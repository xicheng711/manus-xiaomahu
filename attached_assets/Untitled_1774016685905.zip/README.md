
  # Untitled

  This is a code bundle for Untitled. The original project is available at https://www.figma.com/design/AIdiR1MLkh0Fn9b9gAX9mn/Untitled.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  