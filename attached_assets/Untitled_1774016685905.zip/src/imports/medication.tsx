import React, { useState, useCallback } from 'react';
import {
  View, Text, ScrollView, TouchableOpacity, TextInput,
  StyleSheet, Alert, Platform, FlatList,
} from 'react-native';
import { useFocusEffect } from '@react-navigation/native';
import { ScreenContainer } from '@/components/screen-container';
import { getMedications, saveMedications, Medication } from '@/lib/storage';
import * as Haptics from 'expo-haptics';

const TIMES = ['06:00','07:00','07:30','08:00','08:30','09:00','10:00','11:00','12:00','13:00','14:00','15:00','16:00','17:00','18:00','19:00','20:00','21:00','22:00'];
const FREQUENCIES = ['每天一次', '每天两次', '每天三次', '每隔一天', '每周一次', '需要时服用'];
const FREQ_ICONS = ['1️⃣', '2️⃣', '3️⃣', '📅', '📆', '⚡'];

function MedCard({ med, onToggle, onDelete }: { med: Medication; onToggle: () => void; onDelete: () => void }) {
  return (
    <View style={[styles.medCard, med.active ? styles.medCardActive : styles.medCardInactive]}>
      <View style={styles.medCardLeft}>
        <Text style={styles.medIcon}>{med.icon || '💊'}</Text>
        <View style={{ flex: 1 }}>
          <Text style={styles.medName}>{med.name}</Text>
          <Text style={styles.medDose}>{med.dosage} · {med.frequency}</Text>
          <View style={styles.medTimes}>
            {med.times.map((t, i) => (
              <View key={i} style={styles.timeBadge}>
                <Text style={styles.timeBadgeText}>🕐 {t}</Text>
              </View>
            ))}
          </View>
          {med.notes ? <Text style={styles.medNotes}>📝 {med.notes}</Text> : null}
        </View>
      </View>
      <View style={styles.medCardActions}>
        <TouchableOpacity
          style={[styles.toggleBtn, med.active ? styles.toggleBtnOn : styles.toggleBtnOff]}
          onPress={onToggle}
        >
          <Text style={styles.toggleBtnText}>{med.active ? '启用' : '停用'}</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.deleteBtn} onPress={onDelete}>
          <Text style={styles.deleteBtnText}>🗑️</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

export default function MedicationScreen() {
  const [meds, setMeds] = useState<Medication[]>([]);
  const [adding, setAdding] = useState(false);
  const [name, setName] = useState('');
  const [dosage, setDosage] = useState('');
  const [freqIdx, setFreqIdx] = useState(0);
  const [selectedTimes, setSelectedTimes] = useState<string[]>(['08:00']);
  const [notes, setNotes] = useState('');
  const [icon, setIcon] = useState('💊');

  const MED_ICONS = ['💊', '💉', '🩺', '🌡️', '🧴', '🫁', '🧠', '❤️', '🦴', '👁️'];

  useFocusEffect(useCallback(() => {
    getMedications().then(setMeds);
  }, []));

  async function handleAdd() {
    if (!name.trim()) {
      Alert.alert('请输入药物名称');
      return;
    }
    const newMed: Medication = {
      id: Date.now().toString(),
      name: name.trim(),
      dosage: dosage.trim() || '按医嘱',
      frequency: FREQUENCIES[freqIdx],
      times: selectedTimes,
      notes: notes.trim(),
      icon,
      active: true,
    };
    const updated = [...meds, newMed];
    await saveMedications(updated);
    setMeds(updated);
    setAdding(false);
    setName(''); setDosage(''); setFreqIdx(0); setSelectedTimes(['08:00']); setNotes(''); setIcon('💊');
    if (Platform.OS !== 'web') Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
  }

  async function handleToggle(id: string) {
    const updated = meds.map(m => m.id === id ? { ...m, active: !m.active } : m);
    await saveMedications(updated);
    setMeds(updated);
    if (Platform.OS !== 'web') Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
  }

  async function handleDelete(id: string) {
    Alert.alert('删除药物', '确定要删除这个药物吗？', [
      { text: '取消', style: 'cancel' },
      {
        text: '删除', style: 'destructive', onPress: async () => {
          const updated = meds.filter(m => m.id !== id);
          await saveMedications(updated);
          setMeds(updated);
        }
      }
    ]);
  }

  function toggleTime(t: string) {
    setSelectedTimes(prev =>
      prev.includes(t) ? prev.filter(x => x !== t) : [...prev, t]
    );
  }

  return (
    <ScreenContainer>
      <ScrollView contentContainerStyle={styles.container} showsVerticalScrollIndicator={false} keyboardShouldPersistTaps="handled">
        {/* Header */}
        <View style={styles.header}>
          <Text style={styles.title}>💊 用药管理</Text>
          <TouchableOpacity
            style={styles.addBtn}
            onPress={() => setAdding(true)}
          >
            <Text style={styles.addBtnText}>+ 添加药物</Text>
          </TouchableOpacity>
        </View>

        {/* Add Form */}
        {adding && (
          <View style={styles.addForm}>
            <Text style={styles.formTitle}>➕ 添加新药物</Text>

            {/* Icon Picker */}
            <Text style={styles.label}>选择图标</Text>
            <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.iconRow}>
              {MED_ICONS.map(ic => (
                <TouchableOpacity
                  key={ic}
                  style={[styles.iconOption, icon === ic && styles.iconOptionSelected]}
                  onPress={() => setIcon(ic)}
                >
                  <Text style={styles.iconOptionText}>{ic}</Text>
                </TouchableOpacity>
              ))}
            </ScrollView>

            <Text style={styles.label}>药物名称 *</Text>
            <TextInput
              style={styles.input}
              placeholder="例如：多奈哌齐、美金刚..."
              value={name}
              onChangeText={setName}
              placeholderTextColor="#9BA1A6"
            />

            <Text style={styles.label}>剂量</Text>
            <TextInput
              style={styles.input}
              placeholder="例如：5mg、1片..."
              value={dosage}
              onChangeText={setDosage}
              placeholderTextColor="#9BA1A6"
            />

            <Text style={styles.label}>服药频率</Text>
            <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.freqRow}>
              {FREQUENCIES.map((f, i) => (
                <TouchableOpacity
                  key={i}
                  style={[styles.freqOption, freqIdx === i && styles.freqOptionSelected]}
                  onPress={() => setFreqIdx(i)}
                >
                  <Text style={styles.freqIcon}>{FREQ_ICONS[i]}</Text>
                  <Text style={[styles.freqText, freqIdx === i && styles.freqTextSelected]}>{f}</Text>
                </TouchableOpacity>
              ))}
            </ScrollView>

            <Text style={styles.label}>服药时间（可多选）</Text>
            <View style={styles.timesGrid}>
              {TIMES.map(t => (
                <TouchableOpacity
                  key={t}
                  style={[styles.timeOption, selectedTimes.includes(t) && styles.timeOptionSelected]}
                  onPress={() => toggleTime(t)}
                >
                  <Text style={[styles.timeOptionText, selectedTimes.includes(t) && styles.timeOptionTextSelected]}>{t}</Text>
                </TouchableOpacity>
              ))}
            </View>

            <Text style={styles.label}>备注（可选）</Text>
            <TextInput
              style={styles.input}
              placeholder="例如：饭后服用、需要大量喝水..."
              value={notes}
              onChangeText={setNotes}
              placeholderTextColor="#9BA1A6"
            />

            <View style={styles.formBtns}>
              <TouchableOpacity style={styles.cancelBtn} onPress={() => setAdding(false)}>
                <Text style={styles.cancelBtnText}>取消</Text>
              </TouchableOpacity>
              <TouchableOpacity style={styles.saveBtn} onPress={handleAdd}>
                <Text style={styles.saveBtnText}>保存药物 ✓</Text>
              </TouchableOpacity>
            </View>
          </View>
        )}

        {/* Medication List */}
        {meds.length === 0 && !adding ? (
          <View style={styles.emptyState}>
            <Text style={styles.emptyEmoji}>💊</Text>
            <Text style={styles.emptyTitle}>还没有添加药物</Text>
            <Text style={styles.emptyText}>点击右上角「添加药物」开始记录老人的用药计划</Text>
          </View>
        ) : (
          <View style={styles.medList}>
            <Text style={styles.listTitle}>📋 用药计划 ({meds.filter(m => m.active).length} 种启用)</Text>
            {meds.map(med => (
              <MedCard
                key={med.id}
                med={med}
                onToggle={() => handleToggle(med.id)}
                onDelete={() => handleDelete(med.id)}
              />
            ))}
          </View>
        )}

        {/* Reminder Tips */}
        <View style={styles.tipsCard}>
          <Text style={styles.tipsTitle}>💡 用药小贴士</Text>
          <Text style={styles.tipItem}>• 阿尔茨海默症药物需要长期规律服用，不可随意停药</Text>
          <Text style={styles.tipItem}>• 如老人拒绝服药，可尝试将药物混入食物中（请先咨询医生）</Text>
          <Text style={styles.tipItem}>• 使用分药盒，按早中晚分装，避免漏服或重复服药</Text>
          <Text style={styles.tipItem}>• 定期复查，根据医生建议调整用药方案</Text>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  container: { padding: 20, paddingBottom: 40 },
  header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 20 },
  title: { fontSize: 22, fontWeight: '800', color: '#11181C' },
  addBtn: { backgroundColor: '#FF6B6B', borderRadius: 16, paddingHorizontal: 16, paddingVertical: 8 },
  addBtnText: { fontSize: 14, fontWeight: '700', color: '#fff' },
  addForm: { backgroundColor: '#fff', borderRadius: 24, padding: 20, marginBottom: 20, shadowColor: '#000', shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.06, shadowRadius: 12, elevation: 3 },
  formTitle: { fontSize: 18, fontWeight: '800', color: '#11181C', marginBottom: 16 },
  label: { fontSize: 13, fontWeight: '600', color: '#687076', marginBottom: 8, marginTop: 12 },
  input: { backgroundColor: '#F8F9FA', borderRadius: 12, padding: 14, fontSize: 15, color: '#11181C', borderWidth: 1.5, borderColor: '#E5E7EB' },
  iconRow: { flexDirection: 'row', marginBottom: 4 },
  iconOption: { width: 44, height: 44, borderRadius: 12, backgroundColor: '#F8F9FA', alignItems: 'center', justifyContent: 'center', marginRight: 8, borderWidth: 1.5, borderColor: '#E5E7EB' },
  iconOptionSelected: { backgroundColor: '#FFF0F0', borderColor: '#FF6B6B' },
  iconOptionText: { fontSize: 22 },
  freqRow: { flexDirection: 'row', marginBottom: 4 },
  freqOption: { flexDirection: 'row', alignItems: 'center', gap: 6, paddingHorizontal: 14, paddingVertical: 10, borderRadius: 12, backgroundColor: '#F8F9FA', marginRight: 8, borderWidth: 1.5, borderColor: '#E5E7EB' },
  freqOptionSelected: { backgroundColor: '#FFF0F0', borderColor: '#FF6B6B' },
  freqIcon: { fontSize: 16 },
  freqText: { fontSize: 13, fontWeight: '600', color: '#687076' },
  freqTextSelected: { color: '#FF6B6B' },
  timesGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 8 },
  timeOption: { paddingHorizontal: 12, paddingVertical: 8, borderRadius: 10, backgroundColor: '#F8F9FA', borderWidth: 1.5, borderColor: '#E5E7EB' },
  timeOptionSelected: { backgroundColor: '#FFF0F0', borderColor: '#FF6B6B' },
  timeOptionText: { fontSize: 13, fontWeight: '600', color: '#687076' },
  timeOptionTextSelected: { color: '#FF6B6B' },
  formBtns: { flexDirection: 'row', gap: 12, marginTop: 20 },
  cancelBtn: { flex: 1, padding: 14, borderRadius: 16, backgroundColor: '#F8F9FA', alignItems: 'center' },
  cancelBtnText: { fontSize: 15, fontWeight: '600', color: '#687076' },
  saveBtn: { flex: 2, padding: 14, borderRadius: 16, backgroundColor: '#FF6B6B', alignItems: 'center' },
  saveBtnText: { fontSize: 15, fontWeight: '700', color: '#fff' },
  medList: { gap: 12, marginBottom: 20 },
  listTitle: { fontSize: 16, fontWeight: '700', color: '#11181C', marginBottom: 8 },
  medCard: { borderRadius: 20, padding: 16, borderWidth: 1.5 },
  medCardActive: { backgroundColor: '#FFF8F8', borderColor: '#FECACA' },
  medCardInactive: { backgroundColor: '#F8F9FA', borderColor: '#E5E7EB', opacity: 0.7 },
  medCardLeft: { flexDirection: 'row', gap: 12, marginBottom: 10 },
  medIcon: { fontSize: 32 },
  medName: { fontSize: 17, fontWeight: '700', color: '#11181C' },
  medDose: { fontSize: 13, color: '#687076', marginTop: 2 },
  medTimes: { flexDirection: 'row', flexWrap: 'wrap', gap: 6, marginTop: 6 },
  timeBadge: { backgroundColor: '#FFF0F0', borderRadius: 8, paddingHorizontal: 8, paddingVertical: 4 },
  timeBadgeText: { fontSize: 12, color: '#FF6B6B', fontWeight: '600' },
  medNotes: { fontSize: 12, color: '#9BA1A6', marginTop: 4 },
  medCardActions: { flexDirection: 'row', gap: 8, justifyContent: 'flex-end' },
  toggleBtn: { borderRadius: 10, paddingHorizontal: 14, paddingVertical: 8 },
  toggleBtnOn: { backgroundColor: '#DCFCE7' },
  toggleBtnOff: { backgroundColor: '#FEE2E2' },
  toggleBtnText: { fontSize: 13, fontWeight: '600', color: '#374151' },
  deleteBtn: { padding: 8 },
  deleteBtnText: { fontSize: 18 },
  emptyState: { alignItems: 'center', padding: 40 },
  emptyEmoji: { fontSize: 64, marginBottom: 16 },
  emptyTitle: { fontSize: 20, fontWeight: '700', color: '#11181C', marginBottom: 8 },
  emptyText: { fontSize: 14, color: '#687076', textAlign: 'center', lineHeight: 21 },
  tipsCard: { backgroundColor: '#FFFBEB', borderRadius: 20, padding: 18, borderWidth: 1, borderColor: '#FDE68A' },
  tipsTitle: { fontSize: 16, fontWeight: '700', color: '#92400E', marginBottom: 12 },
  tipItem: { fontSize: 13, color: '#78350F', lineHeight: 22 },
});
