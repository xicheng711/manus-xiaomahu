import React, { useState, useRef, useCallback } from 'react';
import {
  View, Text, ScrollView, TouchableOpacity, TextInput,
  StyleSheet, Animated, Platform, FlatList,
} from 'react-native';
import { useFocusEffect } from '@react-navigation/native';
import { ScreenContainer } from '@/components/screen-container';
import { upsertCheckIn, getTodayCheckIn, DailyCheckIn, todayStr } from '@/lib/storage';
import * as Haptics from 'expo-haptics';

// ─── Scroll Picker ─────────────────────────────────────────────────────────────
function ScrollPicker({ items, selectedIndex, onSelect, itemHeight = 52 }: {
  items: string[]; selectedIndex: number; onSelect: (i: number) => void; itemHeight?: number;
}) {
  const listRef = useRef<FlatList>(null);
  const VISIBLE = 5;
  const containerHeight = itemHeight * VISIBLE;
  const paddingItems = Math.floor(VISIBLE / 2);
  const paddedItems = [...Array(paddingItems).fill(''), ...items, ...Array(paddingItems).fill('')];

  const handleScroll = (e: any) => {
    const y = e.nativeEvent.contentOffset.y;
    const idx = Math.round(y / itemHeight);
    if (idx >= 0 && idx < items.length) onSelect(idx);
  };

  return (
    <View style={[styles.pickerWrap, { height: containerHeight }]}>
      <View style={[styles.pickerHighlight, { top: itemHeight * paddingItems, height: itemHeight }]} />
      <FlatList
        ref={listRef}
        data={paddedItems}
        keyExtractor={(_, i) => String(i)}
        showsVerticalScrollIndicator={false}
        snapToInterval={itemHeight}
        decelerationRate="fast"
        onMomentumScrollEnd={handleScroll}
        initialScrollIndex={selectedIndex}
        getItemLayout={(_, index) => ({ length: itemHeight, offset: itemHeight * index, index })}
        renderItem={({ item, index }) => {
          const realIdx = index - paddingItems;
          const isSelected = realIdx === selectedIndex;
          return (
            <View style={[styles.pickerItem, { height: itemHeight }]}>
              <Text style={[styles.pickerText, isSelected && styles.pickerTextSelected]}>{item}</Text>
            </View>
          );
        }}
      />
    </View>
  );
}

// ─── Option Card ───────────────────────────────────────────────────────────────
function OptionCard({ label, icon, selected, onPress }: {
  label: string; icon: string; selected: boolean; onPress: () => void;
}) {
  const scale = useRef(new Animated.Value(1)).current;
  const handlePress = () => {
    Animated.sequence([
      Animated.timing(scale, { toValue: 0.93, duration: 80, useNativeDriver: true }),
      Animated.timing(scale, { toValue: 1, duration: 100, useNativeDriver: true }),
    ]).start();
    if (Platform.OS !== 'web') Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    onPress();
  };
  return (
    <Animated.View style={{ transform: [{ scale }], flex: 1 }}>
      <TouchableOpacity
        style={[styles.optionCard, selected && styles.optionCardSelected]}
        onPress={handlePress}
        activeOpacity={0.9}
      >
        <Text style={styles.optionIcon}>{icon}</Text>
        <Text style={[styles.optionLabel, selected && styles.optionLabelSelected]}>{label}</Text>
        {selected && <Text style={styles.optionCheck}>✓</Text>}
      </TouchableOpacity>
    </Animated.View>
  );
}

// ─── Mood Emoji Picker ─────────────────────────────────────────────────────────
const MOODS = [
  { emoji: '😄', label: '很开心', score: 9 },
  { emoji: '😊', label: '还不错', score: 7 },
  { emoji: '😌', label: '平静', score: 5 },
  { emoji: '😕', label: '有点累', score: 4 },
  { emoji: '😢', label: '不太好', score: 2 },
  { emoji: '😤', label: '烦躁', score: 3 },
];

// ─── Main Screen ───────────────────────────────────────────────────────────────
export default function CheckinScreen() {
  const [checkIn, setCheckIn] = useState<DailyCheckIn | null>(null);
  const [mode, setMode] = useState<'morning' | 'evening'>('morning');
  const [step, setStep] = useState(0);
  const [saving, setSaving] = useState(false);
  const [done, setDone] = useState(false);

  // Morning state
  const [sleepHoursIdx, setSleepHoursIdx] = useState(7); // 0-13 → 1-14h
  const [sleepQuality, setSleepQuality] = useState<'poor' | 'fair' | 'good'>('fair');
  const [morningNotes, setMorningNotes] = useState('');

  // Evening state
  const [moodIdx, setMoodIdx] = useState(1);
  const [medicationTaken, setMedicationTaken] = useState(true);
  const [mealNotes, setMealNotes] = useState('');
  const [eveningNotes, setEveningNotes] = useState('');

  const fadeAnim = useRef(new Animated.Value(1)).current;

  useFocusEffect(useCallback(() => {
    getTodayCheckIn().then(c => {
      setCheckIn(c);
      if (c) {
        setSleepHoursIdx(Math.max(0, Math.min(13, c.sleepHours - 1)));
        setSleepQuality(c.sleepQuality);
        setMorningNotes(c.morningNotes);
        setMoodIdx(MOODS.findIndex(m => m.score === c.moodScore) ?? 1);
        setMedicationTaken(c.medicationTaken);
        setMealNotes(c.mealNotes);
        setEveningNotes(c.eveningNotes);
        if (c.morningDone && c.eveningDone) setDone(true);
        else if (c.morningDone) { setMode('evening'); setStep(0); }
      }
    });
  }, []));

  const SLEEP_HOURS = Array.from({ length: 14 }, (_, i) => `${i + 1} 小时`);
  const selectedMood = MOODS[moodIdx];

  const isHour = new Date().getHours();
  const suggestedMode = isHour < 12 ? 'morning' : 'evening';

  function animateStep(next: () => void) {
    Animated.sequence([
      Animated.timing(fadeAnim, { toValue: 0, duration: 120, useNativeDriver: true }),
    ]).start(() => {
      next();
      Animated.timing(fadeAnim, { toValue: 1, duration: 200, useNativeDriver: true }).start();
    });
  }

  function nextStep() {
    if (Platform.OS !== 'web') Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    const maxSteps = mode === 'morning' ? 3 : 4;
    if (step < maxSteps - 1) {
      animateStep(() => setStep(s => s + 1));
    } else {
      handleSave();
    }
  }

  function prevStep() {
    if (step > 0) {
      if (Platform.OS !== 'web') Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
      animateStep(() => setStep(s => s - 1));
    }
  }

  async function handleSave() {
    setSaving(true);
    if (Platform.OS !== 'web') Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    const data: Partial<DailyCheckIn> & { date: string } = { date: todayStr() };
    if (mode === 'morning') {
      Object.assign(data, {
        sleepHours: sleepHoursIdx + 1,
        sleepQuality,
        morningNotes,
        morningDone: true,
      });
    } else {
      Object.assign(data, {
        moodEmoji: selectedMood.emoji,
        moodScore: selectedMood.score,
        medicationTaken,
        mealNotes,
        eveningNotes,
        eveningDone: true,
      });
    }
    await upsertCheckIn(data);
    setSaving(false);
    setDone(true);
  }

  // ── Done State ──────────────────────────────────────────────────────────────
  if (done) {
    return (
      <ScreenContainer>
        <View style={styles.doneContainer}>
          <Text style={styles.doneEmoji}>🎉</Text>
          <Text style={styles.doneTitle}>打卡完成！</Text>
          <Text style={styles.doneSub}>小马虎已记录今天的数据{'\n'}明天早上查看今日护理预测吧</Text>
          <TouchableOpacity style={styles.doneBtn} onPress={() => { setDone(false); setStep(0); }}>
            <Text style={styles.doneBtnText}>查看今日记录</Text>
          </TouchableOpacity>
        </View>
      </ScreenContainer>
    );
  }

  // ── Mode Selector ───────────────────────────────────────────────────────────
  const morningSteps = [
    {
      q: '昨晚老宝睡了多久？',
      hint: '拨动滚轮选择睡眠时长',
      content: (
        <View style={styles.stepContent}>
          <ScrollPicker items={SLEEP_HOURS} selectedIndex={sleepHoursIdx} onSelect={setSleepHoursIdx} />
          <Text style={styles.selectedDisplay}>已选：{sleepHoursIdx + 1} 小时</Text>
        </View>
      ),
    },
    {
      q: '睡眠质量怎么样？',
      hint: '选择最符合的描述',
      content: (
        <View style={styles.optionRow}>
          <OptionCard icon="😴" label="睡得很好" selected={sleepQuality === 'good'} onPress={() => setSleepQuality('good')} />
          <OptionCard icon="😐" label="一般般" selected={sleepQuality === 'fair'} onPress={() => setSleepQuality('fair')} />
          <OptionCard icon="😫" label="睡不好" selected={sleepQuality === 'poor'} onPress={() => setSleepQuality('poor')} />
        </View>
      ),
    },
    {
      q: '有什么要补充的吗？（可选）',
      hint: '如昨晚有特殊情况可以说明',
      content: (
        <TextInput
          style={styles.noteInput}
          placeholder="例如：昨晚起夜3次、有点烦躁..."
          value={morningNotes}
          onChangeText={setMorningNotes}
          multiline
          numberOfLines={4}
          placeholderTextColor="#9BA1A6"
          returnKeyType="done"
        />
      ),
    },
  ];

  const eveningSteps = [
    {
      q: '今天老宝的心情如何？',
      hint: '选择最接近的情绪',
      content: (
        <View>
          <View style={styles.moodGrid}>
            {MOODS.map((m, i) => (
              <TouchableOpacity
                key={i}
                style={[styles.moodCard, moodIdx === i && styles.moodCardSelected]}
                onPress={() => {
                  setMoodIdx(i);
                  if (Platform.OS !== 'web') Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
                }}
              >
                <Text style={styles.moodEmoji}>{m.emoji}</Text>
                <Text style={[styles.moodLabel, moodIdx === i && styles.moodLabelSelected]}>{m.label}</Text>
              </TouchableOpacity>
            ))}
          </View>
          {moodIdx >= 0 && (
            <Text style={styles.moodScore}>心情分数：{selectedMood.score}/10</Text>
          )}
        </View>
      ),
    },
    {
      q: '今天按时吃药了吗？',
      hint: '记录用药情况',
      content: (
        <View style={styles.optionRow}>
          <OptionCard icon="✅" label="按时吃了" selected={medicationTaken} onPress={() => setMedicationTaken(true)} />
          <OptionCard icon="❌" label="没有吃" selected={!medicationTaken} onPress={() => setMedicationTaken(false)} />
        </View>
      ),
    },
    {
      q: '今天吃了什么？',
      hint: '简单记录一下饮食情况',
      content: (
        <TextInput
          style={styles.noteInput}
          placeholder="例如：早餐小米粥，午餐蒸鱼，晚餐面条..."
          value={mealNotes}
          onChangeText={setMealNotes}
          multiline
          numberOfLines={4}
          placeholderTextColor="#9BA1A6"
          returnKeyType="done"
        />
      ),
    },
    {
      q: '今天有什么要补充的吗？（可选）',
      hint: '如有特殊情况可以记录',
      content: (
        <TextInput
          style={styles.noteInput}
          placeholder="例如：今天有点认不出我、情绪突然激动..."
          value={eveningNotes}
          onChangeText={setEveningNotes}
          multiline
          numberOfLines={4}
          placeholderTextColor="#9BA1A6"
          returnKeyType="done"
        />
      ),
    },
  ];

  const currentSteps = mode === 'morning' ? morningSteps : eveningSteps;
  const currentStep = currentSteps[step];
  const isLast = step === currentSteps.length - 1;

  return (
    <ScreenContainer>
      <ScrollView contentContainerStyle={styles.container} keyboardShouldPersistTaps="handled" showsVerticalScrollIndicator={false}>
        {/* Header */}
        <View style={styles.header}>
          <Text style={styles.appName}>小马虎 🐴🐯</Text>
          <Text style={styles.date}>{new Date().toLocaleDateString('zh-CN', { month: 'long', day: 'numeric', weekday: 'short' })}</Text>
        </View>

        {/* Mode Tabs */}
        <View style={styles.modeTabs}>
          <TouchableOpacity
            style={[styles.modeTab, mode === 'morning' && styles.modeTabActive]}
            onPress={() => { setMode('morning'); setStep(0); }}
          >
            <Text style={[styles.modeTabText, mode === 'morning' && styles.modeTabTextActive]}>
              🌅 早上打卡
            </Text>
            {checkIn?.morningDone && <Text style={styles.doneTag}>✓</Text>}
          </TouchableOpacity>
          <TouchableOpacity
            style={[styles.modeTab, mode === 'evening' && styles.modeTabActive]}
            onPress={() => { setMode('evening'); setStep(0); }}
          >
            <Text style={[styles.modeTabText, mode === 'evening' && styles.modeTabTextActive]}>
              🌙 晚上打卡
            </Text>
            {checkIn?.eveningDone && <Text style={styles.doneTag}>✓</Text>}
          </TouchableOpacity>
        </View>

        {/* Progress dots */}
        <View style={styles.progressDots}>
          {currentSteps.map((_, i) => (
            <View key={i} style={[styles.dot, i === step && styles.dotActive, i < step && styles.dotDone]} />
          ))}
        </View>

        {/* Question Card */}
        <Animated.View style={[styles.questionCard, { opacity: fadeAnim }]}>
          <Text style={styles.questionNum}>第 {step + 1} / {currentSteps.length} 题</Text>
          <Text style={styles.question}>{currentStep.q}</Text>
          <Text style={styles.hint}>{currentStep.hint}</Text>
          <View style={styles.answerArea}>
            {currentStep.content}
          </View>
        </Animated.View>

        {/* Nav buttons */}
        <View style={styles.navRow}>
          {step > 0 && (
            <TouchableOpacity style={styles.backBtn} onPress={prevStep}>
              <Text style={styles.backBtnText}>← 上一题</Text>
            </TouchableOpacity>
          )}
          <TouchableOpacity
            style={[styles.nextBtn, saving && styles.nextBtnDisabled]}
            onPress={nextStep}
            disabled={saving}
          >
            <Text style={styles.nextBtnText}>
              {saving ? '保存中...' : isLast ? (mode === 'morning' ? '完成早上打卡 🌅' : '完成晚上打卡 🌙') : '下一题 →'}
            </Text>
          </TouchableOpacity>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  container: { padding: 20, paddingBottom: 40 },
  header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 20 },
  appName: { fontSize: 20, fontWeight: '800', color: '#11181C' },
  date: { fontSize: 13, color: '#687076' },
  modeTabs: { flexDirection: 'row', gap: 10, marginBottom: 20 },
  modeTab: { flex: 1, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 6, padding: 14, borderRadius: 16, backgroundColor: '#F8F9FA', borderWidth: 1.5, borderColor: '#E5E7EB' },
  modeTabActive: { backgroundColor: '#FFF0F0', borderColor: '#FF6B6B' },
  modeTabText: { fontSize: 14, fontWeight: '600', color: '#687076' },
  modeTabTextActive: { color: '#FF6B6B' },
  doneTag: { fontSize: 12, color: '#22C55E', fontWeight: '700' },
  progressDots: { flexDirection: 'row', justifyContent: 'center', gap: 8, marginBottom: 20 },
  dot: { width: 8, height: 8, borderRadius: 4, backgroundColor: '#E5E7EB' },
  dotActive: { backgroundColor: '#FF6B6B', width: 24 },
  dotDone: { backgroundColor: '#22C55E' },
  questionCard: { backgroundColor: '#fff', borderRadius: 24, padding: 24, marginBottom: 20, shadowColor: '#000', shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.06, shadowRadius: 12, elevation: 3, borderWidth: 1, borderColor: '#F0F0F0' },
  questionNum: { fontSize: 12, color: '#9BA1A6', fontWeight: '600', marginBottom: 8 },
  question: { fontSize: 22, fontWeight: '800', color: '#11181C', marginBottom: 6, lineHeight: 30 },
  hint: { fontSize: 13, color: '#9BA1A6', marginBottom: 20 },
  answerArea: { minHeight: 120 },
  pickerWrap: { backgroundColor: '#F8F9FA', borderRadius: 16, overflow: 'hidden', position: 'relative' },
  pickerHighlight: { position: 'absolute', left: 0, right: 0, backgroundColor: 'rgba(255,107,107,0.12)', borderRadius: 10, zIndex: 1, pointerEvents: 'none' },
  pickerItem: { justifyContent: 'center', alignItems: 'center' },
  pickerText: { fontSize: 16, color: '#9BA1A6' },
  pickerTextSelected: { fontSize: 20, fontWeight: '800', color: '#11181C' },
  selectedDisplay: { textAlign: 'center', fontSize: 14, color: '#FF6B6B', fontWeight: '700', marginTop: 10 },
  stepContent: { alignItems: 'center', width: '100%' },
  optionRow: { flexDirection: 'row', gap: 10 },
  optionCard: { alignItems: 'center', padding: 16, borderRadius: 16, backgroundColor: '#F8F9FA', borderWidth: 1.5, borderColor: '#E5E7EB', gap: 6 },
  optionCardSelected: { backgroundColor: '#FFF0F0', borderColor: '#FF6B6B' },
  optionIcon: { fontSize: 28 },
  optionLabel: { fontSize: 13, fontWeight: '600', color: '#687076', textAlign: 'center' },
  optionLabelSelected: { color: '#FF6B6B' },
  optionCheck: { fontSize: 14, color: '#22C55E', fontWeight: '700' },
  moodGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 10 },
  moodCard: { width: '30%', alignItems: 'center', padding: 12, borderRadius: 16, backgroundColor: '#F8F9FA', borderWidth: 1.5, borderColor: '#E5E7EB', gap: 4 },
  moodCardSelected: { backgroundColor: '#FFF0F0', borderColor: '#FF6B6B' },
  moodEmoji: { fontSize: 28 },
  moodLabel: { fontSize: 12, fontWeight: '600', color: '#687076' },
  moodLabelSelected: { color: '#FF6B6B' },
  moodScore: { textAlign: 'center', fontSize: 14, color: '#FF6B6B', fontWeight: '700', marginTop: 12 },
  noteInput: { backgroundColor: '#F8F9FA', borderRadius: 16, padding: 16, fontSize: 15, color: '#11181C', borderWidth: 1.5, borderColor: '#E5E7EB', minHeight: 100, textAlignVertical: 'top' },
  navRow: { flexDirection: 'row', gap: 12 },
  backBtn: { flex: 1, padding: 16, borderRadius: 20, backgroundColor: '#F8F9FA', alignItems: 'center' },
  backBtnText: { fontSize: 15, fontWeight: '600', color: '#687076' },
  nextBtn: { flex: 2, padding: 16, borderRadius: 20, backgroundColor: '#FF6B6B', alignItems: 'center' },
  nextBtnDisabled: { backgroundColor: '#E5E7EB' },
  nextBtnText: { fontSize: 16, fontWeight: '700', color: '#fff' },
  doneContainer: { flex: 1, alignItems: 'center', justifyContent: 'center', padding: 32 },
  doneEmoji: { fontSize: 72, marginBottom: 16 },
  doneTitle: { fontSize: 28, fontWeight: '800', color: '#11181C', marginBottom: 8 },
  doneSub: { fontSize: 15, color: '#687076', textAlign: 'center', lineHeight: 24, marginBottom: 32 },
  doneBtn: { backgroundColor: '#FF6B6B', borderRadius: 20, paddingHorizontal: 32, paddingVertical: 14 },
  doneBtnText: { fontSize: 16, fontWeight: '700', color: '#fff' },
});
