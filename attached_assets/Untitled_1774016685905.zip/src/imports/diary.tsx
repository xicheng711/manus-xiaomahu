import React, { useState, useCallback } from 'react';
import {
  View, Text, ScrollView, TouchableOpacity, TextInput,
  StyleSheet, Platform, Alert,
} from 'react-native';
import { useFocusEffect } from '@react-navigation/native';
import { ScreenContainer } from '@/components/screen-container';
import { getDiaryEntries, saveDiaryEntry, DiaryEntry, todayStr } from '@/lib/storage';
import * as Haptics from 'expo-haptics';

const MOOD_OPTIONS = [
  { emoji: '😄', label: '很开心', color: '#22C55E' },
  { emoji: '😊', label: '还不错', color: '#84CC16' },
  { emoji: '😌', label: '平静', color: '#6B7280' },
  { emoji: '😕', label: '有点累', color: '#F59E0B' },
  { emoji: '😢', label: '不太好', color: '#EF4444' },
  { emoji: '😤', label: '烦躁', color: '#DC2626' },
];

const TAGS = ['散步', '吃饭好', '睡眠好', '认出家人', '情绪稳定', '有点混乱', '拒绝服药', '跌倒', '特别开心', '需要安慰'];

function DiaryCard({ entry }: { entry: DiaryEntry }) {
  const mood = MOOD_OPTIONS.find(m => m.emoji === entry.moodEmoji) || MOOD_OPTIONS[2];
  return (
    <View style={styles.diaryCard}>
      <View style={styles.diaryCardHeader}>
        <Text style={styles.diaryDate}>{entry.date}</Text>
        <View style={[styles.moodBadge, { backgroundColor: mood.color + '20' }]}>
          <Text style={styles.moodBadgeEmoji}>{entry.moodEmoji}</Text>
          <Text style={[styles.moodBadgeLabel, { color: mood.color }]}>{mood.label}</Text>
        </View>
      </View>
      {entry.tags && entry.tags.length > 0 && (
        <View style={styles.tagRow}>
          {entry.tags.map((tag, i) => (
            <View key={i} style={styles.tag}>
              <Text style={styles.tagText}>{tag}</Text>
            </View>
          ))}
        </View>
      )}
      {entry.content ? <Text style={styles.diaryContent}>{entry.content}</Text> : null}
    </View>
  );
}

export default function DiaryScreen() {
  const [entries, setEntries] = useState<DiaryEntry[]>([]);
  const [writing, setWriting] = useState(false);
  const [selectedMood, setSelectedMood] = useState(0);
  const [selectedTags, setSelectedTags] = useState<string[]>([]);
  const [content, setContent] = useState('');
  const [saving, setSaving] = useState(false);

  useFocusEffect(useCallback(() => {
    getDiaryEntries().then(e => setEntries(e.slice(0, 30)));
  }, []));

  function toggleTag(tag: string) {
    setSelectedTags(prev =>
      prev.includes(tag) ? prev.filter(t => t !== tag) : [...prev, tag]
    );
    if (Platform.OS !== 'web') Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
  }

  async function handleSave() {
    setSaving(true);
    const entry: DiaryEntry = {
      id: Date.now().toString(),
      date: todayStr(),
      moodEmoji: MOOD_OPTIONS[selectedMood].emoji,
      moodLabel: MOOD_OPTIONS[selectedMood].label,
      tags: selectedTags,
      content: content.trim(),
    };
    await saveDiaryEntry(entry);
    const updated = await getDiaryEntries();
    setEntries(updated.slice(0, 30));
    setSaving(false);
    setWriting(false);
    setContent('');
    setSelectedTags([]);
    setSelectedMood(0);
    if (Platform.OS !== 'web') Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
  }

  return (
    <ScreenContainer>
      <ScrollView contentContainerStyle={styles.container} showsVerticalScrollIndicator={false} keyboardShouldPersistTaps="handled">
        {/* Header */}
        <View style={styles.header}>
          <Text style={styles.title}>📖 护理日记</Text>
          <TouchableOpacity style={styles.writeBtn} onPress={() => setWriting(true)}>
            <Text style={styles.writeBtnText}>✏️ 写日记</Text>
          </TouchableOpacity>
        </View>

        {/* Write Form */}
        {writing && (
          <View style={styles.writeForm}>
            <Text style={styles.formTitle}>今天怎么样？</Text>

            {/* Mood */}
            <Text style={styles.label}>老人今天的心情</Text>
            <View style={styles.moodRow}>
              {MOOD_OPTIONS.map((m, i) => (
                <TouchableOpacity
                  key={i}
                  style={[styles.moodOption, selectedMood === i && { borderColor: m.color, backgroundColor: m.color + '15' }]}
                  onPress={() => {
                    setSelectedMood(i);
                    if (Platform.OS !== 'web') Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
                  }}
                >
                  <Text style={styles.moodOptionEmoji}>{m.emoji}</Text>
                  <Text style={[styles.moodOptionLabel, selectedMood === i && { color: m.color }]}>{m.label}</Text>
                </TouchableOpacity>
              ))}
            </View>

            {/* Tags */}
            <Text style={styles.label}>今天发生了什么？（可多选）</Text>
            <View style={styles.tagsGrid}>
              {TAGS.map((tag, i) => (
                <TouchableOpacity
                  key={i}
                  style={[styles.tagOption, selectedTags.includes(tag) && styles.tagOptionSelected]}
                  onPress={() => toggleTag(tag)}
                >
                  <Text style={[styles.tagOptionText, selectedTags.includes(tag) && styles.tagOptionTextSelected]}>
                    {selectedTags.includes(tag) ? '✓ ' : ''}{tag}
                  </Text>
                </TouchableOpacity>
              ))}
            </View>

            {/* Notes */}
            <Text style={styles.label}>详细记录（可选）</Text>
            <TextInput
              style={styles.noteInput}
              placeholder="写下今天的护理情况、老人的特别反应、你的感受..."
              value={content}
              onChangeText={setContent}
              multiline
              numberOfLines={5}
              placeholderTextColor="#9BA1A6"
              textAlignVertical="top"
            />

            <View style={styles.formBtns}>
              <TouchableOpacity style={styles.cancelBtn} onPress={() => setWriting(false)}>
                <Text style={styles.cancelBtnText}>取消</Text>
              </TouchableOpacity>
              <TouchableOpacity style={[styles.saveBtn, saving && { opacity: 0.6 }]} onPress={handleSave} disabled={saving}>
                <Text style={styles.saveBtnText}>{saving ? '保存中...' : '保存日记 💕'}</Text>
              </TouchableOpacity>
            </View>
          </View>
        )}

        {/* Entries */}
        {entries.length === 0 && !writing ? (
          <View style={styles.emptyState}>
            <Text style={styles.emptyEmoji}>📖</Text>
            <Text style={styles.emptyTitle}>还没有日记</Text>
            <Text style={styles.emptyText}>每天记录一点点，{'\n'}积累成最珍贵的回忆</Text>
            <TouchableOpacity style={styles.startBtn} onPress={() => setWriting(true)}>
              <Text style={styles.startBtnText}>开始第一篇日记</Text>
            </TouchableOpacity>
          </View>
        ) : (
          <View style={styles.entriesList}>
            <Text style={styles.listTitle}>📅 最近记录</Text>
            {entries.map(entry => (
              <DiaryCard key={entry.id} entry={entry} />
            ))}
          </View>
        )}
      </ScrollView>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  container: { padding: 20, paddingBottom: 40 },
  header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 20 },
  title: { fontSize: 22, fontWeight: '800', color: '#11181C' },
  writeBtn: { backgroundColor: '#FF6B6B', borderRadius: 16, paddingHorizontal: 16, paddingVertical: 8 },
  writeBtnText: { fontSize: 14, fontWeight: '700', color: '#fff' },
  writeForm: { backgroundColor: '#fff', borderRadius: 24, padding: 20, marginBottom: 20, shadowColor: '#000', shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.06, shadowRadius: 12, elevation: 3 },
  formTitle: { fontSize: 20, fontWeight: '800', color: '#11181C', marginBottom: 16 },
  label: { fontSize: 13, fontWeight: '600', color: '#687076', marginBottom: 10, marginTop: 14 },
  moodRow: { flexDirection: 'row', flexWrap: 'wrap', gap: 8 },
  moodOption: { alignItems: 'center', padding: 10, borderRadius: 14, backgroundColor: '#F8F9FA', borderWidth: 1.5, borderColor: '#E5E7EB', minWidth: 70 },
  moodOptionEmoji: { fontSize: 24 },
  moodOptionLabel: { fontSize: 11, fontWeight: '600', color: '#687076', marginTop: 4 },
  tagsGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 8 },
  tagOption: { paddingHorizontal: 14, paddingVertical: 8, borderRadius: 20, backgroundColor: '#F8F9FA', borderWidth: 1.5, borderColor: '#E5E7EB' },
  tagOptionSelected: { backgroundColor: '#FFF0F0', borderColor: '#FF6B6B' },
  tagOptionText: { fontSize: 13, fontWeight: '600', color: '#687076' },
  tagOptionTextSelected: { color: '#FF6B6B' },
  noteInput: { backgroundColor: '#F8F9FA', borderRadius: 16, padding: 16, fontSize: 15, color: '#11181C', borderWidth: 1.5, borderColor: '#E5E7EB', minHeight: 120 },
  formBtns: { flexDirection: 'row', gap: 12, marginTop: 20 },
  cancelBtn: { flex: 1, padding: 14, borderRadius: 16, backgroundColor: '#F8F9FA', alignItems: 'center' },
  cancelBtnText: { fontSize: 15, fontWeight: '600', color: '#687076' },
  saveBtn: { flex: 2, padding: 14, borderRadius: 16, backgroundColor: '#FF6B6B', alignItems: 'center' },
  saveBtnText: { fontSize: 15, fontWeight: '700', color: '#fff' },
  entriesList: { gap: 12 },
  listTitle: { fontSize: 16, fontWeight: '700', color: '#11181C', marginBottom: 8 },
  diaryCard: { backgroundColor: '#fff', borderRadius: 20, padding: 16, shadowColor: '#000', shadowOffset: { width: 0, height: 1 }, shadowOpacity: 0.04, shadowRadius: 8, elevation: 2, borderWidth: 1, borderColor: '#F0F0F0' },
  diaryCardHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 10 },
  diaryDate: { fontSize: 14, fontWeight: '600', color: '#687076' },
  moodBadge: { flexDirection: 'row', alignItems: 'center', gap: 4, paddingHorizontal: 10, paddingVertical: 4, borderRadius: 12 },
  moodBadgeEmoji: { fontSize: 16 },
  moodBadgeLabel: { fontSize: 12, fontWeight: '600' },
  tagRow: { flexDirection: 'row', flexWrap: 'wrap', gap: 6, marginBottom: 10 },
  tag: { backgroundColor: '#F3F4F6', borderRadius: 10, paddingHorizontal: 10, paddingVertical: 4 },
  tagText: { fontSize: 12, color: '#6B7280', fontWeight: '500' },
  diaryContent: { fontSize: 14, color: '#374151', lineHeight: 21 },
  emptyState: { alignItems: 'center', padding: 40 },
  emptyEmoji: { fontSize: 64, marginBottom: 16 },
  emptyTitle: { fontSize: 20, fontWeight: '700', color: '#11181C', marginBottom: 8 },
  emptyText: { fontSize: 14, color: '#687076', textAlign: 'center', lineHeight: 22, marginBottom: 24 },
  startBtn: { backgroundColor: '#FF6B6B', borderRadius: 20, paddingHorizontal: 28, paddingVertical: 14 },
  startBtnText: { fontSize: 15, fontWeight: '700', color: '#fff' },
});
