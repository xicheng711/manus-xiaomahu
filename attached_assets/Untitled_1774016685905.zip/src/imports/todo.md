# 小马虎 — Project TODO

## Setup & Architecture
- [x] Initialize Expo project with TypeScript and NativeWind
- [x] Design warm Notion/Canva color palette
- [x] Create AsyncStorage data layer (storage.ts)
- [x] Create zodiac utility (zodiac.ts)
- [x] Create professional dementia care knowledge base (care-knowledge.ts)
- [x] Create AI care advice engine with 1-100 score (ai-advice.ts)
- [x] Create weather fetch utility (weather.ts)

## Branding
- [x] Update app name to 小马虎
- [x] Generate cute horse-tiger cartoon mascot icon
- [x] Update app.config.ts with name and logoUrl

## Onboarding Flow
- [x] Welcome screen with app introduction
- [x] Elder name + nickname + birth date input
- [x] Zodiac auto-detection from birth year
- [x] Caregiver name + birth year input
- [x] City input for weather
- [x] Save profile to AsyncStorage

## Home Screen
- [x] App header with 小马虎 branding
- [x] Today check-in banner (pending/done state)
- [x] AI encouragement card
- [x] 7-day mood trend bar chart
- [x] Daily care tip card
- [x] Quick access grid (medication, diary, share, AI)
- [x] Fade-in animation on load

## Daily Check-in (游戏对话式)
- [x] Morning check-in: sleep hours scroll wheel picker
- [x] Morning check-in: sleep quality option cards
- [x] Morning check-in: optional voice/text notes
- [x] Evening check-in: mood emoji picker grid
- [x] Evening check-in: medication taken cards
- [x] Evening check-in: meal situation option cards
- [x] Evening check-in: optional notes
- [x] Completion animation with care score display
- [x] Step-by-step game dialog with progress indicator

## AI Assistant Screen
- [x] 1-100 care score ring with animated spring effect
- [x] Weather badge integration
- [x] Professional advice cards (sleep, mood, medication, activity, nutrition)
- [x] Detailed nutrition advice with meal suggestions
- [x] Encouragement message for caregiver

## Medication Reminders
- [x] Medication list with emoji icons
- [x] Add medication form
- [x] Toggle active/inactive and delete

## Care Diary
- [x] Diary entry list with mood emoji
- [x] New entry form with mood picker and tags
- [x] Delete entries

## Family Sharing
- [x] Daily summary generation
- [x] Share via system share sheet (WeChat compatible)

## Animations & Polish
- [x] Fade-in animations on screen load
- [x] Spring animation on score ring
- [x] Staggered advice card animations
- [x] Haptic feedback on interactions
