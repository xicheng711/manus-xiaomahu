import React, { useEffect, useState, useCallback } from 'react';
import {
  ScrollView, View, Text, TouchableOpacity,
  StyleSheet, Dimensions, Animated,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useRouter, useFocusEffect } from 'expo-router';
import { getDayGreeting, getRandomTip, getEncouragement } from '@/lib/care-knowledge';
import { getTodayCheckIn, getRecentCheckIns, getProfile, DailyCheckIn } from '@/lib/storage';

const { width } = Dimensions.get('window');

// ─── Gradient Card ─────────────────────────────────────────────────────────────
function GradientCard({
  children, style, colors,
}: { children: React.ReactNode; style?: object; colors: string[] }) {
  return (
    <View style={[styles.gradientCard, { backgroundColor: colors[0] }, style]}>
      {children}
    </View>
  );
}

// ─── Mood Bar ──────────────────────────────────────────────────────────────────
function MoodBar({ score, date }: { score: number; date: string }) {
  const height = Math.max(8, (score / 10) * 48);
  const color = score >= 7 ? '#6C9E6C' : score >= 4 ? '#F0A500' : '#E05252';
  const day = new Date(date).toLocaleDateString('zh-CN', { weekday: 'short' }).replace('周', '');
  return (
    <View style={styles.moodBarWrap}>
      <View style={[styles.moodBarBg]}>
        <View style={[styles.moodBarFill, { height, backgroundColor: color }]} />
      </View>
      <Text style={styles.moodBarLabel}>{day}</Text>
    </View>
  );
}

// ─── Home Screen ───────────────────────────────────────────────────────────────
export default function HomeScreen() {
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const [greeting, setGreeting] = useState('');
  const [tip, setTip] = useState<{ category: string; icon: string; tip: string } | null>(null);
  const [todayDone, setTodayDone] = useState(false);
  const [recentMoods, setRecentMoods] = useState<DailyCheckIn[]>([]);
  const [todayCheckIn, setTodayCheckIn] = useState<DailyCheckIn | null>(null);
  const fadeAnim = React.useRef(new Animated.Value(0)).current;

  const loadData = useCallback(async () => {
    const profile = await getProfile();
    setGreeting(getDayGreeting(profile?.nickname || profile?.caregiverName));
    setTip(getRandomTip());
    const today = await getTodayCheckIn();
    setTodayCheckIn(today);
    setTodayDone(!!today);
    const recent = await getRecentCheckIns(7);
    setRecentMoods(recent.slice(0, 7).reverse());
  }, []);

  useFocusEffect(useCallback(() => { loadData(); }, [loadData]));

  useEffect(() => {
    Animated.timing(fadeAnim, { toValue: 1, duration: 600, useNativeDriver: true }).start();
  }, []);

  const encouragement = todayCheckIn
    ? getEncouragement(todayCheckIn.moodScore)
    : '今天还没有打卡哦，点击下方开始记录吧 🐾';

  return (
    <ScrollView
      style={[styles.container, { paddingTop: insets.top }]}
      contentContainerStyle={styles.content}
      showsVerticalScrollIndicator={false}
    >
      <Animated.View style={{ opacity: fadeAnim }}>
        {/* ── Header ── */}
        <View style={styles.header}>
          <View>
            <Text style={styles.appName}>小马虎 🐴🐯</Text>
            <Text style={styles.greeting}>{greeting}</Text>
          </View>
          <TouchableOpacity
            style={styles.profileBtn}
            onPress={() => router.push('/profile' as any)}
          >
            <Text style={styles.profileEmoji}>👤</Text>
          </TouchableOpacity>
        </View>

        {/* ── Today Check-in Banner ── */}
        <TouchableOpacity
          style={[styles.checkinBanner, todayDone ? styles.checkinDone : styles.checkinPending]}
          onPress={() => router.push('/checkin' as any)}
          activeOpacity={0.85}
        >
          <View style={styles.checkinLeft}>
            <Text style={styles.checkinEmoji}>{todayDone ? '✅' : '📋'}</Text>
            <View>
              <Text style={styles.checkinTitle}>
                {todayDone ? '今日打卡已完成' : '开始今日打卡'}
              </Text>
              <Text style={styles.checkinSub}>
                {todayDone
                  ? `心情 ${todayCheckIn?.moodEmoji ?? ''} · 睡眠 ${todayCheckIn?.sleepHours ?? 0}小时`
                  : '每天3个问题，记录老宝的状态'}
              </Text>
            </View>
          </View>
          <Text style={styles.chevron}>{todayDone ? '🔄' : '▶'}</Text>
        </TouchableOpacity>

        {/* ── AI 鼓励卡片 ── */}
        <GradientCard colors={['#F0F7EE']} style={styles.aiCard}>
          <View style={styles.aiHeader}>
            <Text style={styles.aiEmoji}>🤖</Text>
            <Text style={styles.aiLabel}>小马虎 AI 助手</Text>
          </View>
          <Text style={styles.aiMessage}>{encouragement}</Text>
          <TouchableOpacity onPress={() => router.push('/assistant' as any)} style={styles.aiBtn}>
            <Text style={styles.aiBtnText}>查看更多建议 →</Text>
          </TouchableOpacity>
        </GradientCard>

        {/* ── 7天情绪趋势 ── */}
        {recentMoods.length > 0 && (
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>📊 近7天情绪趋势</Text>
            <View style={styles.moodChart}>
              {recentMoods.map((c, i) => (
                <MoodBar key={i} score={c.moodScore} date={c.date} />
              ))}
            </View>
          </View>
        )}

        {/* ── 今日护理贴士 ── */}
        {tip && (
          <GradientCard colors={['#FFF8F0']} style={styles.tipCard}>
            <View style={styles.tipHeader}>
              <Text style={styles.tipIcon}>{tip.icon}</Text>
              <Text style={styles.tipCategory}>{tip.category}</Text>
            </View>
            <Text style={styles.tipText}>{tip.tip}</Text>
          </GradientCard>
        )}

        {/* ── 快捷入口 ── */}
        <Text style={styles.sectionTitle}>🚀 快捷入口</Text>
        <View style={styles.quickGrid}>
          {[
            { emoji: '💊', label: '用药提醒', route: '/medication', color: '#EEF4FF' },
            { emoji: '📖', label: '护理日记', route: '/diary', color: '#FFF4EE' },
            { emoji: '🤝', label: '家庭共享', route: '/share', color: '#F0FFF4' },
            { emoji: '🧠', label: 'AI 助手', route: '/assistant', color: '#FFF0F8' },
          ].map((item) => (
            <TouchableOpacity
              key={item.route}
              style={[styles.quickCard, { backgroundColor: item.color }]}
              onPress={() => router.push(item.route as any)}
              activeOpacity={0.8}
            >
              <Text style={styles.quickEmoji}>{item.emoji}</Text>
              <Text style={styles.quickLabel}>{item.label}</Text>
            </TouchableOpacity>
          ))}
        </View>

        <View style={{ height: 32 }} />
      </Animated.View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#FAFAF8' },
  content: { paddingHorizontal: 20, paddingBottom: 24 },
  header: {
    flexDirection: 'row', justifyContent: 'space-between',
    alignItems: 'flex-start', paddingTop: 20, paddingBottom: 16,
  },
  appName: { fontSize: 22, fontWeight: '800', color: '#1A1A1A', letterSpacing: -0.5 },
  greeting: { fontSize: 14, color: '#9B9B9B', marginTop: 2 },
  profileBtn: {
    width: 40, height: 40, borderRadius: 20,
    backgroundColor: '#F0F0EE', alignItems: 'center', justifyContent: 'center',
  },
  profileEmoji: { fontSize: 18 },

  // Check-in banner
  checkinBanner: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    borderRadius: 20, padding: 18, marginBottom: 16,
  },
  checkinPending: { backgroundColor: '#6C9E6C' },
  checkinDone: { backgroundColor: '#E8F5E8', borderWidth: 1.5, borderColor: '#C8E6C8' },
  checkinLeft: { flexDirection: 'row', alignItems: 'center', gap: 12, flex: 1 },
  checkinEmoji: { fontSize: 28 },
  checkinTitle: {
    fontSize: 16, fontWeight: '700',
    color: '#1A1A1A',
  },
  checkinSub: { fontSize: 13, color: '#666', marginTop: 2 },
  chevron: { fontSize: 16, color: '#999' },

  // AI card
  aiCard: { marginBottom: 16 },
  aiHeader: { flexDirection: 'row', alignItems: 'center', gap: 8, marginBottom: 10 },
  aiEmoji: { fontSize: 20 },
  aiLabel: { fontSize: 13, fontWeight: '600', color: '#6C9E6C' },
  aiMessage: { fontSize: 15, color: '#333', lineHeight: 22, marginBottom: 12 },
  aiBtn: { alignSelf: 'flex-start' },
  aiBtnText: { fontSize: 13, color: '#6C9E6C', fontWeight: '600' },

  // Mood chart
  section: { marginBottom: 16 },
  sectionTitle: { fontSize: 15, fontWeight: '700', color: '#1A1A1A', marginBottom: 12 },
  moodChart: {
    flexDirection: 'row', alignItems: 'flex-end', justifyContent: 'space-between',
    backgroundColor: '#FFFFFF', borderRadius: 16, padding: 16,
    borderWidth: 1, borderColor: '#EBEBEB',
    height: 90,
  },
  moodBarWrap: { alignItems: 'center', flex: 1 },
  moodBarBg: {
    width: 10, height: 56, backgroundColor: '#F0F0EE',
    borderRadius: 5, justifyContent: 'flex-end', overflow: 'hidden',
  },
  moodBarFill: { width: '100%', borderRadius: 5 },
  moodBarLabel: { fontSize: 10, color: '#9B9B9B', marginTop: 4 },

  // Tip card
  tipCard: { marginBottom: 20 },
  tipHeader: { flexDirection: 'row', alignItems: 'center', gap: 8, marginBottom: 8 },
  tipIcon: { fontSize: 20 },
  tipCategory: { fontSize: 12, fontWeight: '700', color: '#F4A261', textTransform: 'uppercase', letterSpacing: 0.5 },
  tipText: { fontSize: 14, color: '#444', lineHeight: 22 },

  // Quick grid
  quickGrid: {
    flexDirection: 'row', flexWrap: 'wrap', gap: 12, marginTop: 8,
  },
  quickCard: {
    width: (width - 52) / 2, borderRadius: 16, padding: 18,
    alignItems: 'flex-start',
    borderWidth: 1, borderColor: 'rgba(0,0,0,0.04)',
  },
  quickEmoji: { fontSize: 28, marginBottom: 8 },
  quickLabel: { fontSize: 14, fontWeight: '600', color: '#1A1A1A' },

  // Gradient card base
  gradientCard: { borderRadius: 20, padding: 18, marginBottom: 16, borderWidth: 1, borderColor: 'rgba(0,0,0,0.04)' },
});
