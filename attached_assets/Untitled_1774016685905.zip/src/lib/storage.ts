// Web版本的本地存储工具（替代AsyncStorage）

export interface DailyCheckIn {
  id: string;
  date: string; // YYYY-MM-DD
  sleepHours: number;
  sleepQuality: 'poor' | 'fair' | 'good';
  morningNotes: string;
  morningDone: boolean;
  moodEmoji: string;
  moodScore: number;
  medicationTaken: boolean;
  mealNotes: string;
  eveningNotes: string;
  eveningDone: boolean;
}

export interface Medication {
  id: string;
  name: string;
  dosage: string;
  frequency: string;
  times: string[];
  notes: string;
  icon: string;
  active: boolean;
}

export interface DiaryEntry {
  id: string;
  date: string;
  moodEmoji: string;
  moodLabel: string;
  tags: string[];
  content: string;
}

export interface ElderProfile {
  id: string;
  elderName: string;
  nickname: string;
  birthDate: string;
  zodiacEmoji: string;
  caregiverName: string;
  caregiverBirthYear: string;
  city: string;
}

// ==================== Helper Functions ====================

export function todayStr(): string {
  return new Date().toISOString().split('T')[0];
}

// ==================== Profile ====================

export async function getProfile(): Promise<ElderProfile | null> {
  const data = localStorage.getItem('profile');
  return data ? JSON.parse(data) : null;
}

export async function saveProfile(profile: ElderProfile): Promise<void> {
  localStorage.setItem('profile', JSON.stringify(profile));
}

// ==================== Daily Check-in ====================

export async function getTodayCheckIn(): Promise<DailyCheckIn | null> {
  const all = await getAllCheckIns();
  return all.find(c => c.date === todayStr()) || null;
}

export async function getAllCheckIns(): Promise<DailyCheckIn[]> {
  const data = localStorage.getItem('checkIns');
  return data ? JSON.parse(data) : [];
}

export async function getRecentCheckIns(days: number): Promise<DailyCheckIn[]> {
  const all = await getAllCheckIns();
  return all.slice(-days).reverse();
}

export async function upsertCheckIn(partial: Partial<DailyCheckIn> & { date: string }): Promise<void> {
  const all = await getAllCheckIns();
  const idx = all.findIndex(c => c.date === partial.date);
  
  if (idx >= 0) {
    all[idx] = { ...all[idx], ...partial };
  } else {
    all.push({
      id: Date.now().toString(),
      date: partial.date,
      sleepHours: 0,
      sleepQuality: 'fair',
      morningNotes: '',
      morningDone: false,
      moodEmoji: '😊',
      moodScore: 5,
      medicationTaken: true,
      mealNotes: '',
      eveningNotes: '',
      eveningDone: false,
      ...partial,
    });
  }
  
  localStorage.setItem('checkIns', JSON.stringify(all));
}

// ==================== Medications ====================

export async function getMedications(): Promise<Medication[]> {
  const data = localStorage.getItem('medications');
  return data ? JSON.parse(data) : [];
}

export async function saveMedications(meds: Medication[]): Promise<void> {
  localStorage.setItem('medications', JSON.stringify(meds));
}

// ==================== Diary ====================

export async function getDiaryEntries(): Promise<DiaryEntry[]> {
  const data = localStorage.getItem('diaryEntries');
  const entries = data ? JSON.parse(data) : [];
  return entries.sort((a: DiaryEntry, b: DiaryEntry) => 
    new Date(b.date).getTime() - new Date(a.date).getTime()
  );
}

export async function saveDiaryEntry(entry: DiaryEntry): Promise<void> {
  const all = await getDiaryEntries();
  all.unshift(entry);
  localStorage.setItem('diaryEntries', JSON.stringify(all));
}

export async function deleteDiaryEntry(id: string): Promise<void> {
  const all = await getDiaryEntries();
  const filtered = all.filter(e => e.id !== id);
  localStorage.setItem('diaryEntries', JSON.stringify(filtered));
}
