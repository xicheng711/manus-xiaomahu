// 专业的认知症护理知识库和AI建议生成

export function getDayGreeting(name?: string): string {
  const hour = new Date().getHours();
  const greetings = [
    { time: [5, 11], msg: '早上好' },
    { time: [11, 14], msg: '中午好' },
    { time: [14, 18], msg: '下午好' },
    { time: [18, 24], msg: '晚上好' },
    { time: [0, 5], msg: '夜深了' },
  ];
  
  const greeting = greetings.find(g => hour >= g.time[0] && hour < g.time[1])?.msg || '你好';
  return name ? `${greeting}，${name}！` : `${greeting}！`;
}

export function getEncouragement(moodScore: number): string {
  if (moodScore >= 8) {
    return '太棒了！老人今天状态很好，继续保持这份温暖的陪伴 ❤️';
  } else if (moodScore >= 6) {
    return '不错哦！每天的陪伴和关怀都在默默起作用 🌟';
  } else if (moodScore >= 4) {
    return '今天可能有些起伏，但你做得很好。试着用音乐或散步转移注意力 🎵';
  } else {
    return '今天比较辛苦，记得照顾好自己的情绪。你是最棒的照护者 💪';
  }
}

interface CareTip {
  category: string;
  icon: string;
  tip: string;
}

const CARE_TIPS: CareTip[] = [
  {
    category: '沟通技巧',
    icon: '💬',
    tip: '与老人对话时，保持眼神接触，语速放慢，用简单清晰的语句，避免一次问太多问题。',
  },
  {
    category: '情绪管理',
    icon: '💛',
    tip: '如果老人出现焦虑或烦躁，不要反驳或纠正，尝试顺着ta的话题，用温和的语气安抚。',
  },
  {
    category: '日常活动',
    icon: '🌸',
    tip: '鼓励老人参与简单的家务活动，如叠毛巾、整理物品，有助于维持认知功能和自信心。',
  },
  {
    category: '睡眠质量',
    icon: '😴',
    tip: '保持规律的作息时间，白天适度活动，避免午睡过长，睡前避免刺激性饮料。',
  },
  {
    category: '安全防护',
    icon: '🏡',
    tip: '在浴室安装扶手，移除地毯和障碍物，保持充足照明，预防跌倒风险。',
  },
  {
    category: '营养饮食',
    icon: '🥗',
    tip: '提供色彩丰富、易咀嚼的食物，鼓励多喝水，观察是否有吞咽困难的迹象。',
  },
  {
    category: '记忆辅助',
    icon: '📝',
    tip: '在家中关键位置贴上提示标签，使用日历和时钟，帮助老人保持时间和空间定向。',
  },
  {
    category: '照护者支持',
    icon: '🤗',
    tip: '照顾好自己才能更好地照顾他人。定期休息，寻求家人帮助，不要独自承担所有压力。',
  },
];

export function getRandomTip(): CareTip {
  return CARE_TIPS[Math.floor(Math.random() * CARE_TIPS.length)];
}

export function getAllTips(): CareTip[] {
  return CARE_TIPS;
}

// 根据打卡数据生成护理分数和建议
export function generateCareAdvice(checkIn: {
  sleepHours: number;
  sleepQuality: string;
  moodScore: number;
  medicationTaken: boolean;
}): {
  score: number;
  sleepAdvice: string;
  moodAdvice: string;
  medicationAdvice: string;
  activityAdvice: string;
} {
  let score = 50; // 基础分

  // 睡眠评分 (30分)
  if (checkIn.sleepHours >= 7 && checkIn.sleepHours <= 9) {
    score += 15;
  } else if (checkIn.sleepHours >= 6 && checkIn.sleepHours <= 10) {
    score += 10;
  } else {
    score += 5;
  }
  
  if (checkIn.sleepQuality === 'good') {
    score += 15;
  } else if (checkIn.sleepQuality === 'fair') {
    score += 10;
  } else {
    score += 5;
  }

  // 情绪评分 (30分)
  score += Math.floor((checkIn.moodScore / 10) * 30);

  // 用药评分 (20分)
  if (checkIn.medicationTaken) {
    score += 20;
  }

  const sleepAdvice =
    checkIn.sleepHours < 6
      ? '睡眠时间较短，建议调整作息，确保充足休息。'
      : checkIn.sleepHours > 10
      ? '睡眠时间较长，注意是否有其他健康问题。'
      : checkIn.sleepQuality === 'poor'
      ? '睡眠质量欠佳，可尝试睡前放松活动，保持卧室安静舒适。'
      : '睡眠状况良好，继续保持规律作息！';

  const moodAdvice =
    checkIn.moodScore >= 7
      ? '情绪状态很好，多陪伴聊天，保持愉快氛围。'
      : checkIn.moodScore >= 5
      ? '情绪平稳，可以安排一些轻松的活动，如散步或听音乐。'
      : '情绪较低落，给予更多关注和安慰，避免批评或指责。';

  const medicationAdvice = checkIn.medicationTaken
    ? '用药依从性良好，继续按时服药。'
    : '今天未按时服药，请提醒并记录原因，必要时咨询医生。';

  const activityAdvice =
    checkIn.moodScore >= 7
      ? '状态不错，可以安排户外散步、简单手工或社交活动。'
      : '建议进行舒缓活动，如听音乐、看照片、简单拼图等。';

  return {
    score: Math.min(100, score),
    sleepAdvice,
    moodAdvice,
    medicationAdvice,
    activityAdvice,
  };
}
