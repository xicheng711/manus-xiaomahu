import { createBrowserRouter } from "react-router";
import { HomePage } from "./pages/home";
import { HomeEnhancedPage } from "./pages/home-enhanced";
import { CheckInPage } from "./pages/checkin";
import { MedicationPage } from "./pages/medication";
import { DiaryPage } from "./pages/diary";
import { AssistantPage } from "./pages/assistant";
import { SharePage } from "./pages/share";
import { IconGeneratorPage } from "./pages/icon-generator";
import { FramePage } from "./pages/frame";
import { CelebrationDemoPage } from "./pages/celebration-demo";
import { Layout } from "./components/layout";

export const router = createBrowserRouter([
  {
    path: "/",
    Component: Layout,
    children: [
      { index: true, Component: HomeEnhancedPage },
      { path: "home-original", Component: HomePage },
      { path: "checkin", Component: CheckInPage },
      { path: "medication", Component: MedicationPage },
      { path: "diary", Component: DiaryPage },
      { path: "assistant", Component: AssistantPage },
      { path: "share", Component: SharePage },
    ],
  },
  {
    path: "/icon-generator",
    Component: IconGeneratorPage,
  },
  {
    path: "/frame",
    Component: FramePage,
  },
  {
    path: "/celebration",
    Component: CelebrationDemoPage,
  },
]);