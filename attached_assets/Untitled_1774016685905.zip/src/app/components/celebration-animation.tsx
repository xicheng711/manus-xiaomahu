import { motion, AnimatePresence } from 'motion/react';
import { useEffect, useState } from 'react';

interface CelebrationAnimationProps {
  isVisible: boolean;
  onComplete: () => void;
  userName?: string;
}

// 精细的浇水壶SVG - 复古手绘风格
function WateringCan() {
  return (
    <svg width="160" height="160" viewBox="0 0 160 160" fill="none">
      <defs>
        {/* 金属质感渐变 */}
        <linearGradient id="canBody" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#86efac" />
          <stop offset="50%" stopColor="#4ade80" />
          <stop offset="100%" stopColor="#22c55e" />
        </linearGradient>
        <linearGradient id="canShine" x1="0%" y1="0%" x2="0%" y2="100%">
          <stop offset="0%" stopColor="white" stopOpacity="0.8" />
          <stop offset="100%" stopColor="white" stopOpacity="0" />
        </linearGradient>
        {/* 阴影 */}
        <filter id="shadow">
          <feDropShadow dx="2" dy="4" stdDeviation="3" floodOpacity="0.3"/>
        </filter>
      </defs>
      
      {/* 壶嘴 */}
      <path
        d="M 100 55 Q 120 55, 128 62 L 128 70 Q 120 77, 100 77 L 100 55 Z"
        fill="url(#canBody)"
        stroke="#16a34a"
        strokeWidth="2.5"
        filter="url(#shadow)"
      />
      {/* 壶嘴内部阴影 */}
      <ellipse cx="100" cy="66" rx="4" ry="8" fill="#15803d" opacity="0.3"/>
      
      {/* 壶嘴孔 - 更多细节 */}
      {[0, 1, 2, 3, 4, 5].map((i) => (
        <g key={i}>
          <circle
            cx={118 + (i % 3) * 5}
            cy={62 + Math.floor(i / 3) * 6}
            r="2"
            fill="#15803d"
          />
          <circle
            cx={118 + (i % 3) * 5 - 0.5}
            cy={62 + Math.floor(i / 3) * 6 - 0.5}
            r="0.8"
            fill="#86efac"
          />
        </g>
      ))}
      
      {/* 主壶身 */}
      <ellipse
        cx="65"
        cy="70"
        rx="35"
        ry="42"
        fill="url(#canBody)"
        stroke="#16a34a"
        strokeWidth="3"
        filter="url(#shadow)"
      />
      
      {/* 壶身装饰条纹 */}
      <path
        d="M 40 50 Q 65 52, 90 50"
        stroke="#d1fae5"
        strokeWidth="2"
        fill="none"
        opacity="0.6"
      />
      <path
        d="M 38 65 Q 65 67, 92 65"
        stroke="#d1fae5"
        strokeWidth="2"
        fill="none"
        opacity="0.6"
      />
      <path
        d="M 40 80 Q 65 82, 90 80"
        stroke="#d1fae5"
        strokeWidth="2"
        fill="none"
        opacity="0.6"
      />
      
      {/* 壶身高光 */}
      <ellipse
        cx="52"
        cy="52"
        rx="15"
        ry="25"
        fill="url(#canShine)"
      />
      
      {/* 壶顶开口 */}
      <ellipse
        cx="65"
        cy="30"
        rx="18"
        ry="6"
        fill="#15803d"
        stroke="#16a34a"
        strokeWidth="2"
      />
      <ellipse
        cx="65"
        cy="28"
        rx="18"
        ry="6"
        fill="#4ade80"
        stroke="#16a34a"
        strokeWidth="2"
      />
      
      {/* 手柄 - 更复杂的曲线 */}
      <path
        d="M 33 50 Q 15 50, 12 65 Q 10 75, 15 82 Q 20 88, 33 90"
        fill="none"
        stroke="#16a34a"
        strokeWidth="6"
        strokeLinecap="round"
        filter="url(#shadow)"
      />
      <path
        d="M 33 50 Q 18 50, 16 65 Q 14 75, 18 82 Q 22 87, 33 90"
        fill="none"
        stroke="#86efac"
        strokeWidth="3"
        strokeLinecap="round"
      />
      
      {/* 手柄装饰圈 */}
      <circle cx="33" cy="50" r="4" fill="#4ade80" stroke="#16a34a" strokeWidth="2"/>
      <circle cx="33" cy="90" r="4" fill="#4ade80" stroke="#16a34a" strokeWidth="2"/>
    </svg>
  );
}

// 精细的水滴 - 带反光和波纹
function WaterDrop({ delay = 0 }: { delay?: number }) {
  return (
    <motion.svg
      width="28"
      height="38"
      viewBox="0 0 28 38"
      fill="none"
      initial={{ opacity: 0, y: -10 }}
      animate={{ opacity: [0, 1, 0.9, 0], y: [0, 80, 100], scale: [0.8, 1, 1.1, 0.9] }}
      transition={{ duration: 1.8, delay, ease: 'easeIn' }}
    >
      <defs>
        <linearGradient id={`waterGrad${delay}`} x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#7dd3fc" />
          <stop offset="50%" stopColor="#38bdf8" />
          <stop offset="100%" stopColor="#0284c7" />
        </linearGradient>
        <radialGradient id={`waterShine${delay}`}>
          <stop offset="0%" stopColor="white" stopOpacity="0.9" />
          <stop offset="100%" stopColor="white" stopOpacity="0" />
        </radialGradient>
      </defs>
      
      {/* 水滴主体 */}
      <path
        d="M 14 3 Q 5 12, 5 20 Q 5 30, 14 35 Q 23 30, 23 20 Q 23 12, 14 3 Z"
        fill={`url(#waterGrad${delay})`}
        stroke="#0369a1"
        strokeWidth="1.5"
        opacity="0.95"
      />
      
      {/* 主高光 */}
      <ellipse
        cx="10"
        cy="14"
        rx="5"
        ry="8"
        fill={`url(#waterShine${delay})`}
      />
      
      {/* 次要高光 */}
      <circle cx="18" cy="22" r="2.5" fill="white" opacity="0.5"/>
      <circle cx="11" cy="25" r="1.5" fill="white" opacity="0.6"/>
    </motion.svg>
  );
}

// 超精细花盆 - 陶瓷质感
function FlowerPot() {
  return (
    <svg width="180" height="130" viewBox="0 0 180 130" fill="none">
      <defs>
        <linearGradient id="potBody" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#fed7aa" />
          <stop offset="50%" stopColor="#fb923c" />
          <stop offset="100%" stopColor="#ea580c" />
        </linearGradient>
        <linearGradient id="potRim" x1="0%" y1="0%" x2="0%" y2="100%">
          <stop offset="0%" stopColor="#fdba74" />
          <stop offset="100%" stopColor="#f97316" />
        </linearGradient>
        <radialGradient id="potShine">
          <stop offset="0%" stopColor="white" stopOpacity="0.4" />
          <stop offset="100%" stopColor="white" stopOpacity="0" />
        </radialGradient>
        <filter id="potShadow">
          <feDropShadow dx="0" dy="6" stdDeviation="4" floodOpacity="0.4"/>
        </filter>
      </defs>
      
      {/* 花盆主体 */}
      <path
        d="M 50 35 L 38 105 Q 38 112, 45 112 L 135 112 Q 142 112, 142 105 L 130 35 Z"
        fill="url(#potBody)"
        stroke="#c2410c"
        strokeWidth="3"
        filter="url(#potShadow)"
      />
      
      {/* 装饰波浪纹 */}
      <path
        d="M 48 50 Q 60 48, 72 50 Q 84 52, 96 50 Q 108 48, 120 50 Q 132 52, 132 50"
        stroke="#fef3c7"
        strokeWidth="2.5"
        fill="none"
        opacity="0.8"
      />
      <path
        d="M 46 68 Q 58 66, 70 68 Q 82 70, 94 68 Q 106 66, 118 68 Q 130 70, 134 68"
        stroke="#fef3c7"
        strokeWidth="2.5"
        fill="none"
        opacity="0.8"
      />
      
      {/* 装饰圆点 */}
      {[0, 1, 2, 3, 4, 5].map((i) => (
        <circle
          key={i}
          cx={55 + i * 14}
          cy="85"
          r="3"
          fill="#fef3c7"
          opacity="0.7"
        />
      ))}
      
      {/* 高光 */}
      <ellipse
        cx="70"
        cy="60"
        rx="20"
        ry="35"
        fill="url(#potShine)"
      />
      
      {/* 花盆边缘 */}
      <ellipse
        cx="90"
        cy="35"
        rx="40"
        ry="8"
        fill="url(#potRim)"
        stroke="#c2410c"
        strokeWidth="2.5"
      />
      
      {/* 边缘高光 */}
      <ellipse
        cx="90"
        cy="33"
        rx="35"
        ry="4"
        fill="white"
        opacity="0.3"
      />
      
      {/* 泥土层 - 多层次 */}
      <ellipse
        cx="90"
        cy="37"
        rx="38"
        ry="6"
        fill="#78350f"
      />
      <ellipse
        cx="90"
        cy="36"
        rx="38"
        ry="5"
        fill="#92400e"
      />
      {/* 泥土颗粒 */}
      {[...Array(20)].map((_, i) => (
        <circle
          key={i}
          cx={60 + Math.random() * 60}
          cy={34 + Math.random() * 4}
          r={0.5 + Math.random()}
          fill="#451a03"
          opacity="0.6"
        />
      ))}
    </svg>
  );
}

// 超精细桃花 - 五瓣带花蕊、叶子
function PeachBlossom({ size = 'large' }: { size?: 'large' | 'small' }) {
  const scale = size === 'large' ? 1 : 0.6;
  const width = 200 * scale;
  const height = 200 * scale;
  
  return (
    <svg width={width} height={height} viewBox="0 0 200 200" fill="none">
      <defs>
        <radialGradient id={`petal${size}`}>
          <stop offset="0%" stopColor="#fce7f3" />
          <stop offset="50%" stopColor="#fda4af" />
          <stop offset="100%" stopColor="#fb7185" />
        </radialGradient>
        <radialGradient id={`petalShine${size}`}>
          <stop offset="0%" stopColor="white" stopOpacity="0.8" />
          <stop offset="100%" stopColor="white" stopOpacity="0" />
        </radialGradient>
        <radialGradient id={`center${size}`}>
          <stop offset="0%" stopColor="#fef08a" />
          <stop offset="70%" stopColor="#fde047" />
          <stop offset="100%" stopColor="#facc15" />
        </radialGradient>
        <filter id={`petalShadow${size}`}>
          <feDropShadow dx="1" dy="2" stdDeviation="2" floodOpacity="0.2"/>
        </filter>
      </defs>
      
      {/* 背景叶子 */}
      {size === 'large' && (
        <>
          {[0, 1].map((i) => {
            const angle = i * 180;
            return (
              <g key={i} transform={`rotate(${angle + 25}, 100, 100)`}>
                <ellipse
                  cx="100"
                  cy="145"
                  rx="18"
                  ry="35"
                  fill="#86efac"
                  stroke="#22c55e"
                  strokeWidth="2"
                  opacity="0.9"
                />
                <path
                  d="M 100 110 Q 100 140, 100 145"
                  stroke="#16a34a"
                  strokeWidth="2.5"
                  fill="none"
                />
                <ellipse
                  cx="95"
                  cy="130"
                  rx="5"
                  ry="12"
                  fill="#bbf7d0"
                  opacity="0.5"
                />
              </g>
            );
          })}
        </>
      )}
      
      {/* 5片花瓣 - 超细致 */}
      {[0, 1, 2, 3, 4].map((i) => {
        const angle = (i * 72 - 90) * (Math.PI / 180);
        const x = 100 + Math.cos(angle) * 45;
        const y = 100 + Math.sin(angle) * 45;
        const rotation = i * 72;
        
        return (
          <g key={i} filter={`url(#petalShadow${size})`}>
            {/* 花瓣主体 */}
            <ellipse
              cx={x}
              cy={y}
              rx="28"
              ry="38"
              fill={`url(#petal${size})`}
              stroke="#f43f5e"
              strokeWidth="2"
              transform={`rotate(${rotation}, ${x}, ${y})`}
            />
            
            {/* 花瓣纹理 */}
            <path
              d={`M ${x} ${y - 30} Q ${x} ${y}, ${x} ${y + 30}`}
              stroke="#fda4af"
              strokeWidth="1.5"
              opacity="0.4"
              transform={`rotate(${rotation}, ${x}, ${y})`}
            />
            <path
              d={`M ${x - 8} ${y - 20} Q ${x} ${y}, ${x - 5} ${y + 25}`}
              stroke="#fda4af"
              strokeWidth="1"
              opacity="0.3"
              transform={`rotate(${rotation}, ${x}, ${y})`}
            />
            <path
              d={`M ${x + 8} ${y - 20} Q ${x} ${y}, ${x + 5} ${y + 25}`}
              stroke="#fda4af"
              strokeWidth="1"
              opacity="0.3"
              transform={`rotate(${rotation}, ${x}, ${y})`}
            />
            
            {/* 花瓣高光 */}
            <ellipse
              cx={x - 8}
              cy={y - 15}
              rx="10"
              ry="18"
              fill={`url(#petalShine${size})`}
              transform={`rotate(${rotation}, ${x}, ${y})`}
            />
            
            {/* 花瓣边缘深色 */}
            <ellipse
              cx={x}
              cy={y}
              rx="26"
              ry="36"
              fill="none"
              stroke="#f43f5e"
              strokeWidth="1.5"
              opacity="0.3"
              transform={`rotate(${rotation}, ${x}, ${y})`}
            />
          </g>
        );
      })}
      
      {/* 花心外圈 */}
      <circle
        cx="100"
        cy="100"
        r="24"
        fill={`url(#center${size})`}
        stroke="#f59e0b"
        strokeWidth="2.5"
      />
      
      {/* 花心装饰圈 */}
      <circle
        cx="100"
        cy="100"
        r="20"
        fill="none"
        stroke="#fb923c"
        strokeWidth="1.5"
        opacity="0.4"
      />
      
      {/* 花蕊 - 3D效果 */}
      {[...Array(12)].map((_, i) => {
        const angle = (i * 30) * (Math.PI / 180);
        const x = 100 + Math.cos(angle) * 14;
        const y = 100 + Math.sin(angle) * 14;
        return (
          <g key={i}>
            <line
              x1="100"
              y1="100"
              x2={x}
              y2={y}
              stroke="#fb923c"
              strokeWidth="2"
              opacity="0.6"
            />
            <circle cx={x} cy={y} r="3" fill="#dc2626"/>
            <circle cx={x} cy={y} r="2" fill="#fca5a5"/>
            <circle cx={x - 0.5} cy={y - 0.5} r="1" fill="white" opacity="0.7"/>
          </g>
        );
      })}
      
      {/* 花心中心 */}
      <circle cx="100" cy="100" r="8" fill="#fb923c"/>
      <circle cx="100" cy="100" r="6" fill="#f97316"/>
      <circle cx="97" cy="97" r="3" fill="#fef3c7" opacity="0.8"/>
    </svg>
  );
}

// 飘落的花瓣 - 更精细
function FallingPetal({ delay = 0, x = 0 }: { delay?: number; x?: number }) {
  const id = `petal-${Math.random()}`;
  return (
    <motion.svg
      width="40"
      height="50"
      viewBox="0 0 40 50"
      fill="none"
      className="absolute"
      style={{ left: `${x}%`, top: '-5%' }}
      initial={{ opacity: 0, rotate: 0, y: 0 }}
      animate={{
        opacity: [0, 0.9, 0.8, 0],
        rotate: [0, 360 + Math.random() * 180],
        y: [0, window.innerHeight + 100],
        x: [0, (Math.random() - 0.5) * 150],
      }}
      transition={{
        duration: 4 + Math.random() * 3,
        delay,
        ease: 'linear',
      }}
    >
      <defs>
        <radialGradient id={id}>
          <stop offset="0%" stopColor="#fce7f3" />
          <stop offset="60%" stopColor="#fda4af" />
          <stop offset="100%" stopColor="#fb7185" />
        </radialGradient>
      </defs>
      
      <ellipse
        cx="20"
        cy="25"
        rx="16"
        ry="22"
        fill={`url(#${id})`}
        stroke="#f43f5e"
        strokeWidth="1.5"
        opacity="0.95"
      />
      <path
        d="M 20 5 Q 20 25, 20 45"
        stroke="#fda4af"
        strokeWidth="1.5"
        opacity="0.3"
      />
      <ellipse
        cx="14"
        cy="16"
        rx="5"
        ry="8"
        fill="white"
        opacity="0.4"
      />
    </motion.svg>
  );
}

// 蝴蝶 - 新增元素
function Butterfly({ delay = 0, side = 'left' }: { delay?: number; side?: 'left' | 'right' }) {
  return (
    <motion.svg
      width="50"
      height="50"
      viewBox="0 0 50 50"
      fill="none"
      className="absolute top-1/3"
      style={{ [side]: '10%' }}
      initial={{ opacity: 0, scale: 0 }}
      animate={{
        opacity: [0, 1, 1, 0],
        scale: [0, 1, 1, 0.8],
        y: [0, -30, -60],
        x: side === 'left' ? [0, 40, 80] : [0, -40, -80],
      }}
      transition={{ duration: 3, delay, ease: 'easeInOut' }}
    >
      <defs>
        <radialGradient id={`butterfly${side}`}>
          <stop offset="0%" stopColor="#fef08a" />
          <stop offset="50%" stopColor="#fde047" />
          <stop offset="100%" stopColor="#facc15" />
        </radialGradient>
      </defs>
      
      {/* 左翅膀 */}
      <ellipse
        cx="18"
        cy="20"
        rx="12"
        ry="16"
        fill={`url(#butterfly${side})`}
        stroke="#ca8a04"
        strokeWidth="1.5"
        transform="rotate(-20, 18, 20)"
      />
      <ellipse cx="15" cy="15" rx="4" ry="6" fill="white" opacity="0.5"/>
      <circle cx="20" cy="25" r="3" fill="#dc2626"/>
      
      {/* 右翅膀 */}
      <ellipse
        cx="32"
        cy="20"
        rx="12"
        ry="16"
        fill={`url(#butterfly${side})`}
        stroke="#ca8a04"
        strokeWidth="1.5"
        transform="rotate(20, 32, 20)"
      />
      <ellipse cx="35" cy="15" rx="4" ry="6" fill="white" opacity="0.5"/>
      <circle cx="30" cy="25" r="3" fill="#dc2626"/>
      
      {/* 身体 */}
      <ellipse cx="25" cy="22" rx="3" ry="12" fill="#78350f"/>
      <circle cx="25" cy="15" r="3.5" fill="#78350f"/>
      
      {/* 触角 */}
      <path d="M 25 15 Q 22 10, 20 8" stroke="#78350f" strokeWidth="1.5" fill="none"/>
      <path d="M 25 15 Q 28 10, 30 8" stroke="#78350f" strokeWidth="1.5" fill="none"/>
      <circle cx="20" cy="8" r="1.5" fill="#78350f"/>
      <circle cx="30" cy="8" r="1.5" fill="#78350f"/>
    </motion.svg>
  );
}

// 闪光星星 - 更精细
function SparkleEffect({ delay = 0, x = 0, y = 0 }: { delay?: number; x?: number; y?: number }) {
  return (
    <motion.svg
      width="40"
      height="40"
      viewBox="0 0 40 40"
      className="absolute"
      style={{ left: `${x}%`, top: `${y}%` }}
      initial={{ opacity: 0, scale: 0, rotate: 0 }}
      animate={{
        opacity: [0, 1, 0],
        scale: [0, 1.5, 0],
        rotate: [0, 180],
      }}
      transition={{
        duration: 2,
        delay,
        repeat: Infinity,
        repeatDelay: Math.random() * 4,
      }}
    >
      <defs>
        <radialGradient id={`sparkle${x}${y}`}>
          <stop offset="0%" stopColor="#fef9c3" />
          <stop offset="50%" stopColor="#fde047" />
          <stop offset="100%" stopColor="#facc15" />
        </radialGradient>
      </defs>
      
      <path
        d="M 20 5 L 22 18 L 35 20 L 22 22 L 20 35 L 18 22 L 5 20 L 18 18 Z"
        fill={`url(#sparkle${x}${y})`}
        stroke="#f59e0b"
        strokeWidth="1.5"
      />
      <circle cx="20" cy="20" r="4" fill="white" opacity="0.8"/>
    </motion.svg>
  );
}

export function CelebrationAnimation({ 
  isVisible, 
  onComplete, 
  userName = "照顾者" 
}: CelebrationAnimationProps) {
  const [stage, setStage] = useState<'watering' | 'blooming' | 'celebrating'>('watering');
  const [petals, setPetals] = useState<number[]>([]);

  useEffect(() => {
    if (!isVisible) {
      setStage('watering');
      setPetals([]);
      return;
    }

    const timeline = [
      { delay: 2500, action: () => setStage('blooming') },
      { delay: 5000, action: () => setStage('celebrating') },
      { delay: 8000, action: onComplete },
    ];

    const timers = timeline.map(({ delay, action }) => 
      setTimeout(action, delay)
    );

    const petalTimer = setTimeout(() => {
      setPetals(Array.from({ length: 30 }, (_, i) => i));
    }, 4500);

    return () => {
      timers.forEach(clearTimeout);
      clearTimeout(petalTimer);
    };
  }, [isVisible, onComplete]);

  if (!isVisible) return null;

  return (
    <AnimatePresence>
      <motion.div
        className="fixed inset-0 z-50 flex items-center justify-center bg-gradient-to-br from-pink-50/98 via-rose-50/98 to-orange-50/98 backdrop-blur-sm overflow-hidden"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        transition={{ duration: 0.6 }}
      >
        {/* 背景闪光效果 */}
        {[...Array(15)].map((_, i) => (
          <SparkleEffect
            key={i}
            delay={Math.random() * 3}
            x={Math.random() * 100}
            y={Math.random() * 100}
          />
        ))}

        {/* 飘落的花瓣 */}
        {petals.map((index) => (
          <FallingPetal
            key={index}
            delay={Math.random() * 1.5}
            x={Math.random() * 100}
          />
        ))}

        {/* 蝴蝶 */}
        {stage === 'celebrating' && (
          <>
            <Butterfly delay={0.5} side="left" />
            <Butterfly delay={1} side="right" />
          </>
        )}

        <div className="relative flex flex-col items-center">
          {/* 浇水罐动画 */}
          <AnimatePresence mode="wait">
            {stage === 'watering' && (
              <motion.div
                className="absolute -top-48 left-1/2"
                initial={{ x: '-50%', y: -80, opacity: 0, rotate: -45 }}
                animate={{ 
                  x: '-50%', 
                  y: 0, 
                  opacity: 1, 
                  rotate: 35,
                }}
                exit={{ opacity: 0, y: -80, transition: { duration: 0.5 } }}
                transition={{ duration: 1.2, ease: 'easeOut' }}
              >
                <WateringCan />
                
                {/* 水滴 */}
                <div className="absolute top-32 left-20">
                  {[0, 1, 2, 3, 4, 5, 6].map((i) => (
                    <div
                      key={i}
                      className="absolute"
                      style={{
                        left: `${i * 10 - 25}px`,
                      }}
                    >
                      <WaterDrop delay={0.3 + i * 0.2} />
                    </div>
                  ))}
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          {/* 花盆 */}
          <div className="relative z-10">
            <motion.div
              initial={{ scale: 0.7, opacity: 0, y: 30 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              transition={{ duration: 1, ease: 'easeOut' }}
            >
              <FlowerPot />
            </motion.div>

            {/* 成长的花 */}
            <motion.div
              className="absolute -top-40 left-1/2 -translate-x-1/2"
              initial={{ scale: 0, y: 100, opacity: 0 }}
              animate={
                stage === 'watering'
                  ? { scale: 0, y: 100, opacity: 0 }
                  : stage === 'blooming'
                  ? { 
                      scale: [0, 1.4, 1], 
                      y: [100, -20, 0], 
                      opacity: 1, 
                      rotate: [0, -20, 12, -8, 0] 
                    }
                  : { scale: 1, y: 0, opacity: 1 }
              }
              transition={{
                duration: 2,
                ease: [0.34, 1.56, 0.64, 1],
                times: [0, 0.6, 1],
              }}
            >
              <motion.div
                animate={
                  stage === 'celebrating'
                    ? {
                        scale: [1, 1.08, 1],
                        rotate: [0, -4, 4, -4, 0],
                      }
                    : {}
                }
                transition={{
                  duration: 3,
                  repeat: Infinity,
                  ease: 'easeInOut',
                }}
              >
                <PeachBlossom size="large" />
              </motion.div>

              {/* 周围的小花 */}
              {stage === 'celebrating' && (
                <>
                  {[0, 1, 2, 3, 4, 5].map((i) => (
                    <motion.div
                      key={i}
                      className="absolute top-1/2 left-1/2"
                      initial={{ 
                        x: '-50%', 
                        y: '-50%', 
                        opacity: 0, 
                        scale: 0 
                      }}
                      animate={{
                        x: `${Math.cos((i * 60 * Math.PI) / 180) * 140 - 50}%`,
                        y: `${Math.sin((i * 60 * Math.PI) / 180) * 140 - 50}%`,
                        opacity: [0, 1, 1, 0.9],
                        scale: [0, 1.5, 1],
                        rotate: [0, 360],
                      }}
                      transition={{
                        duration: 1.8,
                        delay: i * 0.2,
                        ease: 'easeOut',
                      }}
                    >
                      <PeachBlossom size="small" />
                    </motion.div>
                  ))}
                </>
              )}
            </motion.div>
          </div>

          {/* 鼓励文字 */}
          <motion.div
            className="mt-32 text-center px-8 relative z-20"
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: stage === 'celebrating' ? 0.8 : 2.2 }}
          >
            <motion.h2
              className="text-5xl font-bold bg-gradient-to-r from-pink-500 via-rose-500 to-orange-500 bg-clip-text text-transparent mb-6 drop-shadow-sm"
              animate={{
                scale: stage === 'celebrating' ? [1, 1.06, 1] : 1,
              }}
              transition={{
                duration: 1.5,
                repeat: stage === 'celebrating' ? Infinity : 0,
              }}
            >
              {stage === 'watering' && '正在给爱浇水...'}
              {stage === 'blooming' && '爱在绽放！'}
              {stage === 'celebrating' && '打卡完成！'}
            </motion.h2>

            {stage === 'celebrating' && (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 1.3 }}
                className="space-y-5"
              >
                <p className="text-3xl text-gray-700 font-bold drop-shadow-sm">
                  {userName}，你真棒！
                </p>
                <p className="text-xl text-gray-600 max-w-lg mx-auto leading-relaxed px-6">
                  每一次用心的照顾，<br />
                  都像是给花浇水，<br />
                  让爱的花朵更加灿烂盛开
                </p>
              </motion.div>
            )}
          </motion.div>

          {/* 底部光圈效果 - 更大更柔和 */}
          {stage === 'celebrating' && (
            <>
              <motion.div
                className="absolute -bottom-40 left-1/2 -translate-x-1/2 w-[600px] h-[600px] bg-gradient-to-r from-pink-300/50 via-rose-300/50 to-orange-300/50 rounded-full blur-3xl"
                animate={{
                  scale: [1, 1.4, 1],
                  opacity: [0.3, 0.6, 0.3],
                }}
                transition={{
                  duration: 4,
                  repeat: Infinity,
                  ease: 'easeInOut',
                }}
              />
              <motion.div
                className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[400px] h-[400px] bg-gradient-to-r from-yellow-200/40 via-orange-200/40 to-pink-200/40 rounded-full blur-3xl"
                animate={{
                  scale: [1.2, 1, 1.2],
                  opacity: [0.2, 0.4, 0.2],
                  rotate: [0, 360],
                }}
                transition={{
                  duration: 8,
                  repeat: Infinity,
                  ease: 'linear',
                }}
              />
            </>
          )}
        </div>
      </motion.div>
    </AnimatePresence>
  );
}
