import { Outlet, NavLink } from 'react-router';
import { Home, Sparkles, HeartPulse, NotebookPen, Users } from 'lucide-react';
import { motion } from 'motion/react';

export function Layout() {
  const navItems = [
    { path: '/', icon: Home, label: '首页', color: 'from-orange-400 via-rose-400 to-pink-500' },
    { path: '/checkin', icon: Sparkles, label: '每日打卡', color: 'from-green-400 via-emerald-400 to-teal-500' },
    { path: '/medication', icon: HeartPulse, label: '用药', color: 'from-pink-400 via-rose-400 to-red-500' },
    { path: '/diary', icon: NotebookPen, label: '日记', color: 'from-blue-400 via-cyan-400 to-sky-500' },
    { path: '/share', icon: Users, label: '家人', color: 'from-purple-400 via-violet-400 to-fuchsia-500' },
  ];

  return (
    <div className="size-full bg-gradient-to-br from-orange-50 via-pink-50 to-purple-50 overflow-hidden">
      {/* 移动端容器 */}
      <div className="max-w-md mx-auto h-full bg-white shadow-2xl flex flex-col relative">
        
        {/* 主内容区域 */}
        <div className="flex-1 overflow-auto pb-28">
          <Outlet />
        </div>

        {/* 底部导航栏 */}
        <motion.div 
          className="fixed bottom-0 left-0 right-0 max-w-md mx-auto bg-white shadow-[0_-4px_20px_rgba(0,0,0,0.1)] rounded-t-3xl z-50"
          initial={{ y: 100 }}
          animate={{ y: 0 }}
          transition={{ duration: 0.5, delay: 0.2 }}
        >
          {/* 顶部装饰条 */}
          <div className="absolute top-0 left-1/2 -translate-x-1/2 w-12 h-1 bg-gray-300 rounded-full mt-2" />
          
          <div className="flex items-center justify-around px-2 py-4 pt-6">
            {navItems.map((item) => {
              const IconComponent = item.icon;
              return (
                <NavLink
                  key={item.path}
                  to={item.path}
                  end={item.path === '/'}
                >
                  {({ isActive }) => (
                    <motion.div
                      className={`relative flex flex-col items-center gap-2 transition-all ${
                        isActive ? 'px-5 py-2.5' : 'px-0 py-0'
                      }`}
                      layout
                      transition={{ type: 'spring', bounce: 0.2, duration: 0.6 }}
                    >
                      {/* 活跃状态：大圆角矩形 */}
                      {isActive && (
                        <motion.div
                          layoutId="activeBackground"
                          className={`absolute inset-0 bg-gradient-to-br ${item.color} rounded-3xl shadow-lg`}
                          transition={{ type: 'spring', bounce: 0.2, duration: 0.6 }}
                        />
                      )}
                      
                      {/* 非活跃状态：小圆形 */}
                      {!isActive && (
                        <div className="w-12 h-12 rounded-full bg-gray-100 flex items-center justify-center">
                          <IconComponent className="w-5 h-5 text-gray-600" strokeWidth={2} />
                        </div>
                      )}
                      
                      {/* 活跃状态：图标 */}
                      {isActive && (
                        <div className="relative z-10">
                          <IconComponent className="w-5 h-5 text-white" strokeWidth={2.5} />
                        </div>
                      )}
                      
                      {/* 标签文字 */}
                      <span
                        className={`relative z-10 text-[11px] font-medium whitespace-nowrap ${
                          isActive ? 'text-white' : 'text-gray-600'
                        }`}
                      >
                        {item.label}
                      </span>
                      
                      {/* 顶部装饰圆点 */}
                      {isActive && (
                        <motion.div
                          className="absolute -top-1.5 left-1/2 -translate-x-1/2 w-1.5 h-1.5 bg-white rounded-full"
                          initial={{ scale: 0 }}
                          animate={{ scale: 1 }}
                          transition={{ type: 'spring', bounce: 0.5, delay: 0.1 }}
                        />
                      )}
                    </motion.div>
                  )}
                </NavLink>
              );
            })}
          </div>
        </motion.div>
      </div>
    </div>
  );
}