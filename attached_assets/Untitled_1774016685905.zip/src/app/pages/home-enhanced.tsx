import { useEffect, useState } from 'react';
import { motion, useAnimation } from 'motion/react';
import { Link } from 'react-router';
import { 
  ChevronRight, 
  Sparkles, 
  Pill, 
  BookHeart, 
  Users, 
  Brain,
  User,
  CheckCircle2,
  ClipboardList,
} from 'lucide-react';
import { getTodayCheckIn, getRecentCheckIns, getProfile, DailyCheckIn } from '@/lib/storage';
import { getDayGreeting, getRandomTip, getEncouragement } from '@/lib/care-knowledge';

// ═══════════════════════════════════════════════════════════════
// 优化后的云朵 - 更真实的浮动 + 呼吸效果
// ═══════════════════════════════════════════════════════════════
function CloudDecoration({ delay = 0, className = '', size = 1 }: { delay?: number; className?: string; size?: number }) {
  return (
    <motion.svg
      width={80 * size}
      height={50 * size}
      viewBox="0 0 80 50"
      className={className}
      initial={{ opacity: 0, x: -20, scale: 0.9 }}
      animate={{ 
        opacity: 0.7,
        x: 0,
        y: [0, -12, 0],
        scale: [0.9, 1.05],
      }}
      transition={{ 
        opacity: { duration: 1.5, delay },
        x: { duration: 1.5, delay },
        y: { duration: 5, repeat: Infinity, ease: 'easeInOut', delay },
        scale: { duration: 4, repeat: Infinity, ease: 'easeInOut', delay: delay + 1, repeatType: 'reverse' },
      }}
    >
      <defs>
        <filter id={`cloudShadow${delay}`}>
          <feGaussianBlur in="SourceAlpha" stdDeviation="3"/>
          <feOffset dx="0" dy="2" result="offsetblur"/>
          <feComponentTransfer>
            <feFuncA type="linear" slope="0.15"/>
          </feComponentTransfer>
          <feMerge>
            <feMergeNode/>
            <feMergeNode in="SourceGraphic"/>
          </feMerge>
        </filter>
      </defs>
      <g filter={`url(#cloudShadow${delay})`}>
        <circle cx="25" cy="30" r="15" fill="white" opacity="0.95"/>
        <circle cx="40" cy="25" r="18" fill="white" opacity="0.95"/>
        <circle cx="55" cy="30" r="14" fill="white" opacity="0.95"/>
        <ellipse cx="40" cy="35" rx="30" ry="12" fill="white" opacity="0.95"/>
      </g>
    </motion.svg>
  );
}

// ═══════════════════════════════════════════════════════════════
// 新增：小花飘落装饰（细腻不干扰）
// ═══════════════════════════════════════════════════════════════
function FloatingFlower({ delay = 0, startX = 0 }: { delay?: number; startX?: number }) {
  const flowers = ['🌸', '🌼', '🌺', '🌻', '🏵️'];
  const flower = flowers[Math.floor(Math.random() * flowers.length)];
  
  return (
    <motion.div
      className="absolute text-2xl pointer-events-none"
      style={{ left: startX, top: -40 }}
      initial={{ opacity: 0, y: -40, rotate: 0 }}
      animate={{ 
        opacity: [0, 0.5, 0.5, 0],
        y: [0, 120],
        rotate: [0, 360],
        x: [0, (Math.random() - 0.5) * 40],
      }}
      transition={{ 
        duration: 6,
        delay,
        repeat: Infinity,
        repeatDelay: Math.random() * 8 + 4,
        ease: 'easeInOut',
      }}
    >
      {flower}
    </motion.div>
  );
}

// ═══════════════════════════════════════════════════════════════
// 新增：闪烁的星星（更明显）
// ═══════════════════════════════════════════════════════════════
function TwinklingStar({ delay = 0, className = '' }: { delay?: number; className?: string }) {
  return (
    <motion.div
      className={className}
      initial={{ opacity: 0, scale: 0 }}
      animate={{ 
        opacity: [0, 0.4, 1, 0.4, 0.8],
        scale: [0, 1, 1.3, 1, 1.2],
        rotate: [0, 180, 360],
      }}
      transition={{ 
        duration: 3,
        delay,
        repeat: Infinity,
        ease: 'easeInOut',
      }}
    >
      <Sparkles className="w-5 h-5 text-yellow-400 drop-shadow-lg" />
    </motion.div>
  );
}

// ═══════════════════════════════════════════════════════════════
// 新增：气球缓慢上升装饰
// ═══════════════════════════════════════════════════════════════
function FloatingBalloon({ delay = 0, startX = 0 }: { delay?: number; startX?: number }) {
  const balloons = ['🎈', '🎀', '🧸'];
  const balloon = balloons[Math.floor(Math.random() * balloons.length)];
  
  return (
    <motion.div
      className="absolute text-xl pointer-events-none"
      style={{ left: startX, bottom: -40 }}
      initial={{ opacity: 0, y: 0 }}
      animate={{ 
        opacity: [0, 0.6, 0.6, 0],
        y: [0, -200],
        x: [0, Math.sin(delay) * 20, 0],
      }}
      transition={{ 
        duration: 10,
        delay,
        repeat: Infinity,
        repeatDelay: Math.random() * 6 + 3,
        ease: 'easeOut',
      }}
    >
      {balloon}
    </motion.div>
  );
}

// ═══════════════════════════════════════════════════════════════
// 优化：漂浮的爱心（更细腻）
// ═══════════════════════════════════════════════════════════════
function FloatingHeart({ delay = 0, startX = 0 }: { delay?: number; startX?: number }) {
  return (
    <motion.div
      className="absolute text-lg pointer-events-none"
      style={{ left: startX, bottom: 0 }}
      initial={{ opacity: 0, y: 0 }}
      animate={{ 
        opacity: [0, 0.4, 0.4, 0],
        y: [0, -100],
        x: [0, (Math.random() - 0.5) * 30],
        scale: [1, 1.2, 1],
      }}
      transition={{ 
        duration: 5,
        delay,
        repeat: Infinity,
        repeatDelay: Math.random() * 4 + 2,
        ease: 'easeInOut',
      }}
    >
      💗
    </motion.div>
  );
}

// ═══════════════════════════════════════════════════════════════
// 彩色小太阳装饰（增强旋转）
// ═══════════════════════════════════════════════════════════════
function MiniSunDecoration({ delay = 0, className = '' }: { delay?: number; className?: string }) {
  return (
    <motion.div
      className={className}
      initial={{ opacity: 0, scale: 0, rotate: 0 }}
      animate={{ 
        opacity: 0.8,
        scale: 1,
        rotate: [0, 360]
      }}
      transition={{ 
        opacity: { duration: 1, delay },
        scale: { duration: 1, delay, type: 'spring', bounce: 0.5 },
        rotate: { duration: 25, delay, repeat: Infinity, ease: 'linear' }
      }}
    >
      <svg width="45" height="45" viewBox="0 0 50 50">
        <defs>
          <radialGradient id={`sunGrad${delay}`}>
            <stop offset="0%" stopColor="#fef08a" />
            <stop offset="100%" stopColor="#fde047" />
          </radialGradient>
        </defs>
        
        {/* 光芒 */}
        {[...Array(8)].map((_, i) => {
          const angle = (i * 45) * (Math.PI / 180);
          const x1 = 25 + Math.cos(angle) * 12;
          const y1 = 25 + Math.sin(angle) * 12;
          const x2 = 25 + Math.cos(angle) * 20;
          const y2 = 25 + Math.sin(angle) * 20;
          return (
            <motion.line
              key={i}
              x1={x1}
              y1={y1}
              x2={x2}
              y2={y2}
              stroke="#fbbf24"
              strokeWidth="3"
              strokeLinecap="round"
              animate={{ 
                strokeWidth: [3, 4],
                opacity: [0.6, 1]
              }}
              transition={{ 
                duration: 1.5, 
                repeat: Infinity,
                repeatType: 'reverse',
                delay: i * 0.15
              }}
            />
          );
        })}
        
        {/* 太阳主体 */}
        <circle cx="25" cy="25" r="10" fill={`url(#sunGrad${delay})`}/>
        <circle cx="22" cy="22" r="3" fill="white" opacity="0.7"/>
      </svg>
    </motion.div>
  );
}

// ═══════════════════════════════════════════════════════════════
// 趋势图心情条
// ═══════════════════════════════════════════════════════════════
function MoodBar({ score, date }: { score: number; date: string }) {
  const height = Math.max(12, (score / 10) * 56);
  const color = score >= 7 ? '#10b981' : score >= 4 ? '#f59e0b' : '#ef4444';
  const day = new Date(date).toLocaleDateString('zh-CN', { weekday: 'short' }).replace('周', '');
  
  return (
    <div className="flex flex-col items-center gap-2 flex-1">
      <div className="w-3 h-16 bg-gradient-to-t from-gray-100 to-gray-50 rounded-full flex items-end overflow-hidden shadow-inner">
        <motion.div
          className="w-full rounded-full shadow-sm"
          style={{ backgroundColor: color }}
          initial={{ height: 0 }}
          animate={{ height }}
          transition={{ duration: 0.8, delay: 0.1, ease: 'easeOut', type: 'spring' }}
        />
      </div>
      <span className="text-xs font-medium text-gray-500">{day}</span>
    </div>
  );
}

export function HomeEnhancedPage() {
  const [greeting, setGreeting] = useState('');
  const [tip, setTip] = useState<{ category: string; icon: string; tip: string } | null>(null);
  const [todayCheckIn, setTodayCheckIn] = useState<DailyCheckIn | null>(null);
  const [recentMoods, setRecentMoods] = useState<DailyCheckIn[]>([]);

  useEffect(() => {
    loadData();
  }, []);

  async function loadData() {
    const profile = await getProfile();
    setGreeting(getDayGreeting(profile?.nickname || profile?.caregiverName));
    setTip(getRandomTip());
    
    const today = await getTodayCheckIn();
    setTodayCheckIn(today);
    
    const recent = await getRecentCheckIns(7);
    setRecentMoods(recent.slice(0, 7).reverse());
  }

  const todayDone = todayCheckIn?.morningDone || todayCheckIn?.eveningDone;
  const encouragement = todayCheckIn
    ? getEncouragement(todayCheckIn.moodScore)
    : '今天还没有打卡哦，点击下方开始记录吧 🌸';

  const quickActions = [
    { 
      icon: Pill, 
      label: '用药提醒', 
      path: '/medication', 
      iconBg: 'from-pink-400 to-rose-500',
      bgColor: 'from-pink-50 to-rose-50',
      emoji: '💊'
    },
    { 
      icon: BookHeart, 
      label: '护理日记', 
      path: '/diary', 
      iconBg: 'from-blue-400 to-cyan-500',
      bgColor: 'from-blue-50 to-cyan-50',
      emoji: '📖'
    },
    { 
      icon: Users, 
      label: '家庭共享', 
      path: '/share', 
      iconBg: 'from-purple-400 to-pink-500',
      bgColor: 'from-purple-50 to-pink-50',
      emoji: '👨‍👩‍👧'
    },
    { 
      icon: Brain, 
      label: 'AI 助手', 
      path: '/assistant', 
      iconBg: 'from-emerald-400 to-green-500',
      bgColor: 'from-emerald-50 to-green-50',
      emoji: '🤖'
    },
  ];

  return (
    <div className="px-5 py-6 pb-24 bg-gradient-to-br from-orange-50/50 via-rose-50/50 to-pink-50/50 min-h-screen relative overflow-hidden">
      {/* ═══════════════════════════════════════════════════════════════
          背景装饰层 - 优化后的动画
      ═══════════════════════════════════════════════════════════════ */}
      
      {/* 云朵 - 3朵，不同大小和延迟 */}
      <CloudDecoration delay={0} className="absolute top-8 left-2" size={0.9} />
      <CloudDecoration delay={0.6} className="absolute top-20 right-8" size={0.75} />
      <CloudDecoration delay={1.2} className="absolute top-36 left-1/3" size={1} />
      
      {/* 闪烁星星 - 4颗 */}
      <TwinklingStar delay={0.3} className="absolute top-12 right-24" />
      <TwinklingStar delay={0.8} className="absolute top-28 left-16" />
      <TwinklingStar delay={1.4} className="absolute top-44 right-12" />
      <TwinklingStar delay={2} className="absolute top-52 left-1/2" />
      
      {/* 小花飘落 - 5朵 */}
      <FloatingFlower delay={1} startX={60} />
      <FloatingFlower delay={2.5} startX={180} />
      <FloatingFlower delay={4} startX={280} />
      <FloatingFlower delay={5.5} startX={140} />
      <FloatingFlower delay={7} startX={320} />
      
      {/* 气球上升 - 3个 */}
      <FloatingBalloon delay={2} startX={80} />
      <FloatingBalloon delay={5} startX={240} />
      <FloatingBalloon delay={8} startX={300} />
      
      {/* 爱心漂浮 - 6个 */}
      {[60, 120, 200, 260, 340, 30].map((x, i) => (
        <FloatingHeart key={i} delay={i * 1.5} startX={x} />
      ))}

      {/* ═══════════════════════════════════════════════════════════════
          主内容区
      ═══════════════════════════════════════════════════════════════ */}
      
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
        className="relative z-10"
      >
        {/* 顶部问候区 */}
        <div className="relative mb-6">
          <motion.div
            className="bg-gradient-to-br from-white/95 via-white/90 to-white/85 backdrop-blur-xl rounded-3xl p-6 shadow-2xl border-2 border-white/70 relative overflow-hidden"
            initial={{ opacity: 0, y: -30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, type: 'spring' }}
            whileHover={{ scale: 1.01, y: -2 }}
          >
            {/* 小太阳装饰 */}
            <MiniSunDecoration delay={0.3} className="absolute top-3 right-3" />
            <MiniSunDecoration delay={0.6} className="absolute bottom-3 left-3" />
            
            {/* 背景光晕 */}
            <motion.div
              className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-64 h-64 rounded-full bg-gradient-to-br from-orange-200/20 via-rose-200/20 to-pink-200/20 blur-3xl"
              animate={{ 
                scale: [1, 1.2, 1],
                opacity: [0.3, 0.5, 0.3],
                rotate: [0, 90, 0]
              }}
              transition={{ duration: 8, repeat: Infinity }}
            />
            
            <div className="flex items-start justify-between relative z-10">
              <div className="flex-1">
                <motion.div 
                  className="flex items-center gap-2 mb-2"
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.2 }}
                >
                  <h1 className="text-2xl font-bold bg-gradient-to-r from-orange-600 via-rose-600 to-pink-600 bg-clip-text text-transparent">
                    我们一起照顾好今天
                  </h1>
                  <motion.div
                    animate={{ 
                      rotate: [0, 12, -12, 12, 0],
                      scale: [1, 1.3, 1.3, 1.3, 1]
                    }}
                    transition={{ 
                      duration: 2,
                      repeat: Infinity,
                      repeatDelay: 3
                    }}
                  >
                    <span className="text-2xl">✨</span>
                  </motion.div>
                </motion.div>
                <motion.p 
                  className="text-sm text-gray-600 font-medium"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ delay: 0.3 }}
                >
                  {greeting || '加载中...'}
                </motion.p>
              </div>
              
              <Link to="/profile">
                <motion.div
                  className="w-16 h-16 rounded-2xl bg-gradient-to-br from-orange-300 via-rose-300 to-pink-300 flex items-center justify-center shadow-xl border-3 border-white relative overflow-hidden"
                  whileHover={{ scale: 1.1, rotate: 8 }}
                  whileTap={{ scale: 0.95 }}
                  initial={{ opacity: 0, scale: 0.8, rotate: -15 }}
                  animate={{ opacity: 1, scale: 1, rotate: 0 }}
                  transition={{ delay: 0.5, type: 'spring', bounce: 0.6 }}
                >
                  {/* 头像装饰光圈 */}
                  <motion.div
                    className="absolute inset-0 rounded-2xl bg-gradient-to-br from-yellow-300/50 to-pink-300/50"
                    animate={{ 
                      scale: [1, 1.3, 1],
                      opacity: [0.4, 0.7, 0.4]
                    }}
                    transition={{ 
                      duration: 2,
                      repeat: Infinity
                    }}
                  />
                  <User className="w-8 h-8 text-white relative z-10" strokeWidth={2.5} />
                </motion.div>
              </Link>
            </div>
          </motion.div>
        </div>

        {/* 今日打卡横幅 */}
        <Link to="/checkin">
          <motion.div
            className={`rounded-3xl p-6 shadow-2xl mb-5 relative overflow-hidden border-3 ${
              todayDone 
                ? 'bg-gradient-to-br from-green-50 via-emerald-50 to-teal-50 border-green-200/80' 
                : 'bg-gradient-to-br from-green-400 via-emerald-500 to-teal-500 border-green-300/60'
            }`}
            whileHover={{ scale: 1.02, y: -5 }}
            whileTap={{ scale: 0.98 }}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2, type: 'spring' }}
          >
            {/* 背景装饰波浪 */}
            {!todayDone && (
              <>
                <motion.div 
                  className="absolute top-0 right-0 w-40 h-40 bg-white/15 rounded-full -mr-20 -mt-20"
                  animate={{ 
                    scale: [1, 1.4, 1], 
                    opacity: [0.3, 0.2, 0.3],
                    rotate: [0, 120, 0]
                  }}
                  transition={{ duration: 6, repeat: Infinity }}
                />
                <motion.div 
                  className="absolute bottom-0 left-0 w-32 h-32 bg-white/15 rounded-full -ml-16 -mb-16"
                  animate={{ 
                    scale: [1, 1.5, 1], 
                    opacity: [0.2, 0.3, 0.2],
                    rotate: [0, -120, 0]
                  }}
                  transition={{ duration: 5, repeat: Infinity, delay: 1 }}
                />
                {/* 星星闪烁装饰 */}
                {[...Array(6)].map((_, i) => (
                  <motion.div
                    key={i}
                    className="absolute"
                    style={{
                      top: `${20 + Math.random() * 60}%`,
                      left: `${10 + Math.random() * 80}%`
                    }}
                    animate={{
                      scale: [0, 1.2, 0],
                      rotate: [0, 180],
                      opacity: [0, 1, 0]
                    }}
                    transition={{
                      duration: 2.5,
                      delay: i * 0.5,
                      repeat: Infinity,
                      repeatDelay: 2
                    }}
                  >
                    <Sparkles className="w-4 h-4 text-white" />
                  </motion.div>
                ))}
              </>
            )}
            
            <div className="relative flex items-center gap-4">
              <motion.div 
                className={`w-20 h-20 rounded-2xl flex items-center justify-center shadow-xl border-2 border-white/40 ${
                  todayDone ? 'bg-gradient-to-br from-green-200 to-emerald-300' : 'bg-white/30 backdrop-blur-md'
                }`}
                animate={!todayDone ? {
                  scale: [1, 1.08, 1],
                  rotate: [0, 5, -5, 0]
                } : {}}
                transition={{ 
                  duration: 2.5,
                  repeat: !todayDone ? Infinity : 0
                }}
              >
                {todayDone ? (
                  <CheckCircle2 className="w-10 h-10 text-green-600" strokeWidth={2.5} />
                ) : (
                  <ClipboardList className="w-10 h-10 text-white" strokeWidth={2} />
                )}
              </motion.div>
              
              <div className="flex-1">
                <h3 className={`text-xl font-bold mb-1 ${todayDone ? 'text-gray-800' : 'text-white drop-shadow-md'}`}>
                  {todayDone ? '今日打卡已完成 ✓' : '开始今日打卡'}
                </h3>
                <p className={`text-sm ${todayDone ? 'text-gray-600' : 'text-white/95 drop-shadow-sm'}`}>
                  {todayDone
                    ? `心情 ${todayCheckIn?.moodEmoji ?? ''} · 睡眠 ${todayCheckIn?.sleepHours ?? 0}小时`
                    : '每天3个问题，记录老宝的状态'}
                </p>
              </div>
              
              <ChevronRight className={`w-7 h-7 ${todayDone ? 'text-gray-400' : 'text-white/90'}`} />
            </div>
          </motion.div>
        </Link>

        {/* AI 护理预测卡片 */}
        <Link to="/assistant">
          <motion.div
            className="bg-gradient-to-br from-purple-50 via-violet-50 to-purple-50 rounded-3xl p-6 shadow-2xl border-3 border-purple-100/80 mb-5 relative overflow-hidden"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.3, type: 'spring' }}
            whileHover={{ scale: 1.02, y: -4 }}
            whileTap={{ scale: 0.98 }}
          >
            {/* 背景装饰光晕 */}
            <motion.div 
              className="absolute top-0 right-0 w-48 h-48 rounded-full bg-gradient-to-br from-purple-300/20 to-pink-300/20 blur-3xl -mr-24 -mt-24"
              animate={{ 
                scale: [1, 1.3, 1],
                rotate: [0, 90, 0]
              }}
              transition={{ duration: 10, repeat: Infinity }}
            />
            <motion.div 
              className="absolute bottom-0 left-0 w-40 h-40 rounded-full bg-gradient-to-br from-blue-300/20 to-purple-300/20 blur-3xl -ml-20 -mb-20"
              animate={{ 
                scale: [1, 1.4, 1],
                rotate: [0, -90, 0]
              }}
              transition={{ duration: 8, repeat: Infinity }}
            />
            
            <div className="relative">
              <div className="flex items-center gap-3 mb-4">
                <motion.div 
                  className="w-14 h-14 rounded-2xl bg-gradient-to-br from-purple-400 to-violet-500 flex items-center justify-center shadow-xl"
                  animate={{
                    scale: [1, 1.15, 1],
                    rotate: [0, 8, -8, 0]
                  }}
                  transition={{ duration: 4, repeat: Infinity }}
                >
                  <Sparkles className="w-7 h-7 text-white" strokeWidth={2.5} />
                </motion.div>
                <div>
                  <h3 className="text-purple-800 font-bold text-lg">AI 今日护理预测</h3>
                  <p className="text-xs text-purple-600">老宝的阿兹海默护理建议 · 每日更新</p>
                </div>
              </div>
              
              <div className="bg-white/90 backdrop-blur-sm rounded-2xl p-5 mb-4 shadow-lg border border-purple-100/50">
                <p className="text-gray-700 leading-relaxed text-sm font-medium">
                  {encouragement}
                </p>
              </div>

              <div className="flex items-center gap-2 flex-wrap">
                {[
                  { icon: '🧠', label: '护理指数' },
                  { icon: '💬', label: '营养建议' },
                  { icon: '☀️', label: '天气组合' }
                ].map((tag, i) => (
                  <motion.span
                    key={i}
                    className="px-4 py-2 bg-purple-100/90 text-purple-700 rounded-full text-xs font-bold shadow-sm border border-purple-200/50"
                    initial={{ opacity: 0, scale: 0.8 }}
                    animate={{ opacity: 1, scale: 1 }}
                    transition={{ delay: 0.5 + i * 0.1 }}
                    whileHover={{ scale: 1.08, y: -3 }}
                  >
                    {tag.icon} {tag.label}
                  </motion.span>
                ))}
              </div>

              <div className="mt-4 text-sm text-purple-600 font-bold flex items-center gap-1">
                查看详细建议
                <ChevronRight className="w-4 h-4" />
              </div>
            </div>
          </motion.div>
        </Link>

        {/* 本周数据趋势 */}
        {recentMoods.length > 0 && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4 }}
            className="mb-5"
          >
            <div className="bg-gradient-to-br from-white via-orange-50/40 to-pink-50/40 rounded-3xl p-6 shadow-2xl border-3 border-white/80 relative overflow-hidden">
              {/* 背景装饰光晕 */}
              <motion.div
                className="absolute -top-10 -right-10 w-40 h-40 rounded-full bg-gradient-to-br from-orange-200/30 to-pink-200/30 blur-3xl"
                animate={{ 
                  scale: [1, 1.3, 1],
                  rotate: [0, 90, 0]
                }}
                transition={{ duration: 10, repeat: Infinity }}
              />
              
              <div className="relative z-10">
                <h3 className="font-bold text-gray-800 text-xl mb-1 flex items-center gap-2">
                  本周心情指数
                  <motion.span
                    animate={{ 
                      rotate: [0, 15, -15, 0],
                      scale: [1, 1.2, 1]
                    }}
                    transition={{ duration: 2, repeat: Infinity }}
                  >
                    📊
                  </motion.span>
                </h3>
                <p className="text-xs text-gray-500 font-medium mb-6">
                  持续记录，关爱每一天
                </p>
                
                <div className="flex items-end justify-between gap-3 px-2">
                  {recentMoods.map((mood, i) => (
                    <MoodBar key={i} score={mood.moodScore} date={mood.date} />
                  ))}
                </div>
              </div>
            </div>
          </motion.div>
        )}

        {/* 快捷入口 - 2x2 网格 */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
          className="mb-6"
        >
          <div className="flex items-center gap-2 mb-4">
            <motion.span
              animate={{ rotate: [0, 10, -10, 0] }}
              transition={{ duration: 2, repeat: Infinity }}
              className="text-xl"
            >
              🚀
            </motion.span>
            <h3 className="font-bold text-gray-800 text-lg">快捷入口</h3>
          </div>
          
          <div className="grid grid-cols-2 gap-4">
            {quickActions.map((action, i) => (
              <Link key={i} to={action.path}>
                <motion.div
                  className={`bg-gradient-to-br ${action.bgColor} rounded-3xl p-6 shadow-xl border-2 border-white/60 relative overflow-hidden h-44 flex flex-col`}
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ delay: 0.6 + i * 0.1, type: 'spring' }}
                  whileHover={{ scale: 1.05, y: -6 }}
                  whileTap={{ scale: 0.95 }}
                >
                  {/* 背景装饰 */}
                  <motion.div
                    className="absolute -bottom-8 -right-8 text-6xl opacity-10"
                    animate={{ rotate: [0, 10, -10, 0] }}
                    transition={{ duration: 3, repeat: Infinity, delay: i * 0.5 }}
                  >
                    {action.emoji}
                  </motion.div>
                  
                  <motion.div 
                    className={`w-16 h-16 rounded-2xl bg-gradient-to-br ${action.iconBg} flex items-center justify-center shadow-xl`}
                    whileHover={{ scale: 1.1, rotate: 10 }}
                  >
                    <action.icon className="w-8 h-8 text-white" strokeWidth={2.5} />
                  </motion.div>
                  
                  <div className="flex-1" />
                  
                  <h4 className="font-extrabold text-gray-800 text-lg tracking-tight leading-tight">
                    {action.label}
                  </h4>
                </motion.div>
              </Link>
            ))}
          </div>
        </motion.div>

        {/* 护理小贴士 */}
        {tip && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.7 }}
            className="bg-gradient-to-br from-amber-50 to-yellow-50 rounded-3xl p-6 shadow-xl border-2 border-amber-100/80"
          >
            <div className="flex items-center gap-3 mb-3">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-amber-400 to-orange-400 flex items-center justify-center shadow-lg">
                <span className="text-lg">{tip.icon}</span>
              </div>
              <span className="font-bold text-amber-800 text-sm uppercase tracking-wider">
                {tip.category}
              </span>
            </div>
            <p className="text-gray-700 leading-relaxed text-sm">
              {tip.tip}
            </p>
          </motion.div>
        )}
      </motion.div>
    </div>
  );
}