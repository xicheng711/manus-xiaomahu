import { useState } from 'react';
import { CelebrationAnimation } from '../components/celebration-animation';

export function CelebrationDemoPage() {
  const [showAnimation, setShowAnimation] = useState(false);

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100 flex items-center justify-center p-6">
      <div className="text-center space-y-6">
        <h1 className="text-4xl font-bold text-gray-800 mb-2">
          🌸 庆祝动画演示
        </h1>
        <p className="text-gray-600 mb-8">
          点击下方按钮查看打卡完成后的可爱庆祝动画
        </p>

        <button
          onClick={() => setShowAnimation(true)}
          className="bg-gradient-to-r from-pink-500 via-rose-500 to-orange-500 text-white px-12 py-5 rounded-full font-bold text-xl shadow-2xl hover:scale-105 transition-transform"
        >
          🎉 触发庆祝动画
        </button>

        <div className="mt-8 p-6 bg-white rounded-2xl shadow-lg max-w-md mx-auto">
          <h3 className="font-bold text-gray-800 mb-3">✨ 超精细动画元素：</h3>
          <ol className="text-left text-sm text-gray-600 space-y-2">
            <li>🚿 <strong>复古浇水罐</strong> - 金属质感、装饰条纹、立体手柄</li>
            <li>💧 <strong>逼真水滴</strong> - 渐变折射、多层高光、自然下落</li>
            <li>🪴 <strong>陶瓷花盆</strong> - 波浪纹、圆点装饰、泥土颗粒</li>
            <li>🌸 <strong>五瓣桃花</strong> - 花瓣纹理、12根花蕊、绿叶衬托</li>
            <li>🦋 <strong>黄色蝴蝶</strong> - 双翅拍动、触角、飞行轨迹</li>
            <li>✨ <strong>闪光星星</strong> - 八角星芒、光晕效果、旋转闪烁</li>
            <li>🌸 <strong>飘落花瓣</strong> - 30片精细花瓣、随机路径</li>
          </ol>
          <div className="mt-4 pt-4 border-t border-gray-200">
            <p className="text-xs text-gray-500 leading-relaxed">
              🎨 <strong>全手绘SVG</strong> - 每个元素都有渐变、阴影、高光<br />
              💎 <strong>超多细节</strong> - 花瓣纹理、花蕊、叶子、蝴蝶等<br />
              ⏱️ <strong>8秒完整体验</strong> - 浇水→开花→庆祝→自动返回
            </p>
          </div>
        </div>
      </div>

      {/* 庆祝动画 */}
      <CelebrationAnimation
        isVisible={showAnimation}
        onComplete={() => setShowAnimation(false)}
        userName="你"
      />
    </div>
  );
}