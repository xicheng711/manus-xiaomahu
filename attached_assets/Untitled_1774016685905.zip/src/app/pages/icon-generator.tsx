import { useState } from 'react';
import { Download } from 'lucide-react';
import { motion } from 'motion/react';

export function IconGeneratorPage() {
  const [selectedIcon, setSelectedIcon] = useState(0);

  const icons = [
    {
      name: '方案A - 温暖小松鼠',
      description: '简洁温暖 · 专业关怀',
      gradient: 'from-orange-300 via-rose-300 to-pink-300',
      icon: (
        <svg viewBox="0 0 200 200" className="w-full h-full">
          {/* 超大蓬松尾巴 */}
          <path
            d="M 140 140 Q 160 120, 170 90 Q 180 60, 185 40 Q 188 25, 180 20 Q 170 25, 165 45 Q 155 75, 145 105 Q 140 125, 135 145 Z"
            fill="#8B4513"
            opacity="0.9"
          />
          <path
            d="M 145 135 Q 165 115, 175 85 Q 182 58, 183 42"
            fill="none"
            stroke="#A0522D"
            strokeWidth="3"
            opacity="0.6"
          />
          
          {/* 身体 */}
          <ellipse 
            cx="95" 
            cy="120" 
            rx="35" 
            ry="45" 
            fill="#D2691E"
            opacity="0.95"
          />
          
          {/* 肚子（浅色） */}
          <ellipse 
            cx="95" 
            cy="130" 
            rx="22" 
            ry="30" 
            fill="#F4A460"
            opacity="0.9"
          />
          
          {/* 头部 */}
          <circle 
            cx="95" 
            cy="70" 
            r="38" 
            fill="#CD853F"
            opacity="0.95"
          />
          
          {/* 脸部（浅色） */}
          <ellipse 
            cx="95" 
            cy="80" 
            rx="28" 
            ry="25" 
            fill="#F4A460"
            opacity="0.9"
          />
          
          {/* 左耳朵 */}
          <ellipse 
            cx="75" 
            cy="45" 
            rx="10" 
            ry="22" 
            fill="#CD853F"
            opacity="0.95"
          />
          
          {/* 右耳朵 */}
          <ellipse 
            cx="115" 
            cy="45" 
            rx="10" 
            ry="22" 
            fill="#CD853F"
            opacity="0.95"
          />
          
          {/* 左眼 */}
          <circle cx="82" cy="70" r="5" fill="#2C1810" opacity="0.95" />
          <circle cx="83" cy="68" r="2" fill="white" opacity="0.9" />
          
          {/* 右眼 */}
          <circle cx="108" cy="70" r="5" fill="#2C1810" opacity="0.95" />
          <circle cx="109" cy="68" r="2" fill="white" opacity="0.9" />
          
          {/* 小鼻子 */}
          <circle cx="95" cy="82" r="4" fill="#2C1810" opacity="0.85" />
          
          {/* 前爪 */}
          <ellipse 
            cx="70" 
            cy="145" 
            rx="8" 
            ry="15" 
            fill="#CD853F"
            opacity="0.9"
          />
          <ellipse 
            cx="100" 
            cy="150" 
            rx="8" 
            ry="15" 
            fill="#CD853F"
            opacity="0.9"
          />
          
          {/* 小爱心 */}
          <path
            d="M 50 95 C 47 93, 45 94, 45 97 C 45 94, 43 93, 40 95 C 40 99, 45 104, 50 108 C 55 104, 60 99, 60 95 C 57 93, 55 94, 55 97 C 55 94, 53 93, 50 95 Z"
            fill="#FF69B4"
            opacity="0.85"
          />
        </svg>
      ),
    },
    {
      name: '方案B - 小马虎',
      description: '可爱品牌标识',
      gradient: 'from-amber-400 via-orange-400 to-rose-400',
      icon: (
        <svg viewBox="0 0 200 200" className="w-full h-full">
          {/* 圆形背景 */}
          <circle cx="100" cy="100" r="70" fill="white" opacity="0.2" />
          {/* 马 Emoji风格 */}
          <text
            x="70"
            y="125"
            fontSize="60"
            fill="white"
            style={{ fontFamily: 'system-ui' }}
          >
            🐴
          </text>
          {/* 虎 Emoji风格 */}
          <text
            x="110"
            y="125"
            fontSize="60"
            fill="white"
            style={{ fontFamily: 'system-ui' }}
          >
            🐯
          </text>
        </svg>
      ),
    },
    {
      name: '方案C - 守护之手',
      description: '关怀呵护主题',
      gradient: 'from-blue-400 via-cyan-400 to-teal-400',
      icon: (
        <svg viewBox="0 0 200 200" className="w-full h-full">
          {/* 大手 */}
          <path
            d="M100 160 C90 160, 80 150, 80 140 L80 90 C80 80, 85 75, 90 75 C90 70, 92 65, 97 65 C97 60, 100 55, 105 55 C110 55, 113 60, 113 65 C118 65, 120 70, 120 75 C125 75, 130 80, 130 90 L130 110 C130 115, 132 118, 135 118 C140 118, 143 122, 143 127 L143 140 C143 150, 133 160, 123 160 L100 160 Z"
            fill="white"
            opacity="0.9"
          />
          {/* 小爱心 */}
          <path
            d="M105 100 C95 95, 85 90, 85 80 C85 72, 90 68, 95 70 C98 68, 100 70, 100 73 C100 70, 102 68, 105 70 C110 68, 115 72, 115 80 C115 90, 105 95, 105 100 Z"
            fill="rgba(255,255,255,0.8)"
            transform="translate(5, 15)"
          />
        </svg>
      ),
    },
    {
      name: '方案D - 家庭圆环',
      description: '家人团聚',
      gradient: 'from-green-400 via-emerald-400 to-teal-400',
      icon: (
        <svg viewBox="0 0 200 200" className="w-full h-full">
          {/* 外圆环 */}
          <circle
            cx="100"
            cy="100"
            r="60"
            fill="none"
            stroke="white"
            strokeWidth="8"
            opacity="0.3"
          />
          {/* 中圆环 */}
          <circle
            cx="100"
            cy="100"
            r="45"
            fill="none"
            stroke="white"
            strokeWidth="6"
            opacity="0.5"
          />
          {/* 中心爱心 */}
          <path
            d="M100 125 C80 110, 65 95, 65 80 C65 65, 75 58, 85 60 C92 58, 96 63, 100 70 C104 63, 108 58, 115 60 C125 58, 135 65, 135 80 C135 95, 120 110, 100 125 Z"
            fill="white"
            opacity="0.95"
          />
          {/* 小人图标组 */}
          <g opacity="0.8">
            <circle cx="100" cy="60" r="8" fill="white" />
            <circle cx="70" cy="100" r="6" fill="white" />
            <circle cx="130" cy="100" r="6" fill="white" />
            <circle cx="85" cy="135" r="5" fill="white" />
            <circle cx="115" cy="135" r="5" fill="white" />
          </g>
        </svg>
      ),
    },
    {
      name: '方案E - 极简现代',
      description: '简洁专业',
      gradient: 'from-purple-400 via-pink-400 to-rose-400',
      icon: (
        <svg viewBox="0 0 200 200" className="w-full h-full">
          {/* 圆角方形 */}
          <rect
            x="60"
            y="60"
            width="80"
            height="80"
            rx="20"
            fill="white"
            opacity="0.2"
          />
          {/* M字母 (马虎的M) */}
          <text
            x="100"
            y="135"
            fontSize="90"
            fontWeight="bold"
            fill="white"
            textAnchor="middle"
            style={{ fontFamily: 'Arial, sans-serif' }}
          >
            M
          </text>
          {/* 小爱心装饰 */}
          <path
            d="M100 70 C95 67, 90 65, 90 60 C90 56, 92 54, 95 55 C97 54, 98 56, 100 58 C102 56, 103 54, 105 55 C108 54, 110 56, 110 60 C110 65, 105 67, 100 70 Z"
            fill="white"
            opacity="0.9"
          />
        </svg>
      ),
    },
  ];

  const downloadIcon = () => {
    const canvas = document.createElement('canvas');
    canvas.width = 1024;
    canvas.height = 1024;
    const ctx = canvas.getContext('2d')!;

    // 创建渐变
    const gradient = ctx.createLinearGradient(0, 0, 1024, 1024);
    const colors = icons[selectedIcon].gradient;
    
    // 解析Tailwind渐变类
    const colorMap: { [key: string]: string } = {
      'rose-400': '#fb7185',
      'pink-400': '#f472b6',
      'orange-400': '#fb923c',
      'amber-400': '#fbbf24',
      'blue-400': '#60a5fa',
      'cyan-400': '#22d3ee',
      'teal-400': '#2dd4bf',
      'green-400': '#4ade80',
      'emerald-400': '#34d399',
      'purple-400': '#c084fc',
    };

    const gradientColors = colors.match(/from-(\S+)\s+via-(\S+)\s+to-(\S+)/);
    if (gradientColors) {
      gradient.addColorStop(0, colorMap[gradientColors[1]] || '#fb7185');
      gradient.addColorStop(0.5, colorMap[gradientColors[2]] || '#f472b6');
      gradient.addColorStop(1, colorMap[gradientColors[3]] || '#fb923c');
    }

    // 绘制圆角矩形背景
    const radius = 226; // iOS App图标圆角半径 (1024 * 0.2237)
    ctx.fillStyle = gradient;
    ctx.beginPath();
    ctx.moveTo(radius, 0);
    ctx.lineTo(1024 - radius, 0);
    ctx.arcTo(1024, 0, 1024, radius, radius);
    ctx.lineTo(1024, 1024 - radius);
    ctx.arcTo(1024, 1024, 1024 - radius, 1024, radius);
    ctx.lineTo(radius, 1024);
    ctx.arcTo(0, 1024, 0, 1024 - radius, radius);
    ctx.lineTo(0, radius);
    ctx.arcTo(0, 0, radius, 0, radius);
    ctx.closePath();
    ctx.fill();

    // 转换为图片下载
    canvas.toBlob((blob) => {
      if (blob) {
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `xiaomahu-icon-${selectedIcon + 1}.png`;
        a.click();
        URL.revokeObjectURL(url);
      }
    });
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-pink-50 to-orange-50 p-6">
      <div className="max-w-4xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-8"
        >
          <h1 className="text-4xl font-bold text-gray-800 mb-2">
            🎨 小马虎 App 图标生成器
          </h1>
          <p className="text-gray-600">
            选择一个设计方案，点击下载生成 1024x1024 的 App Store 图标
          </p>
        </motion.div>

        {/* 图标预览网格 */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
          {icons.map((iconData, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: index * 0.1 }}
              className={`cursor-pointer transition-all ${
                selectedIcon === index
                  ? 'ring-4 ring-purple-500 ring-offset-4'
                  : 'hover:ring-2 hover:ring-gray-300 hover:ring-offset-2'
              }`}
              onClick={() => setSelectedIcon(index)}
            >
              <div className="bg-white rounded-3xl p-6 shadow-xl">
                {/* 图标预览 */}
                <div
                  className={`w-full aspect-square rounded-3xl bg-gradient-to-br ${iconData.gradient} p-8 mb-4 shadow-lg`}
                >
                  {iconData.icon}
                </div>

                {/* 信息 */}
                <h3 className="font-bold text-gray-800 mb-1">
                  {iconData.name}
                </h3>
                <p className="text-sm text-gray-600">{iconData.description}</p>
              </div>
            </motion.div>
          ))}
        </div>

        {/* 下载按钮 */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
          className="text-center"
        >
          <button
            onClick={downloadIcon}
            className="inline-flex items-center gap-3 bg-gradient-to-r from-purple-500 to-pink-500 text-white px-8 py-4 rounded-2xl font-bold shadow-xl hover:shadow-2xl transition-all hover:scale-105"
          >
            <Download className="w-6 h-6" />
            下载选中的图标 (1024x1024 PNG)
          </button>

          <p className="text-gray-500 text-sm mt-4">
            当前选择：{icons[selectedIcon].name}
          </p>
        </motion.div>

        {/* 使用说明 */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.7 }}
          className="mt-12 bg-white rounded-3xl p-8 shadow-lg"
        >
          <h2 className="text-2xl font-bold text-gray-800 mb-4">
            📋 使用说明
          </h2>
          <ul className="space-y-3 text-gray-700">
            <li className="flex items-start gap-3">
              <span className="text-purple-500 font-bold">1.</span>
              <span>选择你喜欢的图标设计方案</span>
            </li>
            <li className="flex items-start gap-3">
              <span className="text-purple-500 font-bold">2.</span>
              <span>点击"下载"按钮生成 1024x1024 高清 PNG 图标</span>
            </li>
            <li className="flex items-start gap-3">
              <span className="text-purple-500 font-bold">3.</span>
              <span>
                上传到 App Store Connect��适用于 iOS）或 Google Play Console（适用于
                Android）
              </span>
            </li>
            <li className="flex items-start gap-3">
              <span className="text-purple-500 font-bold">4.</span>
              <span>
                iOS 系统会自动添加圆角，无需手动裁切
              </span>
            </li>
          </ul>

          <div className="mt-6 p-4 bg-purple-50 rounded-2xl border-2 border-purple-100">
            <p className="text-sm text-purple-800">
              💡 <strong>提示：</strong>所有图标均符合 App Store 和 Google Play
              的设计规范，分辨率为 1024x1024 像素。
            </p>
          </div>
        </motion.div>
      </div>
    </div>
  );
}