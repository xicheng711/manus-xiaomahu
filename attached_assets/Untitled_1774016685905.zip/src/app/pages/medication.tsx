import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { getMedications, saveMedications, Medication } from '@/lib/storage';
import { X, Plus } from 'lucide-react';

const TIMES = ['06:00', '07:00', '08:00', '09:00', '10:00', '12:00', '14:00', '16:00', '18:00', '20:00', '22:00'];
const FREQUENCIES = ['每天一次', '每天两次', '每天三次', '每隔一天', '每周一次', '需要时服用'];
const MED_ICONS = ['💊', '💉', '🩺', '🌡️', '🧴', '🫁', '🧠', '❤️', '🦴', '👁️'];

export function MedicationPage() {
  const [meds, setMeds] = useState<Medication[]>([]);
  const [adding, setAdding] = useState(false);
  const [name, setName] = useState('');
  const [dosage, setDosage] = useState('');
  const [freqIdx, setFreqIdx] = useState(0);
  const [selectedTimes, setSelectedTimes] = useState<string[]>(['08:00']);
  const [notes, setNotes] = useState('');
  const [icon, setIcon] = useState('💊');

  useEffect(() => {
    loadMedications();
  }, []);

  async function loadMedications() {
    const data = await getMedications();
    setMeds(data);
  }

  async function handleAdd() {
    if (!name.trim()) {
      alert('请输入药物名称');
      return;
    }
    const newMed: Medication = {
      id: Date.now().toString(),
      name: name.trim(),
      dosage: dosage.trim() || '按医嘱',
      frequency: FREQUENCIES[freqIdx],
      times: selectedTimes,
      notes: notes.trim(),
      icon,
      active: true,
    };
    const updated = [...meds, newMed];
    await saveMedications(updated);
    setMeds(updated);
    setAdding(false);
    setName(''); setDosage(''); setFreqIdx(0); setSelectedTimes(['08:00']); setNotes(''); setIcon('💊');
  }

  async function handleToggle(id: string) {
    const updated = meds.map(m => m.id === id ? { ...m, active: !m.active } : m);
    await saveMedications(updated);
    setMeds(updated);
  }

  async function handleDelete(id: string) {
    if (confirm('确定要删除这个药物吗？')) {
      const updated = meds.filter(m => m.id !== id);
      await saveMedications(updated);
      setMeds(updated);
    }
  }

  function toggleTime(t: string) {
    setSelectedTimes(prev =>
      prev.includes(t) ? prev.filter(x => x !== t) : [...prev, t]
    );
  }

  return (
    <div className="p-6 pb-28">
      {/* Header */}
      <div className="flex items-center justify-between mb-6 pt-2">
        <h1 className="text-2xl font-bold text-gray-800 flex items-center gap-2">
          <span>💊</span> 用药管理
        </h1>
        <button
          onClick={() => setAdding(true)}
          className="bg-gradient-to-r from-pink-500 to-red-500 text-white px-4 py-2 rounded-2xl font-bold shadow-lg hover:scale-105 transition-transform flex items-center gap-1"
        >
          <Plus className="w-4 h-4" />
          添加药物
        </button>
      </div>

      {/* Add Form */}
      <AnimatePresence>
        {adding && (
          <motion.div
            className="bg-white rounded-3xl p-6 shadow-xl border-2 border-gray-100 mb-6"
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
          >
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-xl font-bold text-gray-800">➕ 添加新药物</h3>
              <button onClick={() => setAdding(false)} className="text-gray-400 hover:text-gray-600">
                <X className="w-6 h-6" />
              </button>
            </div>

            {/* Icon Picker */}
            <label className="text-sm font-semibold text-gray-600 mb-2 block">选择图标</label>
            <div className="flex gap-2 mb-4 overflow-x-auto pb-2">
              {MED_ICONS.map(ic => (
                <button
                  key={ic}
                  onClick={() => setIcon(ic)}
                  className={`w-12 h-12 rounded-xl flex items-center justify-center text-2xl transition-all ${
                    icon === ic
                      ? 'bg-gradient-to-br from-pink-100 to-red-100 border-2 border-pink-400'
                      : 'bg-gray-100 border-2 border-gray-200 hover:bg-gray-200'
                  }`}
                >
                  {ic}
                </button>
              ))}
            </div>

            <label className="text-sm font-semibold text-gray-600 mb-2 block">药物名称 *</label>
            <input
              type="text"
              className="w-full bg-gray-100 rounded-xl p-3 mb-4 border-2 border-gray-200 focus:border-pink-400 focus:outline-none"
              placeholder="例如：多奈哌齐、美金刚..."
              value={name}
              onChange={(e) => setName(e.target.value)}
            />

            <label className="text-sm font-semibold text-gray-600 mb-2 block">剂量</label>
            <input
              type="text"
              className="w-full bg-gray-100 rounded-xl p-3 mb-4 border-2 border-gray-200 focus:border-pink-400 focus:outline-none"
              placeholder="例如：5mg、1片..."
              value={dosage}
              onChange={(e) => setDosage(e.target.value)}
            />

            <label className="text-sm font-semibold text-gray-600 mb-2 block">服药频率</label>
            <div className="flex gap-2 mb-4 overflow-x-auto pb-2">
              {FREQUENCIES.map((f, i) => (
                <button
                  key={i}
                  onClick={() => setFreqIdx(i)}
                  className={`px-4 py-2 rounded-xl whitespace-nowrap text-sm font-semibold transition-all ${
                    freqIdx === i
                      ? 'bg-gradient-to-br from-pink-100 to-red-100 border-2 border-pink-400 text-pink-700'
                      : 'bg-gray-100 border-2 border-gray-200 text-gray-600 hover:bg-gray-200'
                  }`}
                >
                  {f}
                </button>
              ))}
            </div>

            <label className="text-sm font-semibold text-gray-600 mb-2 block">服药时间（可多选）</label>
            <div className="grid grid-cols-4 gap-2 mb-4">
              {TIMES.map(t => (
                <button
                  key={t}
                  onClick={() => toggleTime(t)}
                  className={`p-2 rounded-xl text-sm font-semibold transition-all ${
                    selectedTimes.includes(t)
                      ? 'bg-gradient-to-br from-pink-100 to-red-100 border-2 border-pink-400 text-pink-700'
                      : 'bg-gray-100 border-2 border-gray-200 text-gray-600 hover:bg-gray-200'
                  }`}
                >
                  {t}
                </button>
              ))}
            </div>

            <label className="text-sm font-semibold text-gray-600 mb-2 block">备注（可选）</label>
            <input
              type="text"
              className="w-full bg-gray-100 rounded-xl p-3 mb-6 border-2 border-gray-200 focus:border-pink-400 focus:outline-none"
              placeholder="例如：饭后服用、需要大量喝水..."
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
            />

            <div className="flex gap-3">
              <button
                onClick={() => setAdding(false)}
                className="flex-1 bg-gray-100 text-gray-700 py-3 rounded-2xl font-semibold hover:bg-gray-200"
              >
                取消
              </button>
              <button
                onClick={handleAdd}
                className="flex-2 bg-gradient-to-r from-pink-500 to-red-500 text-white py-3 px-6 rounded-2xl font-bold shadow-lg hover:scale-105 transition-transform"
              >
                保存药物 ✓
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Medication List */}
      {meds.length === 0 && !adding ? (
        <div className="text-center py-16">
          <p className="text-6xl mb-4">💊</p>
          <h3 className="text-xl font-bold text-gray-800 mb-2">还没有添加药物</h3>
          <p className="text-gray-600 mb-6">点击右上角「添加药物」开始记录老人的用药计划</p>
        </div>
      ) : (
        <div className="space-y-4">
          <h3 className="text-lg font-bold text-gray-800 mb-4">
            📋 用药计划 ({meds.filter(m => m.active).length} 种启用)
          </h3>
          {meds.map((med) => (
            <motion.div
              key={med.id}
              className={`rounded-2xl p-4 border-2 transition-all ${
                med.active
                  ? 'bg-red-50 border-red-200'
                  : 'bg-gray-50 border-gray-200 opacity-60'
              }`}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              whileHover={{ scale: 1.02 }}
            >
              <div className="flex gap-3 mb-3">
                <span className="text-3xl">{med.icon}</span>
                <div className="flex-1">
                  <h4 className="font-bold text-gray-800 text-lg">{med.name}</h4>
                  <p className="text-sm text-gray-600">{med.dosage} · {med.frequency}</p>
                  <div className="flex flex-wrap gap-2 mt-2">
                    {med.times.map((t, i) => (
                      <span key={i} className="bg-pink-100 text-pink-700 text-xs font-semibold px-2 py-1 rounded-lg">
                        🕐 {t}
                      </span>
                    ))}
                  </div>
                  {med.notes && <p className="text-xs text-gray-500 mt-2">📝 {med.notes}</p>}
                </div>
              </div>
              <div className="flex gap-2">
                <button
                  onClick={() => handleToggle(med.id)}
                  className={`flex-1 py-2 rounded-xl text-sm font-semibold ${
                    med.active
                      ? 'bg-green-100 text-green-700'
                      : 'bg-gray-200 text-gray-600'
                  }`}
                >
                  {med.active ? '启用' : '停用'}
                </button>
                <button
                  onClick={() => handleDelete(med.id)}
                  className="px-4 py-2 rounded-xl text-lg hover:bg-red-100"
                >
                  🗑️
                </button>
              </div>
            </motion.div>
          ))}
        </div>
      )}

      {/* Tips */}
      <motion.div
        className="bg-gradient-to-br from-yellow-50 to-amber-50 rounded-2xl p-6 mt-6 border-2 border-yellow-100"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.3 }}
      >
        <h3 className="font-bold text-amber-800 mb-3 flex items-center gap-2">
          <span>💡</span> 用药小贴士
        </h3>
        <ul className="space-y-2 text-sm text-amber-900">
          <li>• 阿尔茨海默症药物需要长期规律服用，不可随意停药</li>
          <li>• 如老人拒绝服药，可尝试将药物混入食物中（请先咨询医生）</li>
          <li>• 使用分药盒，按早中晚分装，避免漏服或重复服药</li>
          <li>• 定期复查，根据医生建议调整用药方案</li>
        </ul>
      </motion.div>
    </div>
  );
}
