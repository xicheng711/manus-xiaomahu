import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { upsertCheckIn, getTodayCheckIn, todayStr, DailyCheckIn } from '@/lib/storage';
import { useNavigate } from 'react-router';
import { Sparkles, ArrowLeft, ArrowRight, Check, Moon, Sun, Coffee } from 'lucide-react';
import { CelebrationAnimation } from '../components/celebration-animation';

const MOODS = [
  { emoji: '😄', label: '很开心', score: 9 },
  { emoji: '😊', label: '还不错', score: 7 },
  { emoji: '😌', label: '平静', score: 5 },
  { emoji: '😕', label: '有点累', score: 4 },
  { emoji: '😢', label: '不太好', score: 2 },
  { emoji: '😤', label: '烦躁', score: 3 },
];

export function CheckInPage() {
  const navigate = useNavigate();
  const [checkIn, setCheckIn] = useState<DailyCheckIn | null>(null);
  const [mode, setMode] = useState<'morning' | 'evening'>('morning');
  const [step, setStep] = useState(0);
  const [done, setDone] = useState(false);
  const [showCelebration, setShowCelebration] = useState(false);

  // Morning state
  const [sleepHours, setSleepHours] = useState(7);
  const [sleepQuality, setSleepQuality] = useState<'poor' | 'fair' | 'good'>('fair');
  const [morningNotes, setMorningNotes] = useState('');

  // Evening state
  const [moodIdx, setMoodIdx] = useState(1);
  const [medicationTaken, setMedicationTaken] = useState(true);
  const [mealNotes, setMealNotes] = useState('');
  const [eveningNotes, setEveningNotes] = useState('');

  useEffect(() => {
    loadCheckIn();
  }, []);

  async function loadCheckIn() {
    const c = await getTodayCheckIn();
    setCheckIn(c);
    if (c) {
      setSleepHours(c.sleepHours || 7);
      setSleepQuality(c.sleepQuality);
      setMorningNotes(c.morningNotes || '');
      setMoodIdx(MOODS.findIndex(m => m.score === c.moodScore) ?? 1);
      setMedicationTaken(c.medicationTaken);
      setMealNotes(c.mealNotes || '');
      setEveningNotes(c.eveningNotes || '');
      if (c.morningDone && c.eveningDone) setDone(true);
      else if (c.morningDone) { setMode('evening'); setStep(0); }
    }
  }

  const morningSteps = [
    {
      q: '昨晚老宝睡了多久？',
      hint: '选择睡眠时长',
      content: (
        <div className="space-y-4">
          <div className="grid grid-cols-4 gap-2">
            {Array.from({ length: 14 }, (_, i) => i + 1).map((h) => (
              <button
                key={h}
                onClick={() => setSleepHours(h)}
                className={`p-3 rounded-xl font-bold text-sm transition-all ${
                  sleepHours === h
                    ? 'bg-gradient-to-br from-pink-100 to-red-100 border-2 border-pink-400 text-pink-700'
                    : 'bg-gray-100 border-2 border-gray-200 text-gray-600 hover:bg-gray-200'
                }`}
              >
                {h}小时
              </button>
            ))}
          </div>
          <p className="text-center text-sm font-bold text-pink-600">已选：{sleepHours} 小时</p>
        </div>
      ),
    },
    {
      q: '睡眠质量怎么样？',
      hint: '选择最符合的描述',
      content: (
        <div className="flex gap-3">
          {[
            { value: 'good', icon: '😴', label: '睡得很好' },
            { value: 'fair', icon: '😐', label: '一般般' },
            { value: 'poor', icon: '😫', label: '睡不好' },
          ].map((opt) => (
            <button
              key={opt.value}
              onClick={() => setSleepQuality(opt.value as any)}
              className={`flex-1 flex flex-col items-center gap-2 p-4 rounded-2xl transition-all ${
                sleepQuality === opt.value
                  ? 'bg-gradient-to-br from-pink-100 to-red-100 border-2 border-pink-400'
                  : 'bg-gray-100 border-2 border-gray-200 hover:bg-gray-200'
              }`}
            >
              <span className="text-3xl">{opt.icon}</span>
              <span className={`text-sm font-semibold ${sleepQuality === opt.value ? 'text-pink-700' : 'text-gray-600'}`}>
                {opt.label}
              </span>
            </button>
          ))}
        </div>
      ),
    },
    {
      q: '有什么要补充的吗？（可选）',
      hint: '如昨晚有特殊情况可以说明',
      content: (
        <textarea
          className="w-full bg-gray-100 rounded-2xl p-4 text-sm border-2 border-gray-200 focus:border-pink-400 focus:outline-none min-h-24"
          placeholder="例如：昨晚起夜3次、有点烦躁..."
          value={morningNotes}
          onChange={(e) => setMorningNotes(e.target.value)}
        />
      ),
    },
  ];

  const eveningSteps = [
    {
      q: '今天老宝的心情如何？',
      hint: '选择最接近的情绪',
      content: (
        <div className="space-y-4">
          <div className="grid grid-cols-3 gap-3">
            {MOODS.map((m, i) => (
              <button
                key={i}
                onClick={() => setMoodIdx(i)}
                className={`flex flex-col items-center gap-2 p-3 rounded-2xl transition-all ${
                  moodIdx === i
                    ? 'bg-gradient-to-br from-pink-100 to-red-100 border-2 border-pink-400'
                    : 'bg-gray-100 border-2 border-gray-200 hover:bg-gray-200'
                }`}
              >
                <span className="text-3xl">{m.emoji}</span>
                <span className={`text-xs font-semibold ${moodIdx === i ? 'text-pink-700' : 'text-gray-600'}`}>
                  {m.label}
                </span>
              </button>
            ))}
          </div>
          <p className="text-center text-sm font-bold text-pink-600">
            心情分数：{MOODS[moodIdx].score}/10
          </p>
        </div>
      ),
    },
    {
      q: '今天按时吃药了吗？',
      hint: '记录用药情况',
      content: (
        <div className="flex gap-3">
          {[
            { value: true, icon: '✅', label: '按时吃了' },
            { value: false, icon: '❌', label: '没有吃' },
          ].map((opt) => (
            <button
              key={String(opt.value)}
              onClick={() => setMedicationTaken(opt.value)}
              className={`flex-1 flex flex-col items-center gap-2 p-4 rounded-2xl transition-all ${
                medicationTaken === opt.value
                  ? 'bg-gradient-to-br from-pink-100 to-red-100 border-2 border-pink-400'
                  : 'bg-gray-100 border-2 border-gray-200 hover:bg-gray-200'
              }`}
            >
              <span className="text-3xl">{opt.icon}</span>
              <span className={`text-sm font-semibold ${medicationTaken === opt.value ? 'text-pink-700' : 'text-gray-600'}`}>
                {opt.label}
              </span>
            </button>
          ))}
        </div>
      ),
    },
    {
      q: '今天吃了什么？',
      hint: '简单记录一下饮食情况',
      content: (
        <textarea
          className="w-full bg-gray-100 rounded-2xl p-4 text-sm border-2 border-gray-200 focus:border-pink-400 focus:outline-none min-h-24"
          placeholder="例如：早餐小米粥，午餐蒸鱼，晚餐面条..."
          value={mealNotes}
          onChange={(e) => setMealNotes(e.target.value)}
        />
      ),
    },
    {
      q: '今天有什么要补充的吗？（可选）',
      hint: '如有特殊情况可以记录',
      content: (
        <textarea
          className="w-full bg-gray-100 rounded-2xl p-4 text-sm border-2 border-gray-200 focus:border-pink-400 focus:outline-none min-h-24"
          placeholder="例如：今天有点认不出我、情绪突然激动..."
          value={eveningNotes}
          onChange={(e) => setEveningNotes(e.target.value)}
        />
      ),
    },
  ];

  const currentSteps = mode === 'morning' ? morningSteps : eveningSteps;
  const currentStep = currentSteps[step];
  const isLast = step === currentSteps.length - 1;

  async function handleNext() {
    if (isLast) {
      const data: Partial<DailyCheckIn> & { date: string } = { date: todayStr() };
      if (mode === 'morning') {
        Object.assign(data, {
          sleepHours,
          sleepQuality,
          morningNotes,
          morningDone: true,
        });
      } else {
        Object.assign(data, {
          moodEmoji: MOODS[moodIdx].emoji,
          moodScore: MOODS[moodIdx].score,
          medicationTaken,
          mealNotes,
          eveningNotes,
          eveningDone: true,
        });
      }
      await upsertCheckIn(data);
      setShowCelebration(true); // 触发庆祝动画
    } else {
      setStep(step + 1);
    }
  }

  // 庆祝动画完成后的回调
  function handleCelebrationComplete() {
    setShowCelebration(false);
    setDone(true);
  }

  // 庆祝动画
  if (showCelebration) {
    return (
      <CelebrationAnimation
        isVisible={showCelebration}
        onComplete={handleCelebrationComplete}
        userName="小马虎家人"
      />
    );
  }

  if (done) {
    return (
      <div className="flex items-center justify-center min-h-screen p-6">
        <motion.div
          className="text-center"
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.5 }}
        >
          <motion.div
            animate={{ rotate: [0, 360] }}
            transition={{ duration: 1, repeat: Infinity, ease: 'linear' }}
          >
            <Sparkles className="w-20 h-20 text-pink-500 mx-auto mb-4" />
          </motion.div>
          <h2 className="text-3xl font-bold text-gray-800 mb-2">打卡完成！</h2>
          <p className="text-gray-600 mb-6 leading-relaxed">
            小马虎已记录今天的数据<br />明天早上查看今日护理预吧
          </p>
          <button
            onClick={() => navigate('/')}
            className="bg-gradient-to-r from-pink-500 to-red-500 text-white px-8 py-3 rounded-full font-bold shadow-lg hover:scale-105 transition-transform"
          >
            返回首页
          </button>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="p-6 pb-28">
      {/* Header */}
      <div className="flex items-center justify-between mb-6 pt-2">
        <h1 className="text-2xl font-bold text-gray-800">小马虎 🐴🐯</h1>
        <p className="text-sm text-gray-500">
          {new Date().toLocaleDateString('zh-CN', { month: 'long', day: 'numeric', weekday: 'short' })}
        </p>
      </div>

      {/* Mode Tabs */}
      <div className="flex gap-3 mb-6">
        <button
          onClick={() => { setMode('morning'); setStep(0); }}
          className={`flex-1 flex items-center justify-center gap-2 p-4 rounded-2xl font-semibold transition-all ${
            mode === 'morning'
              ? 'bg-gradient-to-br from-orange-100 to-yellow-100 border-2 border-orange-400 text-orange-700'
              : 'bg-gray-100 border-2 border-gray-200 text-gray-600'
          }`}
        >
          🌅 早上打卡
          {checkIn?.morningDone && <span className="text-green-600 font-bold">✓</span>}
        </button>
        <button
          onClick={() => { setMode('evening'); setStep(0); }}
          className={`flex-1 flex items-center justify-center gap-2 p-4 rounded-2xl font-semibold transition-all ${
            mode === 'evening'
              ? 'bg-gradient-to-br from-purple-100 to-blue-100 border-2 border-purple-400 text-purple-700'
              : 'bg-gray-100 border-2 border-gray-200 text-gray-600'
          }`}
        >
          🌙 晚上打卡
          {checkIn?.eveningDone && <span className="text-green-600 font-bold">✓</span>}
        </button>
      </div>

      {/* Progress Dots */}
      <div className="flex justify-center gap-2 mb-6">
        {currentSteps.map((_, i) => (
          <div
            key={i}
            className={`h-2 rounded-full transition-all ${
              i === step ? 'w-6 bg-pink-500' : i < step ? 'w-2 bg-green-500' : 'w-2 bg-gray-300'
            }`}
          />
        ))}
      </div>

      {/* Question Card */}
      <AnimatePresence mode="wait">
        <motion.div
          key={`${mode}-${step}`}
          className="bg-white rounded-3xl p-6 shadow-xl border-2 border-gray-100 mb-6"
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          exit={{ opacity: 0, x: -20 }}
          transition={{ duration: 0.3 }}
        >
          <p className="text-xs font-semibold text-gray-400 mb-2">
            第 {step + 1} / {currentSteps.length} 题
          </p>
          <h2 className="text-2xl font-bold text-gray-800 mb-2 leading-tight">{currentStep.q}</h2>
          <p className="text-sm text-gray-500 mb-6">{currentStep.hint}</p>
          <div className="min-h-32">{currentStep.content}</div>
        </motion.div>
      </AnimatePresence>

      {/* Navigation */}
      <div className="flex gap-3">
        {step > 0 && (
          <button
            onClick={() => setStep(step - 1)}
            className="flex-1 bg-gray-100 text-gray-700 py-4 rounded-2xl font-semibold hover:bg-gray-200 transition-colors"
          >
            <ArrowLeft className="w-4 h-4 mr-2" /> 上一题
          </button>
        )}
        <button
          onClick={handleNext}
          className="flex-2 bg-gradient-to-r from-pink-500 to-red-500 text-white py-4 px-8 rounded-2xl font-bold shadow-lg hover:scale-105 transition-transform"
        >
          {isLast ? (mode === 'morning' ? '完成早上打卡 🌅' : '完成晚上打卡 🌙') : '下一题 →'}
        </button>
      </div>
    </div>
  );
}