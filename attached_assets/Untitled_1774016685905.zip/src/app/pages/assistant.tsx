import { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { getTodayCheckIn } from '@/lib/storage';
import { generateCareAdvice } from '@/lib/care-knowledge';

export function AssistantPage() {
  const [score, setScore] = useState(0);
  const [advice, setAdvice] = useState<{
    sleepAdvice: string;
    moodAdvice: string;
    medicationAdvice: string;
    activityAdvice: string;
  } | null>(null);

  useEffect(() => {
    loadAdvice();
  }, []);

  async function loadAdvice() {
    const checkIn = await getTodayCheckIn();
    if (checkIn && checkIn.morningDone && checkIn.eveningDone) {
      const result = generateCareAdvice({
        sleepHours: checkIn.sleepHours,
        sleepQuality: checkIn.sleepQuality,
        moodScore: checkIn.moodScore,
        medicationTaken: checkIn.medicationTaken,
      });
      setScore(result.score);
      setAdvice(result);
    }
  }

  const scoreColor = score >= 80 ? '#22C55E' : score >= 60 ? '#F59E0B' : '#EF4444';
  const scoreLabel = score >= 80 ? '优秀' : score >= 60 ? '良好' : '需关注';

  return (
    <div className="p-6 pb-28">
      {/* Header */}
      <div className="pt-2 mb-6">
        <h1 className="text-2xl font-bold text-gray-800 flex items-center gap-2 mb-2">
          <span>🧠</span> AI 护理助手
        </h1>
        <p className="text-gray-600 text-sm">基于今日打卡数据生成专业建议</p>
      </div>

      {/* Score Ring */}
      {advice ? (
        <>
          <motion.div
            className="bg-gradient-to-br from-purple-50 to-pink-50 rounded-3xl p-8 shadow-xl border-2 border-purple-100 mb-6 flex flex-col items-center"
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.5 }}
          >
            <div className="relative w-48 h-48 mb-4">
              {/* Background Circle */}
              <svg className="w-full h-full -rotate-90">
                <circle
                  cx="96"
                  cy="96"
                  r="88"
                  stroke="#E5E7EB"
                  strokeWidth="12"
                  fill="none"
                />
                <motion.circle
                  cx="96"
                  cy="96"
                  r="88"
                  stroke={scoreColor}
                  strokeWidth="12"
                  fill="none"
                  strokeLinecap="round"
                  initial={{ strokeDashoffset: 553 }}
                  animate={{ strokeDashoffset: 553 - (553 * score) / 100 }}
                  transition={{ duration: 1.5, ease: 'easeOut' }}
                  style={{ strokeDasharray: 553 }}
                />
              </svg>
              <div className="absolute inset-0 flex flex-col items-center justify-center">
                <motion.p
                  className="text-5xl font-bold"
                  style={{ color: scoreColor }}
                  initial={{ opacity: 0, scale: 0.5 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ duration: 0.5, delay: 0.3 }}
                >
                  {score}
                </motion.p>
                <p className="text-sm text-gray-500 font-semibold">护理分数</p>
              </div>
            </div>
            <motion.div
              className="px-6 py-2 rounded-full text-white font-bold shadow-lg"
              style={{ backgroundColor: scoreColor }}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.5 }}
            >
              {scoreLabel}
            </motion.div>
          </motion.div>

          {/* Advice Cards */}
          <div className="space-y-4">
            <h3 className="text-lg font-bold text-gray-800 mb-4">📋 专业护理建议</h3>

            <motion.div
              className="bg-white rounded-2xl p-5 shadow-md border-l-4 border-blue-400"
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.6 }}
            >
              <div className="flex items-center gap-2 mb-2">
                <span className="text-2xl">😴</span>
                <h4 className="font-bold text-gray-800">睡眠质量</h4>
              </div>
              <p className="text-sm text-gray-700 leading-relaxed">{advice.sleepAdvice}</p>
            </motion.div>

            <motion.div
              className="bg-white rounded-2xl p-5 shadow-md border-l-4 border-pink-400"
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.7 }}
            >
              <div className="flex items-center gap-2 mb-2">
                <span className="text-2xl">💛</span>
                <h4 className="font-bold text-gray-800">情绪状态</h4>
              </div>
              <p className="text-sm text-gray-700 leading-relaxed">{advice.moodAdvice}</p>
            </motion.div>

            <motion.div
              className="bg-white rounded-2xl p-5 shadow-md border-l-4 border-green-400"
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.8 }}
            >
              <div className="flex items-center gap-2 mb-2">
                <span className="text-2xl">💊</span>
                <h4 className="font-bold text-gray-800">用药管理</h4>
              </div>
              <p className="text-sm text-gray-700 leading-relaxed">{advice.medicationAdvice}</p>
            </motion.div>

            <motion.div
              className="bg-white rounded-2xl p-5 shadow-md border-l-4 border-orange-400"
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.9 }}
            >
              <div className="flex items-center gap-2 mb-2">
                <span className="text-2xl">🎯</span>
                <h4 className="font-bold text-gray-800">活动建议</h4>
              </div>
              <p className="text-sm text-gray-700 leading-relaxed">{advice.activityAdvice}</p>
            </motion.div>
          </div>

          {/* Encouragement */}
          <motion.div
            className="bg-gradient-to-br from-amber-50 to-yellow-50 rounded-2xl p-6 mt-6 border-2 border-amber-100"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 1 }}
          >
            <div className="flex items-center gap-2 mb-3">
              <span className="text-2xl">🌟</span>
              <h4 className="font-bold text-amber-800">给照护者的话</h4>
            </div>
            <p className="text-sm text-amber-900 leading-relaxed">
              照顾认知症患者是一项充满爱与耐心的工作。你做得很好！记得也要照顾好自己，
              定期休息，保持身心健康。你的陪伴是老人最大的幸福 ❤️
            </p>
          </motion.div>
        </>
      ) : (
        <div className="text-center py-16">
          <p className="text-6xl mb-4">🤖</p>
          <h3 className="text-xl font-bold text-gray-800 mb-2">还没有数据</h3>
          <p className="text-gray-600">完成今天的早晚打卡后，AI 助手会为你生成专业的护理建议</p>
        </div>
      )}
    </div>
  );
}
