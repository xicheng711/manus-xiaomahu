import { useEffect, useState } from 'react';
import { motion } from 'motion/react';
import { 
  ChevronRight, 
  Sparkles, 
  Pill, 
  BookHeart, 
  Users, 
  Brain,
  Heart,
  User,
  CheckCircle2,
  ClipboardList,
  Star
} from 'lucide-react';

// 模拟数据
function MoodBar({ score, date }: { score: number; date: string }) {
  const height = Math.max(12, (score / 10) * 56);
  const color = score >= 7 ? '#10b981' : score >= 4 ? '#f59e0b' : '#ef4444';
  const day = new Date(date).toLocaleDateString('zh-CN', { weekday: 'short' }).replace('周', '');
  
  return (
    <div className="flex flex-col items-center gap-2 flex-1">
      <div className="w-3 h-16 bg-gradient-to-t from-gray-100 to-gray-50 rounded-full flex items-end overflow-hidden shadow-inner">
        <motion.div
          className="w-full rounded-full shadow-sm"
          style={{ backgroundColor: color }}
          initial={{ height: 0 }}
          animate={{ height }}
          transition={{ duration: 0.6, delay: 0.1, ease: 'easeOut' }}
        />
      </div>
      <span className="text-xs font-medium text-gray-500">{day}</span>
    </div>
  );
}

function getMoodEmoji(score: number) {
  if (score >= 8) return '😊';
  if (score >= 6) return '🙂';
  if (score >= 4) return '😐';
  if (score >= 2) return '😔';
  return '😢';
}

// 独立Frame页面 - 用于Figma导入或预览
export function FramePage() {
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    setMounted(true);
  }, []);

  // 模拟数据
  const greeting = '早上好，小马虎家人 👋';
  const todayDone = false;
  const encouragement = '今天还没有打卡哦，点击下方开始记录吧 🌸';
  const tip = {
    category: '营养建议',
    icon: '🥗',
    tip: '多吃富含Omega-3的食物，如深海鱼、核桃等，有助于改善记忆力。'
  };

  const recentMoods = [
    { moodScore: 7, date: '2024-03-10' },
    { moodScore: 6, date: '2024-03-11' },
    { moodScore: 8, date: '2024-03-12' },
    { moodScore: 7, date: '2024-03-13' },
    { moodScore: 9, date: '2024-03-14' },
    { moodScore: 6, date: '2024-03-15' },
    { moodScore: 8, date: '2024-03-16' },
  ];

  const avgMood = (recentMoods.reduce((sum, m) => sum + m.moodScore, 0) / recentMoods.length).toFixed(1);

  const quickActions = [
    { 
      icon: Pill, 
      label: '用药提醒', 
      bgColor: 'bg-gradient-to-br from-pink-50 to-rose-50',
      iconBg: 'bg-gradient-to-br from-pink-400 to-rose-400'
    },
    { 
      icon: BookHeart, 
      label: '护理日记', 
      bgColor: 'bg-gradient-to-br from-blue-50 to-cyan-50',
      iconBg: 'bg-gradient-to-br from-blue-400 to-cyan-400'
    },
    { 
      icon: Users, 
      label: '家庭共享', 
      bgColor: 'bg-gradient-to-br from-purple-50 to-pink-50',
      iconBg: 'bg-gradient-to-br from-purple-400 to-pink-400'
    },
    { 
      icon: Brain, 
      label: 'AI 助手', 
      bgColor: 'bg-gradient-to-br from-emerald-50 to-green-50',
      iconBg: 'bg-gradient-to-br from-emerald-400 to-green-400'
    },
  ];

  if (!mounted) return null;

  return (
    <div className="px-5 py-6 pb-24 bg-gradient-to-br from-orange-50/30 via-rose-50/30 to-pink-50/30 min-h-screen">
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
      >
        {/* 顶部问候 */}
        <div className="flex items-start justify-between mb-6">
          <div className="flex-1">
            <motion.div 
              className="flex items-center gap-2 mb-2"
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.2 }}
            >
              <h1 className="text-2xl font-bold bg-gradient-to-r from-orange-600 via-rose-600 to-pink-600 bg-clip-text text-transparent">
                我们一起照顾好今天
              </h1>
              <motion.div
                animate={{ 
                  rotate: [0, 10, -10, 10, 0],
                  scale: [1, 1.1, 1.1, 1.1, 1]
                }}
                transition={{ 
                  duration: 2,
                  repeat: Infinity,
                  repeatDelay: 3
                }}
              >
                <span className="text-2xl">✨</span>
              </motion.div>
            </motion.div>
            <motion.p 
              className="text-sm text-gray-500"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.3 }}
            >
              {greeting}
            </motion.p>
          </div>
          
          <motion.div
            className="w-14 h-14 rounded-2xl bg-gradient-to-br from-orange-300 via-rose-300 to-pink-300 flex items-center justify-center shadow-lg border-2 border-white/80"
            whileHover={{ scale: 1.05, rotate: 3 }}
            whileTap={{ scale: 0.95 }}
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.4 }}
          >
            <User className="w-7 h-7 text-white" strokeWidth={2.5} />
          </motion.div>
        </div>

        {/* 今日打卡横幅 */}
        <motion.div
          className={`rounded-3xl p-5 shadow-lg mb-5 relative overflow-hidden border-2 ${
            todayDone 
              ? 'bg-gradient-to-br from-green-50 to-emerald-50 border-green-200/60' 
              : 'bg-gradient-to-br from-green-400 via-emerald-400 to-teal-400 border-green-300/50'
          }`}
          whileHover={{ scale: 1.01, y: -2 }}
          whileTap={{ scale: 0.99 }}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
        >
          {/* 背景装饰点 */}
          {!todayDone && (
            <>
              <motion.div 
                className="absolute top-0 right-0 w-32 h-32 bg-white/10 rounded-full -mr-16 -mt-16"
                animate={{ scale: [1, 1.2, 1], opacity: [0.3, 0.2, 0.3] }}
                transition={{ duration: 4, repeat: Infinity }}
              />
              <motion.div 
                className="absolute bottom-0 left-0 w-24 h-24 bg-white/10 rounded-full -ml-12 -mb-12"
                animate={{ scale: [1, 1.3, 1], opacity: [0.2, 0.3, 0.2] }}
                transition={{ duration: 3, repeat: Infinity, delay: 1 }}
              />
            </>
          )}
          
          <div className="relative flex items-center gap-4">
            <div className={`w-16 h-16 rounded-2xl flex items-center justify-center shadow-md ${
              todayDone ? 'bg-gradient-to-br from-green-200 to-emerald-200' : 'bg-white/25 backdrop-blur-sm'
            }`}>
              {todayDone ? (
                <CheckCircle2 className="w-9 h-9 text-green-600" strokeWidth={2.5} />
              ) : (
                <ClipboardList className="w-9 h-9 text-white" strokeWidth={2} />
              )}
            </div>
            
            <div className="flex-1">
              <h3 className={`text-lg font-bold mb-1 ${todayDone ? 'text-gray-800' : 'text-white'}`}>
                {todayDone ? '今日打卡已完成 ✓' : '开始今日打卡'}
              </h3>
              <p className={`text-sm ${todayDone ? 'text-gray-600' : 'text-white/90'}`}>
                每天3个问题，记录老宝的状态
              </p>
            </div>
            
            <ChevronRight className={`w-6 h-6 ${todayDone ? 'text-gray-400' : 'text-white/80'}`} />
          </div>
        </motion.div>

        {/* AI 今日护理预测 */}
        <motion.div
          className="bg-gradient-to-br from-purple-50 via-violet-50 to-purple-50 rounded-3xl p-5 shadow-md border-2 border-purple-100/60 mb-5 relative overflow-hidden"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.3 }}
          whileHover={{ scale: 1.01, y: -2 }}
          whileTap={{ scale: 0.99 }}
        >
          {/* 背景装饰星星 */}
          <div className="absolute top-4 right-4 opacity-20">
            <Star className="w-16 h-16 text-purple-400" fill="currentColor" />
          </div>
          
          <div className="relative">
            <div className="flex items-center gap-3 mb-3">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-purple-400 to-violet-400 flex items-center justify-center shadow-md">
                <Sparkles className="w-5 h-5 text-white" strokeWidth={2.5} />
              </div>
              <div>
                <h3 className="text-purple-800 font-bold text-base">AI 今日护理预测</h3>
                <p className="text-xs text-purple-600">老宝的阿兹海默护理建议 · 每日更新</p>
              </div>
            </div>
            
            <div className="bg-white/70 backdrop-blur-sm rounded-2xl p-4 mb-3 shadow-sm">
              <p className="text-gray-700 leading-relaxed text-sm">
                {encouragement}
              </p>
            </div>

            {/* 标签 */}
            <div className="flex items-center gap-2 flex-wrap">
              <span className="px-3 py-1 bg-purple-100 text-purple-700 rounded-full text-xs font-medium">
                🧠 护理指数
              </span>
              <span className="px-3 py-1 bg-purple-100 text-purple-700 rounded-full text-xs font-medium">
                💬 营养建议
              </span>
              <span className="px-3 py-1 bg-purple-100 text-purple-700 rounded-full text-xs font-medium">
                ☀️ 天气组合
              </span>
            </div>

            <div className="mt-3 text-sm text-purple-600 font-medium flex items-center gap-1">
              查看详细建议
              <ChevronRight className="w-4 h-4" />
            </div>
          </div>
        </motion.div>

        {/* 周/月切换 + 本周数据 */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          className="mb-5"
        >
          {/* 标签切换 */}
          <div className="flex items-center justify-center gap-3 mb-4">
            <button className="px-6 py-2 bg-white text-gray-800 rounded-full font-bold text-sm shadow-md border-2 border-gray-200">
              周
            </button>
            <button className="px-6 py-2 bg-gray-100 text-gray-500 rounded-full font-medium text-sm">
              月
            </button>
          </div>

          {/* 本周卡片 */}
          <div className="bg-white rounded-3xl p-5 shadow-md border border-gray-100">
            <div className="flex items-center justify-between mb-4">
              <div>
                <h3 className="font-bold text-gray-800 text-base mb-1">本周</h3>
                <p className="text-xs text-gray-500">3月10日 至 3月16日</p>
              </div>
              
              <div className="flex gap-2">
                <button className="w-8 h-8 rounded-lg bg-gray-100 flex items-center justify-center">
                  <ChevronRight className="w-4 h-4 text-gray-600 rotate-180" />
                </button>
                <button className="w-8 h-8 rounded-lg bg-gray-100 flex items-center justify-center">
                  <ChevronRight className="w-4 h-4 text-gray-600" />
                </button>
              </div>
            </div>

            {/* 心情指数 */}
            <div className="mb-5">
              <h4 className="text-sm font-bold text-gray-700 mb-3">心情指数</h4>
              <div className="flex items-center gap-4">
                <div className="relative">
                  {/* 温度计样式 */}
                  <div className="w-14 h-32 bg-gradient-to-t from-gray-100 to-gray-50 rounded-full relative overflow-hidden shadow-inner border-2 border-gray-200">
                    <motion.div 
                      className="absolute bottom-0 w-full bg-gradient-to-t from-amber-400 to-yellow-300 rounded-full"
                      initial={{ height: 0 }}
                      animate={{ height: `${(parseFloat(avgMood) / 10) * 100}%` }}
                      transition={{ duration: 1, delay: 0.6 }}
                    />
                    {/* 温度计底部圆球 */}
                    <div className="absolute bottom-2 left-1/2 -translate-x-1/2 w-8 h-8 rounded-full bg-gradient-to-br from-amber-400 to-orange-400 shadow-lg flex items-center justify-center">
                      <span className="text-xs">😊</span>
                    </div>
                  </div>
                </div>
                
                <div className="flex-1">
                  <div className="flex items-baseline gap-2 mb-2">
                    <span className="text-5xl font-bold bg-gradient-to-r from-amber-500 to-orange-500 bg-clip-text text-transparent">
                      {avgMood}
                    </span>
                    <span className="text-gray-400 text-lg font-medium">/ 10</span>
                  </div>
                  <p className="text-sm text-gray-600">
                    本周心情很棒！
                  </p>
                </div>
              </div>
            </div>

            {/* 心情分布 */}
            <div>
              <h4 className="text-sm font-bold text-gray-700 mb-3">心情分布</h4>
              
              <div className="bg-gradient-to-br from-gray-50 to-white rounded-2xl p-4 border border-gray-100">
                <div className="flex items-end justify-between h-20 gap-1.5">
                  {recentMoods.map((mood, i) => (
                    <MoodBar key={i} score={mood.moodScore} date={mood.date} />
                  ))}
                </div>
                
                <div className="mt-4 pt-4 border-t border-gray-100 flex items-center justify-between text-xs">
                  <span className="text-gray-500">
                    共记录心情: <span className="font-bold text-gray-700">{recentMoods.length}</span> 条
                  </span>
                  <span className="text-gray-500">
                    最多心情: <span className="text-lg">{getMoodEmoji(parseFloat(avgMood))}</span> 平稳
                  </span>
                </div>
              </div>
            </div>
          </div>
        </motion.div>

        {/* 今日护理贴士 */}
        <motion.div
          className="bg-gradient-to-br from-amber-50 via-orange-50 to-amber-50 rounded-3xl p-5 shadow-md border-2 border-amber-100/60 mb-5"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.5 }}
        >
          <div className="flex items-center gap-3 mb-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-amber-400 to-orange-400 flex items-center justify-center shadow-md">
              <Heart className="w-5 h-5 text-white" strokeWidth={2.5} />
            </div>
            <div>
              <span className="text-xs font-bold text-amber-700 uppercase tracking-wider block">
                {tip.category}
              </span>
              <span className="text-xs text-amber-600">护理小贴士</span>
            </div>
          </div>
          <p className="text-gray-700 leading-relaxed text-sm bg-white/50 rounded-xl p-3">
            {tip.tip}
          </p>
        </motion.div>

        {/* 快捷入口 */}
        <div className="mb-6">
          <h3 className="text-lg font-bold text-gray-800 mb-4 flex items-center gap-2">
            <span className="text-xl">🚀</span>
            快捷入口
          </h3>
          
          <div className="grid grid-cols-2 gap-3">
            {quickActions.map((action, index) => {
              const IconComponent = action.icon;
              return (
                <motion.div
                  key={index}
                  className={`${action.bgColor} rounded-2xl p-5 shadow-md border border-gray-100 relative overflow-hidden`}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.4, delay: 0.6 + index * 0.1 }}
                  whileHover={{ scale: 1.03, y: -3 }}
                  whileTap={{ scale: 0.97 }}
                >
                  {/* 背景装饰 */}
                  <div className="absolute top-0 right-0 w-16 h-16 bg-white/30 rounded-full -mr-8 -mt-8" />
                  
                  <div className="relative">
                    <div className={`w-12 h-12 ${action.iconBg} rounded-xl flex items-center justify-center mb-3 shadow-lg`}>
                      <IconComponent className="w-6 h-6 text-white" strokeWidth={2} />
                    </div>
                    <p className="font-bold text-sm text-gray-800">{action.label}</p>
                  </div>
                </motion.div>
              );
            })}
          </div>
        </div>
      </motion.div>
    </div>
  );
}
