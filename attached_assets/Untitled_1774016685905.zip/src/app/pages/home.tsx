import { useEffect, useState } from 'react';
import { motion } from 'motion/react';
import { Link } from 'react-router';
import { 
  ChevronRight, 
  Sparkles, 
  Pill, 
  BookHeart, 
  Users, 
  Brain,
  TrendingUp,
  Heart,
  User,
  CheckCircle2,
  ClipboardList,
  Sun,
  Moon,
  Star
} from 'lucide-react';
import { getTodayCheckIn, getRecentCheckIns, getProfile, DailyCheckIn } from '@/lib/storage';
import { getDayGreeting, getRandomTip, getEncouragement } from '@/lib/care-knowledge';

// 可爱的云朵SVG
function CloudDecoration({ delay = 0, className = '' }: { delay?: number; className?: string }) {
  return (
    <motion.svg
      width="80"
      height="50"
      viewBox="0 0 80 50"
      className={className}
      initial={{ opacity: 0, x: -20 }}
      animate={{ opacity: 0.6, x: 0, y: [0, -8, 0] }}
      transition={{ 
        opacity: { duration: 1, delay },
        x: { duration: 1, delay },
        y: { duration: 4, repeat: Infinity, ease: 'easeInOut' }
      }}
    >
      <defs>
        <filter id={`cloudShadow${delay}`}>
          <feDropShadow dx="0" dy="2" stdDeviation="2" floodOpacity="0.1"/>
        </filter>
      </defs>
      <g filter={`url(#cloudShadow${delay})`}>
        <circle cx="25" cy="30" r="15" fill="white" opacity="0.9"/>
        <circle cx="40" cy="25" r="18" fill="white" opacity="0.9"/>
        <circle cx="55" cy="30" r="14" fill="white" opacity="0.9"/>
        <ellipse cx="40" cy="35" rx="30" ry="12" fill="white" opacity="0.9"/>
      </g>
    </motion.svg>
  );
}

// 可爱的小太阳装饰（多彩版本）
function MiniSunDecoration({ delay = 0, className = '', colorScheme = 'yellow' }: { delay?: number; className?: string; colorScheme?: 'yellow' | 'orange' | 'pink' | 'purple' }) {
  const colors = {
    yellow: { center: '#fef08a', outer: '#fde047', rays: '#fbbf24' },
    orange: { center: '#fed7aa', outer: '#fb923c', rays: '#f97316' },
    pink: { center: '#fce7f3', outer: '#f9a8d4', rays: '#ec4899' },
    purple: { center: '#f3e8ff', outer: '#d8b4fe', rays: '#a855f7' },
  };
  const c = colors[colorScheme];
  
  return (
    <motion.svg
      width="50"
      height="50"
      viewBox="0 0 50 50"
      className={className}
      initial={{ opacity: 0, scale: 0, rotate: 0 }}
      animate={{ 
        opacity: [0, 0.7, 0.7],
        scale: [0, 1, 1],
        rotate: [0, 360]
      }}
      transition={{ 
        opacity: { duration: 1, delay },
        scale: { duration: 1, delay },
        rotate: { duration: 30, delay, repeat: Infinity, ease: 'linear' }
      }}
    >
      <defs>
        <radialGradient id={`miniSunGrad${colorScheme}${delay}`}>
          <stop offset="0%" stopColor={c.center} />
          <stop offset="100%" stopColor={c.outer} />
        </radialGradient>
      </defs>
      
      {/* 光芒 */}
      {[...Array(8)].map((_, i) => {
        const angle = (i * 45) * (Math.PI / 180);
        const x1 = 25 + Math.cos(angle) * 12;
        const y1 = 25 + Math.sin(angle) * 12;
        const x2 = 25 + Math.cos(angle) * 20;
        const y2 = 25 + Math.sin(angle) * 20;
        return (
          <motion.line
            key={i}
            x1={x1}
            y1={y1}
            x2={x2}
            y2={y2}
            stroke={c.rays}
            strokeWidth="2.5"
            strokeLinecap="round"
            animate={{ 
              strokeWidth: [2.5, 3.5, 2.5],
              opacity: [0.6, 1, 0.6]
            }}
            transition={{ 
              duration: 1.5, 
              repeat: Infinity, 
              delay: i * 0.1 
            }}
          />
        );
      })}
      
      {/* 太阳主体 */}
      <circle cx="25" cy="25" r="10" fill={`url(#miniSunGrad${colorScheme}${delay})`}/>
      <circle cx="22" cy="22" r="3" fill="white" opacity="0.6"/>
    </motion.svg>
  );
}

// 小花朵装饰
function FlowerDecoration({ delay = 0, color = 'pink', className = '' }: { delay?: number; color?: string; className?: string }) {
  const colors = {
    pink: { petals: '#fda4af', center: '#fde047' },
    purple: { petals: '#d8b4fe', center: '#fbbf24' },
    blue: { petals: '#93c5fd', center: '#fef08a' },
  };
  const c = colors[color as keyof typeof colors] || colors.pink;
  
  return (
    <motion.svg
      width="40"
      height="40"
      viewBox="0 0 40 40"
      className={className}
      initial={{ opacity: 0, scale: 0, rotate: 0 }}
      animate={{ 
        opacity: 0.8, 
        scale: 1,
        rotate: [0, 10, -10, 0]
      }}
      transition={{ 
        opacity: { duration: 0.8, delay },
        scale: { duration: 0.8, delay },
        rotate: { duration: 3, repeat: Infinity, ease: 'easeInOut' }
      }}
    >
      {/* 5片花瓣 */}
      {[0, 1, 2, 3, 4].map((i) => {
        const angle = (i * 72 - 90) * (Math.PI / 180);
        const x = 20 + Math.cos(angle) * 10;
        const y = 20 + Math.sin(angle) * 10;
        return (
          <ellipse
            key={i}
            cx={x}
            cy={y}
            rx="5"
            ry="7"
            fill={c.petals}
            transform={`rotate(${i * 72}, ${x}, ${y})`}
          />
        );
      })}
      <circle cx="20" cy="20" r="4" fill={c.center}/>
      <circle cx="18" cy="18" r="1.5" fill="white" opacity="0.7"/>
    </motion.svg>
  );
}

// 爱心漂浮装饰
function FloatingHeart({ delay = 0 }: { delay?: number }) {
  return (
    <motion.svg
      width="24"
      height="24"
      viewBox="0 0 24 24"
      className="absolute"
      style={{ 
        top: `${20 + Math.random() * 60}%`,
        left: `${10 + Math.random() * 80}%`
      }}
      initial={{ opacity: 0, y: 0 }}
      animate={{ 
        opacity: [0, 0.4, 0],
        y: [-20, -80],
        x: [0, (Math.random() - 0.5) * 20]
      }}
      transition={{ 
        duration: 4,
        delay,
        repeat: Infinity,
        repeatDelay: Math.random() * 5
      }}
    >
      <path
        d="M 12 21 L 5 14 Q 2 11, 2 8 Q 2 4, 6 4 Q 9 4, 12 7 Q 15 4, 18 4 Q 22 4, 22 8 Q 22 11, 19 14 Z"
        fill="#f87171"
        opacity="0.6"
      />
    </motion.svg>
  );
}

// 卡片装饰图案
function CardPattern({ variant = 1 }: { variant?: number }) {
  if (variant === 1) {
    // 波浪纹
    return (
      <svg className="absolute bottom-0 right-0 opacity-10" width="200" height="120" viewBox="0 0 200 120">
        <path
          d="M 0 60 Q 50 40, 100 60 T 200 60 L 200 120 L 0 120 Z"
          fill="currentColor"
        />
      </svg>
    );
  } else if (variant === 2) {
    // 圆点纹
    return (
      <svg className="absolute top-0 right-0 opacity-10" width="150" height="150" viewBox="0 0 150 150">
        {[...Array(20)].map((_, i) => (
          <circle
            key={i}
            cx={Math.random() * 150}
            cy={Math.random() * 150}
            r={2 + Math.random() * 4}
            fill="currentColor"
          />
        ))}
      </svg>
    );
  }
  return null;
}

function MoodBar({ score, date }: { score: number; date: string }) {
  const height = Math.max(12, (score / 10) * 56);
  const color = score >= 7 ? '#10b981' : score >= 4 ? '#f59e0b' : '#ef4444';
  const day = new Date(date).toLocaleDateString('zh-CN', { weekday: 'short' }).replace('周', '');
  
  return (
    <div className="flex flex-col items-center gap-2 flex-1">
      <div className="w-3 h-16 bg-gradient-to-t from-gray-100 to-gray-50 rounded-full flex items-end overflow-hidden shadow-inner">
        <motion.div
          className="w-full rounded-full shadow-sm"
          style={{ backgroundColor: color }}
          initial={{ height: 0 }}
          animate={{ height }}
          transition={{ duration: 0.6, delay: 0.1, ease: 'easeOut' }}
        />
      </div>
      <span className="text-xs font-medium text-gray-500">{day}</span>
    </div>
  );
}

function getMoodEmoji(score: number) {
  if (score >= 8) return '😊';
  if (score >= 6) return '🙂';
  if (score >= 4) return '😐';
  if (score >= 2) return '😔';
  return '😢';
}

export function HomePage() {
  const [greeting, setGreeting] = useState('');
  const [tip, setTip] = useState<{ category: string; icon: string; tip: string } | null>(null);
  const [todayCheckIn, setTodayCheckIn] = useState<DailyCheckIn | null>(null);
  const [recentMoods, setRecentMoods] = useState<DailyCheckIn[]>([]);
  const [profileName, setProfileName] = useState('');

  useEffect(() => {
    loadData();
  }, []);

  async function loadData() {
    const profile = await getProfile();
    setProfileName(profile?.nickname || profile?.caregiverName || '');
    setGreeting(getDayGreeting(profile?.nickname || profile?.caregiverName));
    setTip(getRandomTip());
    
    const today = await getTodayCheckIn();
    setTodayCheckIn(today);
    
    const recent = await getRecentCheckIns(7);
    setRecentMoods(recent.slice(0, 7).reverse());
  }

  const todayDone = todayCheckIn?.morningDone || todayCheckIn?.eveningDone;
  const encouragement = todayCheckIn
    ? getEncouragement(todayCheckIn.moodScore)
    : '今天还没有打卡哦，点击下方开始记录吧 🌸';

  const quickActions = [
    { 
      icon: Pill, 
      label: '用药提醒', 
      path: '/medication', 
      gradient: 'from-pink-400 via-rose-400 to-red-400',
      bgColor: 'bg-gradient-to-br from-pink-50 to-rose-50',
      iconBg: 'bg-gradient-to-br from-pink-400 to-rose-400',
      emoji: '💊'
    },
    { 
      icon: BookHeart, 
      label: '护理日记', 
      path: '/diary', 
      gradient: 'from-blue-400 via-cyan-400 to-teal-400',
      bgColor: 'bg-gradient-to-br from-blue-50 to-cyan-50',
      iconBg: 'bg-gradient-to-br from-blue-400 to-cyan-400',
      emoji: '📖'
    },
    { 
      icon: Users, 
      label: '家庭共享', 
      path: '/share', 
      gradient: 'from-purple-400 via-violet-400 to-pink-400',
      bgColor: 'bg-gradient-to-br from-purple-50 to-pink-50',
      iconBg: 'bg-gradient-to-br from-purple-400 to-pink-400',
      emoji: '👨‍👩‍👧'
    },
    { 
      icon: Brain, 
      label: 'AI 助手', 
      path: '/assistant', 
      gradient: 'from-emerald-400 via-green-400 to-teal-400',
      bgColor: 'bg-gradient-to-br from-emerald-50 to-green-50',
      iconBg: 'bg-gradient-to-br from-emerald-400 to-green-400',
      emoji: '🤖'
    },
  ];

  const avgMood = recentMoods.length > 0 
    ? (recentMoods.reduce((sum, m) => sum + m.moodScore, 0) / recentMoods.length).toFixed(1)
    : '0.0';

  return (
    <div className="px-5 py-6 pb-24 bg-gradient-to-br from-orange-50/40 via-rose-50/40 to-pink-50/40 min-h-screen relative overflow-hidden">
      {/* 背景装饰 - 云朵 */}
      <CloudDecoration delay={0} className="absolute top-8 left-4" />
      <CloudDecoration delay={0.5} className="absolute top-16 right-12" />
      <CloudDecoration delay={1} className="absolute top-32 left-1/2 -translate-x-1/2" />
      
      {/* 背景装饰 - 漂浮爱心 */}
      {[...Array(6)].map((_, i) => (
        <FloatingHeart key={i} delay={i * 2} />
      ))}
      
      {/* 背景装饰 - 小花朵 */}
      <FlowerDecoration delay={0.3} color="pink" className="absolute top-40 left-6" />
      <FlowerDecoration delay={0.6} color="purple" className="absolute top-80 right-8" />
      <FlowerDecoration delay={0.9} color="blue" className="absolute bottom-80 left-8" />

      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
        className="relative z-10"
      >
        {/* 顶部问候区 - 加强设计 */}
        <div className="relative mb-6">
          <motion.div
            className="bg-gradient-to-br from-white/90 via-white/80 to-white/70 backdrop-blur-xl rounded-3xl p-6 shadow-xl border-2 border-white/60 relative overflow-hidden"
            initial={{ opacity: 0, y: -30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
          >
            {/* 小太阳装饰 */}
            <MiniSunDecoration delay={0.2} colorScheme="yellow" className="absolute top-3 right-3" />
            <MiniSunDecoration delay={0.5} colorScheme="purple" className="absolute bottom-3 left-3" />
            
            <div className="flex items-start justify-between relative z-10">
              <div className="flex-1">
                <motion.div 
                  className="flex items-center gap-2 mb-2"
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.2 }}
                >
                  <h1 className="text-2xl font-bold bg-gradient-to-r from-orange-600 via-rose-600 to-pink-600 bg-clip-text text-transparent">
                    我们一起照顾好今天
                  </h1>
                  <motion.div
                    animate={{ 
                      rotate: [0, 10, -10, 10, 0],
                      scale: [1, 1.2, 1.2, 1.2, 1]
                    }}
                    transition={{ 
                      duration: 2,
                      repeat: Infinity,
                      repeatDelay: 3
                    }}
                  >
                    <span className="text-2xl">✨</span>
                  </motion.div>
                </motion.div>
                <motion.p 
                  className="text-sm text-gray-600 font-medium"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ delay: 0.3 }}
                >
                  {greeting || '加载中...'}
                </motion.p>
              </div>
              
              <Link to="/profile">
                <motion.div
                  className="w-16 h-16 rounded-2xl bg-gradient-to-br from-orange-300 via-rose-300 to-pink-300 flex items-center justify-center shadow-xl border-3 border-white relative overflow-hidden"
                  whileHover={{ scale: 1.08, rotate: 5 }}
                  whileTap={{ scale: 0.95 }}
                  initial={{ opacity: 0, scale: 0.8, rotate: -10 }}
                  animate={{ opacity: 1, scale: 1, rotate: 0 }}
                  transition={{ delay: 0.4, type: 'spring' }}
                >
                  {/* 头像装饰光圈 */}
                  <motion.div
                    className="absolute inset-0 rounded-2xl bg-gradient-to-br from-yellow-300/40 to-pink-300/40"
                    animate={{ 
                      scale: [1, 1.2, 1],
                      opacity: [0.5, 0.8, 0.5]
                    }}
                    transition={{ 
                      duration: 2,
                      repeat: Infinity
                    }}
                  />
                  <User className="w-8 h-8 text-white relative z-10" strokeWidth={2.5} />
                </motion.div>
              </Link>
            </div>
          </motion.div>
        </div>

        {/* 今日打卡横幅 - 增强设计 */}
        <Link to="/checkin">
          <motion.div
            className={`rounded-3xl p-6 shadow-2xl mb-5 relative overflow-hidden border-3 ${
              todayDone 
                ? 'bg-gradient-to-br from-green-50 via-emerald-50 to-teal-50 border-green-200/80' 
                : 'bg-gradient-to-br from-green-400 via-emerald-400 to-teal-400 border-green-300/60'
            }`}
            whileHover={{ scale: 1.02, y: -4 }}
            whileTap={{ scale: 0.98 }}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2, type: 'spring' }}
          >
            {/* 背景装饰波浪 */}
            {!todayDone && (
              <>
                <motion.div 
                  className="absolute top-0 right-0 w-40 h-40 bg-white/10 rounded-full -mr-20 -mt-20"
                  animate={{ 
                    scale: [1, 1.3, 1], 
                    opacity: [0.3, 0.2, 0.3],
                    rotate: [0, 90, 0]
                  }}
                  transition={{ duration: 5, repeat: Infinity }}
                />
                <motion.div 
                  className="absolute bottom-0 left-0 w-32 h-32 bg-white/10 rounded-full -ml-16 -mb-16"
                  animate={{ 
                    scale: [1, 1.4, 1], 
                    opacity: [0.2, 0.3, 0.2],
                    rotate: [0, -90, 0]
                  }}
                  transition={{ duration: 4, repeat: Infinity, delay: 1 }}
                />
                {/* 星星装饰 */}
                {[...Array(5)].map((_, i) => (
                  <motion.div
                    key={i}
                    className="absolute"
                    style={{
                      top: `${20 + Math.random() * 60}%`,
                      left: `${10 + Math.random() * 80}%`
                    }}
                    animate={{
                      scale: [0, 1, 0],
                      rotate: [0, 180],
                      opacity: [0, 1, 0]
                    }}
                    transition={{
                      duration: 2,
                      delay: i * 0.4,
                      repeat: Infinity,
                      repeatDelay: 2
                    }}
                  >
                    <Sparkles className="w-4 h-4 text-white" />
                  </motion.div>
                ))}
              </>
            )}
            
            <div className="relative flex items-center gap-4">
              <motion.div 
                className={`w-20 h-20 rounded-2xl flex items-center justify-center shadow-xl border-2 border-white/40 ${
                  todayDone ? 'bg-gradient-to-br from-green-200 to-emerald-300' : 'bg-white/30 backdrop-blur-md'
                }`}
                animate={!todayDone ? {
                  scale: [1, 1.05, 1],
                  rotate: [0, 3, -3, 0]
                } : {}}
                transition={{ 
                  duration: 2,
                  repeat: !todayDone ? Infinity : 0
                }}
              >
                {todayDone ? (
                  <CheckCircle2 className="w-10 h-10 text-green-600" strokeWidth={2.5} />
                ) : (
                  <ClipboardList className="w-10 h-10 text-white" strokeWidth={2} />
                )}
              </motion.div>
              
              <div className="flex-1">
                <h3 className={`text-xl font-bold mb-1 ${todayDone ? 'text-gray-800' : 'text-white drop-shadow-md'}`}>
                  {todayDone ? '今日打卡已完成 ✓' : '开始今日打卡'}
                </h3>
                <p className={`text-sm ${todayDone ? 'text-gray-600' : 'text-white/95 drop-shadow-sm'}`}>
                  {todayDone
                    ? `心情 ${todayCheckIn?.moodEmoji ?? ''} · 睡眠 ${todayCheckIn?.sleepHours ?? 0}小时`
                    : '每天3个问题，记录老宝的状态'}
                </p>
              </div>
              
              <ChevronRight className={`w-7 h-7 ${todayDone ? 'text-gray-400' : 'text-white/90'}`} />
            </div>
          </motion.div>
        </Link>

        {/* AI 今日护理预测 - 增强设计 */}
        <Link to="/assistant">
          <motion.div
            className="bg-gradient-to-br from-purple-50 via-violet-50 to-purple-50 rounded-3xl p-6 shadow-2xl border-3 border-purple-100/80 mb-5 relative overflow-hidden"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.3, type: 'spring' }}
            whileHover={{ scale: 1.02, y: -4 }}
            whileTap={{ scale: 0.98 }}
          >
            {/* 背景装饰 */}
            <CardPattern variant={1} />
            <motion.div 
              className="absolute top-4 right-4 opacity-15"
              animate={{ rotate: [0, 360] }}
              transition={{ duration: 20, repeat: Infinity, ease: 'linear' }}
            >
              <Sparkles className="w-20 h-20 text-purple-400" />
            </motion.div>
            
            <div className="relative">
              <div className="flex items-center gap-3 mb-4">
                <motion.div 
                  className="w-12 h-12 rounded-xl bg-gradient-to-br from-purple-400 to-violet-500 flex items-center justify-center shadow-xl"
                  animate={{
                    scale: [1, 1.1, 1],
                    rotate: [0, 5, -5, 0]
                  }}
                  transition={{ duration: 3, repeat: Infinity }}
                >
                  <Sparkles className="w-6 h-6 text-white" strokeWidth={2.5} />
                </motion.div>
                <div>
                  <h3 className="text-purple-800 font-bold text-lg">AI 今日护理预测</h3>
                  <p className="text-xs text-purple-600">老宝的阿兹海默护理建议 · 每日更新</p>
                </div>
              </div>
              
              <div className="bg-white/80 backdrop-blur-sm rounded-2xl p-5 mb-4 shadow-md border border-purple-100/50">
                <p className="text-gray-700 leading-relaxed text-sm font-medium">
                  {encouragement}
                </p>
              </div>

              <div className="flex items-center gap-2 flex-wrap">
                {[
                  { icon: '🧠', label: '护理指数' },
                  { icon: '💬', label: '营养建议' },
                  { icon: '☀️', label: '天气组合' }
                ].map((tag, i) => (
                  <motion.span
                    key={i}
                    className="px-4 py-2 bg-purple-100/80 text-purple-700 rounded-full text-xs font-bold shadow-sm border border-purple-200/50"
                    initial={{ opacity: 0, scale: 0.8 }}
                    animate={{ opacity: 1, scale: 1 }}
                    transition={{ delay: 0.5 + i * 0.1 }}
                    whileHover={{ scale: 1.05, y: -2 }}
                  >
                    {tag.icon} {tag.label}
                  </motion.span>
                ))}
              </div>

              <div className="mt-4 text-sm text-purple-600 font-bold flex items-center gap-1">
                查看详细建议
                <ChevronRight className="w-4 h-4" />
              </div>
            </div>
          </motion.div>
        </Link>

        {/* 周/月切换 + 本周数据 */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          className="mb-5"
        >
          {/* 本周卡片 */}
          <div className="bg-gradient-to-br from-white via-orange-50/30 to-pink-50/30 rounded-3xl p-6 shadow-2xl border-3 border-white/80 relative overflow-hidden">
            {/* 背景装饰波浪 */}
            <motion.div
              className="absolute -top-10 -right-10 w-40 h-40 rounded-full bg-gradient-to-br from-orange-200/20 to-pink-200/20 blur-2xl"
              animate={{ 
                scale: [1, 1.2, 1],
                rotate: [0, 90, 0]
              }}
              transition={{ duration: 8, repeat: Infinity }}
            />
            <motion.div
              className="absolute -bottom-10 -left-10 w-40 h-40 rounded-full bg-gradient-to-br from-purple-200/20 to-blue-200/20 blur-2xl"
              animate={{ 
                scale: [1, 1.3, 1],
                rotate: [0, -90, 0]
              }}
              transition={{ duration: 10, repeat: Infinity }}
            />
            
            <div className="flex items-center justify-between mb-6 relative z-10">
              <div>
                <h3 className="font-bold text-gray-800 text-xl mb-1 flex items-center gap-2">
                  本周
                  <motion.span
                    animate={{ 
                      rotate: [0, 10, -10, 0],
                      scale: [1, 1.1, 1]
                    }}
                    transition={{ duration: 2, repeat: Infinity }}
                  >
                    📊
                  </motion.span>
                </h3>
                <p className="text-xs text-gray-500 font-medium">
                  {recentMoods.length > 0 
                    ? `${new Date(recentMoods[0].date).toLocaleDateString('zh-CN', { month: 'long', day: 'numeric' })} 至 ${new Date(recentMoods[recentMoods.length - 1].date).toLocaleDateString('zh-CN', { month: 'long', day: 'numeric' })}`
                    : '暂无数据'}
                </p>
              </div>
              
              <div className="flex gap-2">
                <motion.button 
                  className="w-10 h-10 rounded-xl bg-white flex items-center justify-center shadow-lg border-2 border-gray-100"
                  whileHover={{ scale: 1.1, backgroundColor: '#fef3c7' }}
                  whileTap={{ scale: 0.9 }}
                >
                  <ChevronRight className="w-5 h-5 text-gray-600 rotate-180" />
                </motion.button>
                <motion.button 
                  className="w-10 h-10 rounded-xl bg-white flex items-center justify-center shadow-lg border-2 border-gray-100"
                  whileHover={{ scale: 1.1, backgroundColor: '#fef3c7' }}
                  whileTap={{ scale: 0.9 }}
                >
                  <ChevronRight className="w-5 h-5 text-gray-600" />
                </motion.button>
              </div>
            </div>

            {/* 心情指数 - 全新设计 */}
            <div className="mb-6 relative z-10">
              <h4 className="text-base font-bold text-gray-700 mb-4 flex items-center gap-2">
                心情指数
                <motion.span
                  animate={{ scale: [1, 1.2, 1] }}
                  transition={{ duration: 1.5, repeat: Infinity }}
                >
                  😊
                </motion.span>
              </h4>
              
              <div className="bg-gradient-to-br from-orange-50/80 via-amber-50/80 to-yellow-50/80 rounded-3xl p-6 border-2 border-orange-100/50 shadow-xl relative overflow-hidden">
                {/* 背景装饰光晕 */}
                <motion.div
                  className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-32 h-32 rounded-full bg-gradient-to-br from-yellow-300/30 to-orange-300/30 blur-3xl"
                  animate={{ 
                    scale: [1, 1.4, 1],
                    opacity: [0.3, 0.6, 0.3]
                  }}
                  transition={{ duration: 4, repeat: Infinity }}
                />
                
                <div className="flex items-center gap-6 relative z-10">
                  {/* 温度计 - 全新可爱设计 */}
                  <div className="relative">
                    <svg width="80" height="200" viewBox="0 0 80 200" className="drop-shadow-xl">
                      <defs>
                        {/* 温度计管渐变 */}
                        <linearGradient id="tubeGrad" x1="0%" y1="0%" x2="0%" y2="100%">
                          <stop offset="0%" stopColor="#f3f4f6" />
                          <stop offset="100%" stopColor="#e5e7eb" />
                        </linearGradient>
                        {/* 水银渐变 */}
                        <linearGradient id="mercuryGrad" x1="0%" y1="100%" x2="0%" y2="0%">
                          <stop offset="0%" stopColor="#f97316" />
                          <stop offset="50%" stopColor="#fb923c" />
                          <stop offset="100%" stopColor="#fde047" />
                        </linearGradient>
                        {/* 阴影 */}
                        <filter id="thermometerShadow">
                          <feDropShadow dx="0" dy="4" stdDeviation="4" floodOpacity="0.2"/>
                        </filter>
                      </defs>
                      
                      {/* 温度计管身 */}
                      <rect
                        x="20"
                        y="20"
                        width="40"
                        height="140"
                        rx="20"
                        fill="url(#tubeGrad)"
                        stroke="#d1d5db"
                        strokeWidth="3"
                        filter="url(#thermometerShadow)"
                      />
                      
                      {/* 水银柱 */}
                      <motion.rect
                        x="25"
                        y="25"
                        width="30"
                        height="0"
                        rx="15"
                        fill="url(#mercuryGrad)"
                        initial={{ height: 0 }}
                        animate={{ height: 135 * (parseFloat(avgMood) / 10) }}
                        transition={{ duration: 1.5, delay: 0.6, type: 'spring', bounce: 0.3 }}
                      />
                      
                      {/* 温度计底部圆球 */}
                      <circle
                        cx="40"
                        cy="175"
                        r="25"
                        fill="url(#mercuryGrad)"
                        stroke="#f97316"
                        strokeWidth="3"
                        filter="url(#thermometerShadow)"
                      />
                      
                      {/* 圆球内部emoji */}
                      <text
                        x="40"
                        y="175"
                        textAnchor="middle"
                        dominantBaseline="middle"
                        fontSize="20"
                      >
                        😊
                      </text>
                      
                      {/* 圆球高光 */}
                      <circle
                        cx="30"
                        cy="165"
                        r="8"
                        fill="white"
                        opacity="0.6"
                      />
                    </svg>
                  </div>
                  
                  {/* 数据显示 */}
                  <div className="flex-1">
                    <div className="flex items-baseline gap-3 mb-3">
                      <motion.span 
                        className="text-7xl font-black bg-gradient-to-br from-orange-500 via-amber-500 to-yellow-500 bg-clip-text text-transparent drop-shadow-sm"
                        initial={{ opacity: 0, scale: 0.5 }}
                        animate={{ opacity: 1, scale: 1 }}
                        transition={{ delay: 0.8, type: 'spring', bounce: 0.4 }}
                      >
                        {avgMood}
                      </motion.span>
                      <span className="text-gray-400 text-2xl font-bold">/ 10</span>
                    </div>
                    
                    <motion.div
                      className="inline-flex items-center gap-2 bg-white/80 backdrop-blur-sm px-4 py-2 rounded-full shadow-lg border-2 border-orange-200/50"
                      initial={{ opacity: 0, x: -20 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: 1 }}
                    >
                      <span className="text-2xl">
                        {parseFloat(avgMood) >= 7 ? '🌟' : parseFloat(avgMood) >= 4 ? '😊' : '💕'}
                      </span>
                      <p className="text-sm text-gray-700 font-bold">
                        {parseFloat(avgMood) >= 7 ? '本周心情很棒！' : parseFloat(avgMood) >= 4 ? '本周心情平稳' : '需要更多陪伴'}
                      </p>
                    </motion.div>
                    
                    {/* 进度条 */}
                    <div className="mt-4 space-y-2">
                      <div className="flex items-center justify-between text-xs text-gray-500 font-medium">
                        <span>心情健康度</span>
                        <span>{Math.round(parseFloat(avgMood) * 10)}%</span>
                      </div>
                      <div className="h-3 bg-white/60 rounded-full overflow-hidden border-2 border-orange-100/50 shadow-inner">
                        <motion.div
                          className="h-full bg-gradient-to-r from-orange-400 via-amber-400 to-yellow-400 rounded-full shadow-sm"
                          initial={{ width: 0 }}
                          animate={{ width: `${parseFloat(avgMood) * 10}%` }}
                          transition={{ duration: 1.5, delay: 1.2, ease: 'easeOut' }}
                        />
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* 心情分布 */}
            <div className="relative z-10">
              <h4 className="text-base font-bold text-gray-700 mb-4 flex items-center gap-2">
                心情分布
                <motion.span
                  animate={{ y: [0, -3, 0] }}
                  transition={{ duration: 1.5, repeat: Infinity }}
                >
                  📈
                </motion.span>
              </h4>
              
              {recentMoods.length > 0 ? (
                <div className="bg-gradient-to-br from-white/90 via-blue-50/30 to-purple-50/30 rounded-3xl p-6 border-2 border-white/60 shadow-xl">
                  <div className="flex items-end justify-between h-28 gap-2 mb-5">
                    {recentMoods.map((mood, i) => (
                      <MoodBar key={i} score={mood.moodScore} date={mood.date} />
                    ))}
                  </div>
                  
                  <div className="grid grid-cols-2 gap-4">
                    <div className="bg-white/80 backdrop-blur-sm rounded-2xl p-4 border-2 border-gray-100 shadow-md">
                      <p className="text-xs text-gray-500 font-medium mb-1">记录天数</p>
                      <p className="text-3xl font-black bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
                        {recentMoods.length}
                      </p>
                      <p className="text-xs text-gray-400 mt-1">本周已打卡</p>
                    </div>
                    
                    <div className="bg-white/80 backdrop-blur-sm rounded-2xl p-4 border-2 border-gray-100 shadow-md">
                      <p className="text-xs text-gray-500 font-medium mb-1">主要心情</p>
                      <p className="text-4xl mb-1">{getMoodEmoji(parseFloat(avgMood))}</p>
                      <p className="text-xs text-gray-400">情绪平稳</p>
                    </div>
                  </div>
                </div>
              ) : (
                <div className="bg-gradient-to-br from-gray-50 to-gray-100 rounded-3xl p-10 text-center border-2 border-dashed border-gray-300">
                  <motion.div
                    animate={{ y: [0, -10, 0] }}
                    transition={{ duration: 2, repeat: Infinity }}
                  >
                    <span className="text-5xl mb-3 block">📝</span>
                  </motion.div>
                  <p className="text-gray-500 text-sm font-medium">暂无心情数据</p>
                  <p className="text-gray-400 text-xs mt-1">开始打卡记录吧！</p>
                </div>
              )}
            </div>
          </div>
        </motion.div>

        {/* 今日护理贴士 */}
        {tip && (
          <motion.div
            className="bg-gradient-to-br from-amber-50 via-orange-50 to-amber-50 rounded-3xl p-6 shadow-2xl border-3 border-amber-100/80 mb-5 relative overflow-hidden"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.5 }}
          >
            <CardPattern variant={1} />
            <div className="flex items-center gap-3 mb-4 relative z-10">
              <motion.div 
                className="w-12 h-12 rounded-xl bg-gradient-to-br from-amber-400 to-orange-500 flex items-center justify-center shadow-xl"
                animate={{
                  rotate: [0, 10, -10, 0],
                  scale: [1, 1.1, 1]
                }}
                transition={{ duration: 3, repeat: Infinity }}
              >
                <Heart className="w-6 h-6 text-white" strokeWidth={2.5} />
              </motion.div>
              <div>
                <span className="text-xs font-bold text-amber-700 uppercase tracking-wider block">
                  {tip.category}
                </span>
                <span className="text-xs text-amber-600 font-medium">护理小贴士</span>
              </div>
            </div>
            <div className="bg-white/70 backdrop-blur-sm rounded-2xl p-4 shadow-md border border-amber-100 relative z-10">
              <p className="text-gray-700 leading-relaxed text-sm font-medium">
                {tip.tip}
              </p>
            </div>
          </motion.div>
        )}

        {/* 快捷入口 - 重新设计 */}
        <div className="mb-6">
          <h3 className="text-xl font-bold text-gray-800 mb-5 flex items-center gap-2">
            <motion.span 
              className="text-2xl"
              animate={{ rotate: [0, 15, -15, 0] }}
              transition={{ duration: 2, repeat: Infinity }}
            >
              🚀
            </motion.span>
            快捷入口
          </h3>
          
          <div className="grid grid-cols-2 gap-4">
            {quickActions.map((action, index) => {
              const IconComponent = action.icon;
              return (
                <Link key={index} to={action.path}>
                  <motion.div
                    className={`${action.bgColor} rounded-3xl p-6 shadow-xl border-2 border-white/60 relative overflow-hidden`}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.4, delay: 0.6 + index * 0.1, type: 'spring' }}
                    whileHover={{ scale: 1.05, y: -5 }}
                    whileTap={{ scale: 0.95 }}
                  >
                    {/* 背景装饰 */}
                    <motion.div 
                      className="absolute top-0 right-0 w-20 h-20 bg-white/40 rounded-full -mr-10 -mt-10"
                      animate={{ scale: [1, 1.2, 1] }}
                      transition={{ duration: 3, repeat: Infinity, delay: index * 0.5 }}
                    />
                    <motion.div 
                      className="absolute bottom-0 left-0 w-16 h-16 bg-white/30 rounded-full -ml-8 -mb-8"
                      animate={{ scale: [1, 1.3, 1] }}
                      transition={{ duration: 4, repeat: Infinity, delay: index * 0.5 + 1 }}
                    />
                    
                    <div className="relative z-10">
                      <motion.div 
                        className={`w-14 h-14 ${action.iconBg} rounded-2xl flex items-center justify-center mb-4 shadow-2xl border-2 border-white/40`}
                        whileHover={{ rotate: 10, scale: 1.1 }}
                      >
                        <IconComponent className="w-7 h-7 text-white" strokeWidth={2.5} />
                      </motion.div>
                      <p className="font-bold text-base text-gray-800 mb-1">{action.label}</p>
                      <p className="text-2xl">{action.emoji}</p>
                    </div>
                  </motion.div>
                </Link>
              );
            })}
          </div>
        </div>
      </motion.div>
    </div>
  );
}