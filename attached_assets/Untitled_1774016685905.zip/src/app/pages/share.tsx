import { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { getTodayCheckIn, getProfile } from '@/lib/storage';
import { Share2, Download } from 'lucide-react';

export function SharePage() {
  const [checkIn, setCheckIn] = useState<any>(null);
  const [profile, setProfile] = useState<any>(null);

  useEffect(() => {
    loadData();
  }, []);

  async function loadData() {
    const c = await getTodayCheckIn();
    const p = await getProfile();
    setCheckIn(c);
    setProfile(p);
  }

  function handleShare() {
    if (!checkIn) {
      alert('今天还没有打卡数据哦');
      return;
    }

    const text = `
【小马虎 - 今日护理报告】

👤 ${profile?.elderName || '老宝'}（${profile?.nickname || ''}）
📅 ${checkIn.date}

😴 睡眠情况
时长：${checkIn.sleepHours}小时
质量：${checkIn.sleepQuality === 'good' ? '很好' : checkIn.sleepQuality === 'fair' ? '一般' : '欠佳'}

${checkIn.moodEmoji} 心情状态
情绪：${checkIn.moodEmoji} （${checkIn.moodScore}/10分）

💊 用药情况
${checkIn.medicationTaken ? '✅ 已按时服药' : '❌ 未按时服药'}

📝 备注
${checkIn.eveningNotes || checkIn.morningNotes || '无'}

---
由小马虎 App 生成
    `.trim();

    if (navigator.share) {
      navigator.share({
        title: '今日护理报告',
        text: text,
      }).catch(() => {});
    } else {
      navigator.clipboard.writeText(text);
      alert('报告已复制到剪贴板！');
    }
  }

  return (
    <div className="p-6 pb-28">
      {/* Header */}
      <div className="pt-2 mb-6">
        <h1 className="text-2xl font-bold text-gray-800 flex items-center gap-2 mb-2">
          <span>🤝</span> 家庭共享
        </h1>
        <p className="text-gray-600 text-sm">将今日护理情况分享给家人</p>
      </div>

      {checkIn && checkIn.morningDone && checkIn.eveningDone ? (
        <>
          {/* Summary Card */}
          <motion.div
            className="bg-gradient-to-br from-green-50 to-emerald-50 rounded-3xl p-6 shadow-xl border-2 border-green-100 mb-6"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
          >
            <div className="flex items-center justify-between mb-4">
              <div>
                <h2 className="text-xl font-bold text-gray-800">今日护理报告</h2>
                <p className="text-sm text-gray-600">{checkIn.date}</p>
              </div>
              <div className="w-14 h-14 rounded-full bg-white shadow-md flex items-center justify-center text-3xl">
                {profile?.zodiacEmoji || '👤'}
              </div>
            </div>

            <div className="space-y-4">
              {/* Sleep */}
              <div className="bg-white/80 rounded-2xl p-4">
                <div className="flex items-center gap-2 mb-2">
                  <span className="text-xl">😴</span>
                  <h3 className="font-bold text-gray-800">睡眠情况</h3>
                </div>
                <div className="grid grid-cols-2 gap-3 text-sm">
                  <div>
                    <span className="text-gray-500">时长</span>
                    <p className="font-bold text-gray-800">{checkIn.sleepHours}小时</p>
                  </div>
                  <div>
                    <span className="text-gray-500">质量</span>
                    <p className="font-bold text-gray-800">
                      {checkIn.sleepQuality === 'good' ? '很好' : checkIn.sleepQuality === 'fair' ? '一般' : '欠佳'}
                    </p>
                  </div>
                </div>
              </div>

              {/* Mood */}
              <div className="bg-white/80 rounded-2xl p-4">
                <div className="flex items-center gap-2 mb-2">
                  <span className="text-xl">{checkIn.moodEmoji}</span>
                  <h3 className="font-bold text-gray-800">心情状态</h3>
                </div>
                <p className="text-sm">
                  <span className="text-gray-500">情绪分数：</span>
                  <span className="font-bold text-gray-800">{checkIn.moodScore}/10</span>
                </p>
              </div>

              {/* Medication */}
              <div className="bg-white/80 rounded-2xl p-4">
                <div className="flex items-center gap-2 mb-2">
                  <span className="text-xl">💊</span>
                  <h3 className="font-bold text-gray-800">用药情况</h3>
                </div>
                <p className="text-sm font-bold" style={{ color: checkIn.medicationTaken ? '#22C55E' : '#EF4444' }}>
                  {checkIn.medicationTaken ? '✅ 已按时服药' : '❌ 未按时服药'}
                </p>
              </div>

              {/* Notes */}
              {(checkIn.morningNotes || checkIn.eveningNotes || checkIn.mealNotes) && (
                <div className="bg-white/80 rounded-2xl p-4">
                  <div className="flex items-center gap-2 mb-2">
                    <span className="text-xl">📝</span>
                    <h3 className="font-bold text-gray-800">备注</h3>
                  </div>
                  <div className="space-y-1 text-sm text-gray-700">
                    {checkIn.morningNotes && <p>• {checkIn.morningNotes}</p>}
                    {checkIn.mealNotes && <p>• 饮食：{checkIn.mealNotes}</p>}
                    {checkIn.eveningNotes && <p>• {checkIn.eveningNotes}</p>}
                  </div>
                </div>
              )}
            </div>
          </motion.div>

          {/* Share Button */}
          <motion.button
            onClick={handleShare}
            className="w-full bg-gradient-to-r from-blue-500 to-cyan-500 text-white py-4 rounded-2xl font-bold shadow-xl flex items-center justify-center gap-2"
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
          >
            <Share2 className="w-5 h-5" />
            分享今日报告
          </motion.button>

          <p className="text-center text-xs text-gray-500 mt-4">
            点击按钮后可以分享到微信、复制文本或保存图片
          </p>
        </>
      ) : (
        <div className="text-center py-16">
          <p className="text-6xl mb-4">📊</p>
          <h3 className="text-xl font-bold text-gray-800 mb-2">还没有完整数据</h3>
          <p className="text-gray-600">完成今天的早晚打卡后，就可以生成今日报告并分享给家人了</p>
        </div>
      )}

      {/* Tips */}
      <motion.div
        className="bg-gradient-to-br from-purple-50 to-pink-50 rounded-2xl p-6 mt-6 border-2 border-purple-100"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.4 }}
      >
        <div className="flex items-center gap-2 mb-3">
          <span className="text-2xl">💡</span>
          <h4 className="font-bold text-purple-800">分享小贴士</h4>
        </div>
        <ul className="space-y-2 text-sm text-purple-900">
          <li>• 定期与家人分享老人的护理情况，让大家都参与到照护中</li>
          <li>• 报告内容包含睡眠、情绪、用药等关键信息</li>
          <li>• 可以直接分享到微信群，方便家人了解</li>
          <li>• 建议每天固定时间分享，形成家庭护理日记</li>
        </ul>
      </motion.div>
    </div>
  );
}
