import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { getDiaryEntries, saveDiaryEntry, deleteDiaryEntry, DiaryEntry, todayStr } from '@/lib/storage';
import { X, Plus, Trash2 } from 'lucide-react';

const MOOD_OPTIONS = [
  { emoji: '😄', label: '很开心', color: '#22C55E' },
  { emoji: '😊', label: '还不错', color: '#84CC16' },
  { emoji: '😌', label: '平静', color: '#6B7280' },
  { emoji: '😕', label: '有点累', color: '#F59E0B' },
  { emoji: '😢', label: '不太好', color: '#EF4444' },
  { emoji: '😤', label: '烦躁', color: '#DC2626' },
];

const TAGS = ['散步', '吃饭好', '睡眠好', '认出家人', '情绪稳定', '有点混乱', '拒绝服药', '跌倒', '特别开心', '需要安慰'];

export function DiaryPage() {
  const [entries, setEntries] = useState<DiaryEntry[]>([]);
  const [writing, setWriting] = useState(false);
  const [selectedMood, setSelectedMood] = useState(0);
  const [selectedTags, setSelectedTags] = useState<string[]>([]);
  const [content, setContent] = useState('');

  useEffect(() => {
    loadEntries();
  }, []);

  async function loadEntries() {
    const data = await getDiaryEntries();
    setEntries(data.slice(0, 30));
  }

  function toggleTag(tag: string) {
    setSelectedTags(prev =>
      prev.includes(tag) ? prev.filter(t => t !== tag) : [...prev, tag]
    );
  }

  async function handleSave() {
    const entry: DiaryEntry = {
      id: Date.now().toString(),
      date: todayStr(),
      moodEmoji: MOOD_OPTIONS[selectedMood].emoji,
      moodLabel: MOOD_OPTIONS[selectedMood].label,
      tags: selectedTags,
      content: content.trim(),
    };
    await saveDiaryEntry(entry);
    await loadEntries();
    setWriting(false);
    setContent('');
    setSelectedTags([]);
    setSelectedMood(0);
  }

  async function handleDelete(id: string) {
    if (confirm('确定要删除这条日记吗？')) {
      await deleteDiaryEntry(id);
      await loadEntries();
    }
  }

  return (
    <div className="p-6 pb-28">
      {/* Header */}
      <div className="flex items-center justify-between mb-6 pt-2">
        <h1 className="text-2xl font-bold text-gray-800 flex items-center gap-2">
          <span>📖</span> 护理日记
        </h1>
        <button
          onClick={() => setWriting(true)}
          className="bg-gradient-to-r from-blue-500 to-cyan-500 text-white px-4 py-2 rounded-2xl font-bold shadow-lg hover:scale-105 transition-transform flex items-center gap-1"
        >
          <Plus className="w-4 h-4" />
          写日记
        </button>
      </div>

      {/* Write Form */}
      <AnimatePresence>
        {writing && (
          <motion.div
            className="bg-white rounded-3xl p-6 shadow-xl border-2 border-gray-100 mb-6"
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
          >
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-xl font-bold text-gray-800">今天怎么样？</h3>
              <button onClick={() => setWriting(false)} className="text-gray-400 hover:text-gray-600">
                <X className="w-6 h-6" />
              </button>
            </div>

            {/* Mood */}
            <label className="text-sm font-semibold text-gray-600 mb-2 block">老人今天的心情</label>
            <div className="grid grid-cols-3 gap-2 mb-4">
              {MOOD_OPTIONS.map((m, i) => (
                <button
                  key={i}
                  onClick={() => setSelectedMood(i)}
                  className={`flex flex-col items-center gap-1 p-3 rounded-xl transition-all ${
                    selectedMood === i
                      ? 'border-2'
                      : 'bg-gray-100 border-2 border-gray-200 hover:bg-gray-200'
                  }`}
                  style={selectedMood === i ? {
                    backgroundColor: m.color + '20',
                    borderColor: m.color,
                  } : {}}
                >
                  <span className="text-2xl">{m.emoji}</span>
                  <span 
                    className="text-xs font-semibold"
                    style={selectedMood === i ? { color: m.color } : { color: '#6B7280' }}
                  >
                    {m.label}
                  </span>
                </button>
              ))}
            </div>

            {/* Tags */}
            <label className="text-sm font-semibold text-gray-600 mb-2 block">今天发生了什么？（可多选）</label>
            <div className="flex flex-wrap gap-2 mb-4">
              {TAGS.map((tag) => (
                <button
                  key={tag}
                  onClick={() => toggleTag(tag)}
                  className={`px-3 py-1.5 rounded-full text-sm font-semibold transition-all ${
                    selectedTags.includes(tag)
                      ? 'bg-gradient-to-br from-blue-100 to-cyan-100 border-2 border-blue-400 text-blue-700'
                      : 'bg-gray-100 border-2 border-gray-200 text-gray-600 hover:bg-gray-200'
                  }`}
                >
                  {selectedTags.includes(tag) ? '✓ ' : ''}{tag}
                </button>
              ))}
            </div>

            {/* Notes */}
            <label className="text-sm font-semibold text-gray-600 mb-2 block">详细记录（可选）</label>
            <textarea
              className="w-full bg-gray-100 rounded-2xl p-4 mb-6 border-2 border-gray-200 focus:border-blue-400 focus:outline-none min-h-32"
              placeholder="写下今天的护理情况、老人的特别反应、你的感受..."
              value={content}
              onChange={(e) => setContent(e.target.value)}
            />

            <div className="flex gap-3">
              <button
                onClick={() => setWriting(false)}
                className="flex-1 bg-gray-100 text-gray-700 py-3 rounded-2xl font-semibold hover:bg-gray-200"
              >
                取消
              </button>
              <button
                onClick={handleSave}
                className="flex-2 bg-gradient-to-r from-blue-500 to-cyan-500 text-white py-3 px-6 rounded-2xl font-bold shadow-lg hover:scale-105 transition-transform"
              >
                保存日记 💕
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Entries */}
      {entries.length === 0 && !writing ? (
        <div className="text-center py-16">
          <p className="text-6xl mb-4">📖</p>
          <h3 className="text-xl font-bold text-gray-800 mb-2">还没有日记</h3>
          <p className="text-gray-600 mb-6">每天记录一点点，<br />积累成最珍贵的回忆</p>
          <button
            onClick={() => setWriting(true)}
            className="bg-gradient-to-r from-blue-500 to-cyan-500 text-white px-6 py-3 rounded-full font-bold shadow-lg hover:scale-105 transition-transform"
          >
            开始第一篇日记
          </button>
        </div>
      ) : (
        <div className="space-y-4">
          <h3 className="text-lg font-bold text-gray-800 mb-4">📅 最近记录</h3>
          {entries.map((entry) => {
            const mood = MOOD_OPTIONS.find(m => m.emoji === entry.moodEmoji) || MOOD_OPTIONS[2];
            return (
              <motion.div
                key={entry.id}
                className="bg-white rounded-2xl p-4 shadow-md border border-gray-100"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                whileHover={{ scale: 1.02 }}
              >
                <div className="flex items-center justify-between mb-3">
                  <span className="text-sm font-semibold text-gray-600">{entry.date}</span>
                  <div className="flex items-center gap-2">
                    <div
                      className="flex items-center gap-1 px-3 py-1 rounded-full"
                      style={{ backgroundColor: mood.color + '20' }}
                    >
                      <span className="text-lg">{entry.moodEmoji}</span>
                      <span className="text-xs font-semibold" style={{ color: mood.color }}>
                        {entry.moodLabel}
                      </span>
                    </div>
                    <button
                      onClick={() => handleDelete(entry.id)}
                      className="text-gray-400 hover:text-red-500 transition-colors"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>

                {entry.tags && entry.tags.length > 0 && (
                  <div className="flex flex-wrap gap-1.5 mb-3">
                    {entry.tags.map((tag, i) => (
                      <span key={i} className="bg-gray-100 text-gray-600 text-xs font-medium px-2 py-1 rounded-lg">
                        {tag}
                      </span>
                    ))}
                  </div>
                )}

                {entry.content && (
                  <p className="text-sm text-gray-700 leading-relaxed">{entry.content}</p>
                )}
              </motion.div>
            );
          })}
        </div>
      )}
    </div>
  );
}
